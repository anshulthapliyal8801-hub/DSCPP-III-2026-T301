/*
 * MUNSphere — dsa_api.h
 *
 * The single contract between the C data-structure layer and the C++ layer.
 *
 * Why one shared header instead of re-declaring functions in each .cpp file:
 * if a C signature changes and a hand-written C++ declaration does not, the
 * program still compiles and links (C symbols carry no type information) and
 * then misbehaves at runtime. Declaring everything once, and including this
 * header in BOTH the .c and the .cpp files, makes the compiler check that the
 * two sides agree.
 *
 * The .c files themselves stay header-free: each module's C code lives in a
 * single *_dsa.c file, and its public functions are declared here.
 */
#ifndef MUNSPHERE_DSA_API_H
#define MUNSPHERE_DSA_API_H

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------ */
/* Common status codes returned by every C data-structure function    */
/* ------------------------------------------------------------------ */
typedef enum {
    DSA_OK            = 0,
    DSA_ERR_DUPLICATE = 1,  /* a record with this ID already exists      */
    DSA_ERR_NOT_FOUND = 2,  /* no record with this ID                    */
    DSA_ERR_NO_MEMORY = 3,  /* malloc failed                             */
    DSA_ERR_INVALID   = 4,  /* bad argument or malformed file            */
    DSA_ERR_IO        = 5,  /* file could not be opened/written/replaced */
    DSA_ERR_FULL      = 6   /* fixed-capacity structure is full          */
} DsaStatus;

/* Field capacities, including the terminating '\0'. The C++ layer
 * rejects longer input before it reaches C, so nothing is truncated. */
#define DSA_ID_LEN     16   /* IDs: up to 15 characters      */
#define DSA_NAME_LEN   101  /* names/titles: up to 100       */
#define DSA_SHORT_LEN  21   /* abbreviations: up to 20       */
#define DSA_TEXT_LEN   301  /* descriptions/agenda: up to 300 */
#define DSA_DATE_LEN   11   /* YYYY-MM-DD                    */
#define DSA_TIME_LEN   6    /* HH:MM                         */
#define DSA_PATH_LEN   512
#define DSA_STAMP_LEN  20   /* YYYY-MM-DD HH:MM:SS           */
#define DSA_PASS_LEN   160  /* pbkdf2-sha256$iter$salt$hash   */

/* ================================================================== */
/* MODULE 1 — Conference & Session Management (conference_dsa.c)      */
/* Singly linked lists; linear search; file handling.                 */
/* ================================================================== */

typedef struct {
    char id[DSA_ID_LEN];
    char name[DSA_NAME_LEN];
    char venue[DSA_NAME_LEN];
    char startDate[DSA_DATE_LEN];
    char endDate[DSA_DATE_LEN];
    char description[DSA_TEXT_LEN];
} ConferenceRec;

typedef struct {
    char id[DSA_ID_LEN];
    char conferenceId[DSA_ID_LEN];
    char name[DSA_NAME_LEN];
    char abbreviation[DSA_SHORT_LEN];
    char agenda[DSA_TEXT_LEN];
    int  capacity;
} CommitteeRec;

typedef enum {
    SESSION_SCHEDULED = 0,
    SESSION_ACTIVE    = 1,
    SESSION_COMPLETED = 2
} SessionStatus;
#define SESSION_STATUS_COUNT 3

typedef struct {
    char id[DSA_ID_LEN];
    char committeeId[DSA_ID_LEN];
    char title[DSA_NAME_LEN];
    char date[DSA_DATE_LEN];
    char startTime[DSA_TIME_LEN];
    char endTime[DSA_TIME_LEN];
    int  status;              /* one of SessionStatus */
} SessionRec;

/* Entity selector for ID generation */
typedef enum {
    M1_CONFERENCE = 0,
    M1_COMMITTEE  = 1,
    M1_SESSION    = 2
} M1Entity;

/* Store lifecycle */
void m1_store_reset(void);                       /* frees every node */

/* Conferences — list in insertion order */
int  conference_insert(const ConferenceRec *rec);
int  conference_find(const char *id, ConferenceRec *out, int *comparisons);
int  conference_update(const ConferenceRec *rec);
int  conference_delete(const char *id);
int  conference_count(void);
int  conference_to_array(ConferenceRec *out, int max);

/* Committees — list in insertion order */
int  committee_insert(const CommitteeRec *rec);
int  committee_find(const char *id, CommitteeRec *out, int *comparisons);
int  committee_update(const CommitteeRec *rec);
int  committee_delete(const char *id);
int  committee_count(void);
int  committee_to_array(CommitteeRec *out, int max);
int  committee_count_by_conference(const char *conferenceId);
int  committee_search_name(const char *query, CommitteeRec *out, int max,
                           int *comparisons);

/* Sessions — list kept SORTED by (date, startTime, id) on every insert */
int  session_insert(const SessionRec *rec);
int  session_find(const char *id, SessionRec *out, int *comparisons);
int  session_update(const SessionRec *rec);
int  session_delete(const char *id);
int  session_count(void);
int  session_to_array(SessionRec *out, int max);
int  session_count_by_committee(const char *committeeId);
const char *session_status_name(int status);

/* Largest numeric suffix among IDs of the form <prefix><digits>; 0 if none */
int  m1_max_id_suffix(int entity, const char *prefix);

/* File handling. Missing files load as empty. A malformed file is
 * rejected as a whole (DSA_ERR_INVALID) and the in-memory store is left
 * untouched. Individually malformed lines are skipped and counted. */
int  m1_save(const char *conferencePath, const char *committeePath,
             const char *sessionPath);
int  m1_load(const char *conferencePath, const char *committeePath,
             const char *sessionPath, int *skippedLines);

/* ================================================================== */
/* MODULE 12 — Persistence helpers (persistence_dsa.c)                */
/* ================================================================== */
#define PERS_LINE_MAX 4096
#define PERS_MAX_FIELDS 64
void  pers_copy_field(char *dst, const char *src, size_t cap);
void  pers_write_field(FILE *f, const char *s);
void  pers_write_int(FILE *f, int v);
int   pers_split_fields(char *line, char **fields, int maxFields);
int   pers_parse_int(const char *s);
int   pers_read_line(FILE *f, char *buf, size_t cap);
int   pers_open_for_load(const char *path, const char *kind, FILE **out);
FILE *pers_begin_save(const char *path, const char *kind, char *tmpOut, size_t tmpCap);
int   pers_finish_save(FILE *f, const char *tmpPath, const char *path);
int   pers_copy_file(const char *src, const char *dst);

/* Audit log (Module 12): dynamic array in memory, append-only file on disk.
 * Each entry stores the previous entry's hash and its own SHA-256 hash
 * (computed in C++), forming a chain that exposes any later edit. */
#define AUDIT_ACTION_LEN 81
#define AUDIT_TARGET_LEN 101
#define AUDIT_HASH_LEN 65
typedef struct {
    long seq;
    char at[DSA_STAMP_LEN];
    char actor[DSA_ID_LEN];
    char role[12];
    char action[AUDIT_ACTION_LEN];
    char target[AUDIT_TARGET_LEN];
    int  status;
    char prevHash[AUDIT_HASH_LEN];
    char hash[AUDIT_HASH_LEN];
} AuditRec;

void audit_store_reset(void);
/* Adds to memory, and appends one line to `path` (if not NULL), creating
 * the file with its header when needed. */
int  audit_append(const AuditRec *rec, const char *path);
int  audit_count(void);
int  audit_get(int index, AuditRec *out);       /* 0 = oldest */
long audit_next_seq(void);
int  audit_save(const char *path);              /* full rewrite (backups) */
int  audit_load(const char *path, int *skipped);

/* ================================================================== */
/* SHARED — Accounts and login history (Shared/account_dsa.c)          */
/* Hash table with separate chaining (fixed 101 buckets); login        */
/* history as a singly linked list, newest first, capped.             */
/* ================================================================== */
typedef enum { ROLE_ADMIN = 0, ROLE_EB = 1, ROLE_DELEGATE = 2 } AccountRole;
#define ROLE_COUNT 3

typedef struct {
    char id[DSA_ID_LEN];
    int  role;                       /* AccountRole */
    char name[DSA_NAME_LEN];
    char passHash[DSA_PASS_LEN];     /* never sent to the browser */
    int  active;                     /* 0 = deactivated / revoked */
    int  mustChangePassword;         /* set for temporary passwords */
    int  resetRequested;             /* delegate asked for a reset */
    char createdAt[DSA_STAMP_LEN];
} AccountRec;

typedef struct {
    char accountId[DSA_ID_LEN];
    char at[DSA_STAMP_LEN];
    int  success;
    char detail[64];
} LoginEventRec;
#define LOGIN_HISTORY_CAP 1000

void account_store_reset(void);
int  account_insert(const AccountRec *rec);
int  account_find(const char *id, AccountRec *out, int *comparisons);
int  account_update(const AccountRec *rec);
int  account_delete(const char *id);
int  account_count(void);
int  account_count_role(int role);
int  account_to_array(AccountRec *out, int max);
int  account_max_id_suffix(const char *prefix);
void login_history_add(const LoginEventRec *ev);
int  login_history_count(void);
/* accountId NULL or "" = every account; newest first */
int  login_history_to_array(const char *accountId, LoginEventRec *out, int max);
int  accounts_save(const char *accountsPath, const char *historyPath);
int  accounts_load(const char *accountsPath, const char *historyPath, int *skipped);

/* ================================================================== */
/* MODULE 10 — Executive Board assignments (eb_dsa.c)                  */
/* Adjacency list: a linked list of committees, each holding a linked  */
/* list of the EB members assigned to it.                              */
/* ================================================================== */
typedef enum { EB_CHAIRPERSON = 0, EB_MODERATOR = 1, EB_SCRIBE = 2 } EbRole;
#define EB_ROLE_COUNT 3

typedef struct {
    char id[DSA_ID_LEN];             /* same ID as the account */
    char committeeId[DSA_ID_LEN];
    int  ebRole;                     /* EbRole */
    int  permissions;                /* bitmask, see RoleManager.h */
    char email[DSA_NAME_LEN];
} EbRec;

void eb_store_reset(void);
int  eb_insert(const EbRec *rec);
int  eb_find(const char *id, EbRec *out, int *comparisons);
int  eb_update(const EbRec *rec);    /* moves node if committee changed */
int  eb_delete(const char *id);
int  eb_count(void);
int  eb_count_by_committee(const char *committeeId);
int  eb_list_by_committee(const char *committeeId, EbRec *out, int max);
int  eb_committee_count(void);       /* vertices with at least one EB */
int  eb_to_array(EbRec *out, int max);
int  eb_save(const char *path);
int  eb_load(const char *path, int *skipped);

/* ================================================================== */
/* MODULE 2 — Delegates (delegate_dsa.c)                               */
/* Primary store: hash table, separate chaining, rehash at load > 0.75.*/
/* Secondary index: BST ordered by (name, id).                         */
/* ================================================================== */
/* Named REGISTRATION_* rather than REG_*: <windows.h> defines REG_NONE (a
 * registry value type) as a macro, which would break this enum. */
typedef enum {
    REGISTRATION_NONE = 0, REGISTRATION_PENDING = 1, REGISTRATION_APPROVED = 2, REGISTRATION_REJECTED = 3
} RegistrationStatus;
#define REGISTRATION_STATUS_COUNT 4
#define DELEGATE_PREFS 3

typedef struct {
    char id[DSA_ID_LEN];
    char name[DSA_NAME_LEN];         /* BST key; kept equal to the account name */
    char email[DSA_NAME_LEN];
    char institution[DSA_NAME_LEN];
    char conferenceId[DSA_ID_LEN];   /* "" = not registered */
    char prefs[DELEGATE_PREFS][DSA_ID_LEN];
    int  status;                     /* RegistrationStatus */
    char note[DSA_TEXT_LEN];         /* rejection reason */
    char committeeId[DSA_ID_LEN];    /* "" = not assigned */
    char portfolio[DSA_NAME_LEN];
    char registeredAt[DSA_STAMP_LEN];
} DelegateRec;

typedef struct {
    int comparisons;
    int pathLen;
    char path[64][DSA_ID_LEN];       /* nodes/entries examined, in order */
} SearchTrace;

void delegate_store_reset(void);
int  delegate_insert(const DelegateRec *rec);
int  delegate_find(const char *id, DelegateRec *out, int *comparisons);
int  delegate_update(const DelegateRec *rec);  /* re-indexes BST if name changed */
int  delegate_delete(const char *id);
int  delegate_count(void);
int  delegate_to_array(DelegateRec *out, int max);  /* bucket order */
int  delegate_max_id_suffix(const char *prefix);

/* Hash table internals for display and analytics */
unsigned delegate_hash_value(const char *id);
int  delegate_bucket_count(void);
int  delegate_bucket_length(int bucket);
int  delegate_bucket_ids(int bucket, char (*ids)[DSA_ID_LEN], int max);
double delegate_load_factor(void);
int  delegate_rehash_count(void);

/* BST operations (keyed by name, then id) */
int  bst_inorder(char (*ids)[DSA_ID_LEN], int max);
int  bst_preorder(char (*ids)[DSA_ID_LEN], int max);
int  bst_postorder(char (*ids)[DSA_ID_LEN], int max);
int  bst_height(void);                /* empty = 0, single node = 1 */
int  bst_node_count(void);
int  bst_min(char *idOut);            /* DSA_ERR_NOT_FOUND if empty */
int  bst_max(char *idOut);
/* Level-order dump for drawing: parent index per node (-1 for root) */
int  bst_level_order(char (*ids)[DSA_ID_LEN], int *parent, int *isLeft, int max);

/* The four searches compared in analytics */
int  delegate_search_hash(const char *id, DelegateRec *out, SearchTrace *t);
int  delegate_search_bst_name(const char *name, DelegateRec *out, SearchTrace *t);
int  delegate_search_linear_id(const char *id, DelegateRec *out, SearchTrace *t);
int  delegate_search_binary_id(const char *id, DelegateRec *out, SearchTrace *t);
/* Linear substring search on name/institution/portfolio; returns matches */
int  delegate_search_text(const char *query, DelegateRec *out, int max, int *comparisons);

int  delegates_save(const char *path);
int  delegates_load(const char *path, int *skipped);

/* ================================================================== */
/* MODULE 3 — Committee roster algorithms (committee_dsa.c)            */
/* Work on arrays the C++ layer builds from the single delegate store. */
/* ================================================================== */
typedef struct {
    char id[DSA_ID_LEN];
    char name[DSA_NAME_LEN];
    char portfolio[DSA_NAME_LEN];
} RosterEntry;

typedef enum { ROSTER_BY_NAME = 0, ROSTER_BY_PORTFOLIO = 1, ROSTER_BY_ID = 2 } RosterKey;

typedef struct { long comparisons; long moves; } SortStats;

/* Insertion sort (stable; rosters are small and often nearly sorted) */
void roster_sort(RosterEntry *a, int n, int key, SortStats *stats);
/* Case-insensitive linear search; index or -1 */
int  roster_find_portfolio(const RosterEntry *a, int n, const char *portfolio,
                           const char *ignoreId);

/* ================================================================== */
/* MODULE 4 — Attendance (attendance_dsa.c)                            */
/* Linked list of session sheets; each sheet is a dynamic array of     */
/* entries that doubles its capacity when full.                        */
/* ================================================================== */
typedef enum { ATT_PRESENT = 0, ATT_ABSENT = 1, ATT_LATE = 2, ATT_CHECKED_IN = 3 } AttendanceStatus;
#define ATT_STATUS_COUNT 4

typedef struct {
    char sessionId[DSA_ID_LEN];
    char delegateId[DSA_ID_LEN];
    int  status;                     /* AttendanceStatus */
    char markedBy[DSA_ID_LEN];
    char markedAt[DSA_STAMP_LEN];
} AttendanceRec;

void att_store_reset(void);
int  att_mark(const AttendanceRec *rec, int *wasUpdate);   /* insert or update: no duplicates */
int  att_find(const char *sessionId, const char *delegateId, AttendanceRec *out, int *comparisons);
int  att_list_session(const char *sessionId, AttendanceRec *out, int max);
int  att_list_delegate(const char *delegateId, AttendanceRec *out, int max);
int  att_session_tally(const char *sessionId, int counts[ATT_STATUS_COUNT]);
int  att_total(void);
int  att_save(const char *path);
int  att_load(const char *path, int *skipped);

/* ================================================================== */
/* MODULE 5 — Speaker list, speaking requests, POIs (speaker_dsa.c)    */
/* ================================================================== */
#define GSL_CAPACITY 64

typedef struct {
    char sessionId[DSA_ID_LEN];
    int  speakingSeconds;            /* time per speech */
    char current[DSA_ID_LEN];        /* "" = nobody speaking */
    long long startedAt;             /* epoch seconds */
    int  queueLength;
} SpeakerState;

typedef struct {
    char sessionId[DSA_ID_LEN];
    char delegateId[DSA_ID_LEN];
    long long startedAt;
    int  seconds;                    /* actual length */
    int  allotted;
} SpeechRec;

typedef struct {
    char sessionId[DSA_ID_LEN];
    char delegateId[DSA_ID_LEN];
    char at[DSA_STAMP_LEN];
} SpeakRequestRec;

typedef enum { POI_PENDING = 0, POI_ACCEPTED = 1, POI_REJECTED = 2, POI_WITHDRAWN = 3 } PoiStatus;
#define POI_STATUS_COUNT 4

typedef struct {
    char id[DSA_ID_LEN];
    char sessionId[DSA_ID_LEN];
    char committeeId[DSA_ID_LEN];
    char delegateId[DSA_ID_LEN];     /* who raised it */
    char targetId[DSA_ID_LEN];       /* the speaker it is addressed to */
    char text[DSA_TEXT_LEN];
    char createdAt[DSA_STAMP_LEN];
    int  status;                     /* PoiStatus */
    char decidedBy[DSA_ID_LEN];
    char reason[DSA_TEXT_LEN];
} PoiRec;

void spk_store_reset(void);
/* General Speakers List: one circular queue per session */
int  spk_state(const char *sessionId, SpeakerState *out);   /* defaults if untouched */
int  spk_set_time(const char *sessionId, int seconds);
int  spk_enqueue(const char *sessionId, const char *delegateId);  /* DUPLICATE / FULL */
int  spk_queue(const char *sessionId, char (*ids)[DSA_ID_LEN], int max);
int  spk_position(const char *sessionId, const char *delegateId); /* 0-based or -1 */
int  spk_remove(const char *sessionId, const char *delegateId);
/* Ends the current speech (logged in history) and dequeues the next
 * speaker. NOT_FOUND if the queue was empty (the speech still ends). */
int  spk_next(const char *sessionId, long long now, char *idOut);
int  spk_finish(const char *sessionId, long long now);
int  speech_list(const char *sessionId, const char *delegateId, SpeechRec *out, int max); /* newest first */
int  speech_count(void);
/* Speaking requests: FIFO queue (linked list with head and tail) */
int  req_push(const SpeakRequestRec *rec);
int  req_pop_front(const char *sessionId, SpeakRequestRec *out);
int  req_remove(const char *sessionId, const char *delegateId);
int  req_list(const char *sessionId, SpeakRequestRec *out, int max);
/* POIs: all POIs in a list, pending ones also in a FIFO queue */
int  poi_insert(const PoiRec *rec);
int  poi_find(const char *id, PoiRec *out);
int  poi_update(const PoiRec *rec);   /* leaving PENDING removes it from the queue */
int  poi_pending(const char *sessionId, PoiRec *out, int max);   /* queue order */
int  poi_list(const char *sessionId, const char *delegateId, PoiRec *out, int max); /* newest first */
int  poi_count(void);
int  poi_max_id_suffix(const char *prefix);
int  speakers_save(const char *statePath, const char *speechPath, const char *requestPath, const char *poiPath);
int  speakers_load(const char *statePath, const char *speechPath, const char *requestPath, const char *poiPath, int *skipped);

/* ================================================================== */
/* MODULE 6 — Motions (motion_dsa.c)                                   */
/* Pending motions: binary min-heap per session (priority queue).      */
/* Chair actions: stack per session, for undo.                         */
/* ================================================================== */
/* Enum order IS the order of precedence: lower value = considered first */
typedef enum {
    MOT_ADJOURN = 0, MOT_SUSPEND = 1, MOT_CLOSE_DEBATE = 2, MOT_UNMODERATED = 3,
    MOT_MODERATED = 4, MOT_INTRODUCE_DRAFT = 5, MOT_SPEAKING_TIME = 6
} MotionType;
#define MOTION_TYPE_COUNT 7

typedef enum {
    MS_PENDING = 0, MS_VOTING = 1, MS_PASSED = 2, MS_FAILED = 3, MS_WITHDRAWN = 4, MS_OUT_OF_ORDER = 5
} MotionStatus;
#define MOTION_STATUS_COUNT 6

typedef struct {
    char id[DSA_ID_LEN];
    char sessionId[DSA_ID_LEN];
    char committeeId[DSA_ID_LEN];
    char proposerId[DSA_ID_LEN];
    int  type;                       /* MotionType */
    char topic[DSA_TEXT_LEN];
    int  totalMinutes;               /* caucuses */
    int  speakingSeconds;            /* moderated caucus / speaking time */
    int  status;                     /* MotionStatus */
    char createdAt[DSA_STAMP_LEN];
    long seq;                        /* arrival order, the final tie-break */
    char voteId[DSA_ID_LEN];
} MotionRec;

typedef struct {
    char sessionId[DSA_ID_LEN];
    char motionId[DSA_ID_LEN];
    int  fromStatus;
    int  toStatus;
    char by[DSA_ID_LEN];
    char at[DSA_STAMP_LEN];
} MotionActionRec;

void motion_store_reset(void);
int  motion_insert(const MotionRec *rec);    /* PENDING motions enter the heap */
int  motion_find(const char *id, MotionRec *out);
int  motion_update(const MotionRec *rec);    /* keeps heap membership in step with status */
int  motion_peek(const char *sessionId, MotionRec *out);
int  motion_pending(const char *sessionId, MotionRec *out, int max);  /* priority order */
int  motion_list(const char *sessionId, MotionRec *out, int max);     /* newest first */
int  motion_heap_size(const char *sessionId);
int  motion_max_id_suffix(const char *prefix);
long motion_next_seq(void);
int  mact_push(const MotionActionRec *a);
int  mact_peek(const char *sessionId, MotionActionRec *out);
int  mact_pop(const char *sessionId, MotionActionRec *out);
int  mact_depth(const char *sessionId);
int  motions_save(const char *motionPath, const char *actionPath);
int  motions_load(const char *motionPath, const char *actionPath, int *skipped);

/* ================================================================== */
/* MODULE 7 — Voting (voting_dsa.c)                                    */
/* Linked list of votes; each holds a dynamic array of ballots.        */
/* ================================================================== */
typedef enum { VOTE_YES = 0, VOTE_NO = 1, VOTE_ABSTAIN = 2 } VoteChoice;
#define VOTE_CHOICE_COUNT 3
typedef enum { VS_OPEN = 0, VS_CLOSED = 1 } VoteState;
typedef enum { MAJ_SIMPLE = 0, MAJ_TWO_THIRDS = 1 } MajorityRule;

typedef struct {
    char id[DSA_ID_LEN];
    char sessionId[DSA_ID_LEN];
    char committeeId[DSA_ID_LEN];
    char subject[DSA_TEXT_LEN];
    char motionId[DSA_ID_LEN];       /* "" if not about a motion */
    int  substantive;                /* 1: abstentions allowed */
    int  majority;                   /* MajorityRule */
    int  state;                      /* VoteState */
    int  yes, no, abstain;           /* filled when closed */
    int  outcome;                    /* -1 open, 1 passed, 0 failed */
    char openedAt[DSA_STAMP_LEN];
    char closedAt[DSA_STAMP_LEN];
} VoteRec;

typedef struct {
    char voteId[DSA_ID_LEN];
    char delegateId[DSA_ID_LEN];
    int  choice;                     /* VoteChoice */
    int  corrections;                /* authorized changes by the EB */
    char castAt[DSA_STAMP_LEN];
} BallotRec;

void vote_store_reset(void);
int  vote_open(const VoteRec *rec);
int  vote_find(const char *id, VoteRec *out);
int  vote_update(const VoteRec *rec);
int  vote_open_for_session(const char *sessionId, VoteRec *out);
int  vote_list(const char *sessionId, VoteRec *out, int max);   /* newest first */
int  vote_delete(const char *id);
int  vote_max_id_suffix(const char *prefix);
int  ballot_cast(const BallotRec *b);                 /* DUPLICATE if already voted */
int  ballot_correct(const char *voteId, const char *delegateId, int choice);
int  ballot_find(const char *voteId, const char *delegateId, BallotRec *out, int *comparisons);
int  ballot_list(const char *voteId, BallotRec *out, int max);
int  vote_tally(const char *voteId, int counts[VOTE_CHOICE_COUNT]);
int  votes_save(const char *votePath, const char *ballotPath);
int  votes_load(const char *votePath, const char *ballotPath, int *skipped);

/* ================================================================== */
/* MODULE 8 — Scoring and marksheets (scoring_dsa.c)                   */
/* Criteria: fixed array kept in display order (insertion sort).       */
/* Marksheets: dynamic array. Revision history: linked list.           */
/* ================================================================== */
#define MAX_CRITERIA 10
#define CRIT_NAME_LEN 41

typedef struct {
    char key[DSA_ID_LEN];
    char name[CRIT_NAME_LEN];
    int  maxMarks;
    int  order;
    int  fromAttendance;     /* 1: prefilled from Module 4 attendance */
} CriterionRec;

typedef enum {
    SHEET_DRAFT = 0, SHEET_SUBMITTED = 1, SHEET_RETURNED = 2, SHEET_APPROVED = 3, SHEET_PUBLISHED = 4
} SheetStatus;
#define SHEET_STATUS_COUNT 5

typedef enum {
    SHEET_ACT_CREATED = 0, SHEET_ACT_SAVED = 1, SHEET_ACT_SUBMITTED = 2, SHEET_ACT_RETURNED = 3,
    SHEET_ACT_APPROVED = 4, SHEET_ACT_PUBLISHED = 5
} SheetAction;
#define SHEET_ACTION_COUNT 6

typedef struct {
    char id[DSA_ID_LEN];
    char delegateId[DSA_ID_LEN];
    char committeeId[DSA_ID_LEN];
    int  criteriaCount;                        /* snapshot of the criteria used */
    char critKey[MAX_CRITERIA][DSA_ID_LEN];
    char critName[MAX_CRITERIA][CRIT_NAME_LEN];
    int  critMax[MAX_CRITERIA];
    int  marks[MAX_CRITERIA];
    int  total, maxTotal;
    int  status;                               /* SheetStatus */
    int  revision;
    char remarks[DSA_TEXT_LEN];                /* EB's comments to the delegate */
    char adminNote[DSA_TEXT_LEN];              /* why it was returned */
    char createdBy[DSA_ID_LEN];
    char updatedAt[DSA_STAMP_LEN];
} MarksheetRec;

typedef struct {
    char marksheetId[DSA_ID_LEN];
    int  revision;
    int  action;                               /* SheetAction */
    char by[DSA_ID_LEN];
    char at[DSA_STAMP_LEN];
    int  total;
    int  marksCount;
    int  marks[MAX_CRITERIA];
    char note[DSA_TEXT_LEN];
} SheetRevisionRec;

void scoring_store_reset(void);
int  criteria_set(const CriterionRec *arr, int n);   /* validates, sorts by order */
int  criteria_get(CriterionRec *out, int max);
int  criteria_count(void);
int  sheet_compute_total(MarksheetRec *m);           /* INVALID if a mark is out of range */
int  sheet_insert(const MarksheetRec *m);
int  sheet_find(const char *id, MarksheetRec *out, int *comparisons);
int  sheet_find_by_delegate(const char *delegateId, MarksheetRec *out);
int  sheet_update(const MarksheetRec *m);
int  sheet_list(const char *committeeId, int status, MarksheetRec *out, int max); /* status -1 = any */
int  sheet_count(void);
int  sheet_max_id_suffix(const char *prefix);
int  rev_add(const SheetRevisionRec *r);
int  rev_list(const char *marksheetId, SheetRevisionRec *out, int max);   /* oldest first */
int  rev_count(void);
int  scoring_save(const char *criteriaPath, const char *sheetPath, const char *revisionPath);
int  scoring_load(const char *criteriaPath, const char *sheetPath, const char *revisionPath, int *skipped);

/* ================================================================== */
/* MODULE 9 — Ranking and awards (awards_dsa.c)                        */
/* Five sorting algorithms on the same array, each counting its work.  */
/* ================================================================== */
typedef struct {
    char delegateId[DSA_ID_LEN];
    char committeeId[DSA_ID_LEN];
    int  percentTenths;      /* score as a percentage x 10 (85.5% = 855) */
    int  tiebreakTenths;     /* tie-break criterion as a percentage x 10 */
    int  attendanceTenths;   /* attendance percentage x 10 */
} RankEntry;

typedef enum {
    SORT_BUBBLE = 0, SORT_SELECTION = 1, SORT_INSERTION = 2, SORT_MERGE = 3, SORT_QUICK = 4
} SortAlgorithm;
#define SORT_ALGORITHM_COUNT 5

/* < 0 if a ranks above b. Order: score, tie-break criterion, attendance,
 * then Delegate ID (a total order, so every algorithm gives one result). */
int  rank_compare(const RankEntry *a, const RankEntry *b);
/* Sorts best first. stats->moves counts swaps (bubble, selection, quick)
 * or element moves (insertion, merge). */
int  rank_sort(RankEntry *a, int n, int algorithm, SortStats *stats);
const char *sort_algorithm_name(int algorithm);

#define MAX_AWARDS 8
#define AWARD_NAME_LEN 41
typedef struct {
    char name[AWARD_NAME_LEN];
    int  positions;          /* how many delegates can receive it */
    int  minPercent;         /* minimum score to qualify */
} AwardRule;

void awards_store_reset(void);
int  awards_set(const AwardRule *rules, int n, const char *tiebreakKey);
int  awards_get(AwardRule *out, int max);
int  awards_count(void);
void awards_tiebreak(char *keyOut);
int  awards_save(const char *path);
int  awards_load(const char *path, int *skipped);

/* ================================================================== */
/* MODULE 11 — Reports: statistics, CSV, announcements (reports_dsa.c) */
/* ================================================================== */
typedef struct {
    int  count;
    int  min, max;
    long sum;
    int  meanTenths;       /* x 10 */
    int  medianTenths;     /* x 10 */
    int  stddevTenths;     /* population standard deviation x 10 */
} StatSummary;

/* All values are integers (e.g. percentages x 10). The median uses an
 * insertion-sorted copy; the square root is integer Newton's method. */
int  stats_summary(const int *values, int n, StatSummary *out);
/* Counts values into nb buckets of `width` starting at `lo`; values at or
 * above the top go in the last bucket, below `lo` in the first. */
int  stats_histogram(const int *values, int n, int lo, int width, int *buckets, int nb);
/* RFC 4180: quote a field if it contains , " CR or LF; double inner quotes.
 * Returns the length written, or -1 if `cap` is too small. */
int  csv_escape(const char *in, char *out, size_t cap);

typedef enum { AUD_ALL = 0, AUD_DELEGATES = 1, AUD_EB = 2, AUD_COMMITTEE = 3 } AnnouncementAudience;
#define ANN_TITLE_LEN 101
#define ANN_BODY_LEN 601
typedef struct {
    char id[DSA_ID_LEN];
    char title[ANN_TITLE_LEN];
    char body[ANN_BODY_LEN];
    int  audience;
    char committeeId[DSA_ID_LEN];   /* for AUD_COMMITTEE */
    char author[DSA_ID_LEN];
    char at[DSA_STAMP_LEN];
    int  pinned;
} AnnouncementRec;

void ann_store_reset(void);
int  ann_insert(const AnnouncementRec *a);     /* newest first; pinned shown first by C++ */
int  ann_delete(const char *id);
int  ann_find(const char *id, AnnouncementRec *out);
int  ann_list(AnnouncementRec *out, int max);
int  ann_count(void);
int  ann_max_id_suffix(const char *prefix);
int  ann_save(const char *path);
int  ann_load(const char *path, int *skipped);

#ifdef __cplusplus
}
#endif

#endif /* MUNSPHERE_DSA_API_H */
