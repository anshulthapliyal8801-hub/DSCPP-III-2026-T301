// MUNSphere — Shared/RoleManager.cpp
#include "RoleManager.h"

#include <cctype>

#include "dsa_api.h"

namespace mun {

namespace {
struct PermInfo {
    int bit;
    const char* key;
    const char* label;
};
const PermInfo kPerms[] = {
    {perm::VIEW, "view", "View committee, delegates and sessions"},
    {perm::MANAGE_SESSIONS, "manage_sessions", "Create, edit and delete sessions"},
    {perm::RUN_SESSIONS, "run_sessions", "Activate, pause and complete sessions"},
    {perm::SPEAKERS, "speakers", "Run the speaker list and timer"},
    {perm::POI, "poi", "Accept or reject points of information"},
    {perm::MOTIONS, "motions", "Manage motions"},
    {perm::VOTING, "voting", "Run voting"},
    {perm::ATTENDANCE, "attendance", "Mark attendance"},
    {perm::EVALUATE, "evaluate", "Evaluate delegates and write marksheets"},
    {perm::REPORTS, "reports", "View committee reports"},
};
}  // namespace

bool AuthContext::isAdmin() const { return role == ROLE_ADMIN; }
bool AuthContext::isEb() const { return role == ROLE_EB; }
bool AuthContext::isDelegate() const { return role == ROLE_DELEGATE; }

std::string RoleManager::roleKey(int role) {
    switch (role) {
    case ROLE_ADMIN: return "admin";
    case ROLE_EB: return "eb";
    case ROLE_DELEGATE: return "delegate";
    default: return "unknown";
    }
}

std::string RoleManager::roleTitle(int role) {
    switch (role) {
    case ROLE_ADMIN: return "Admin";
    case ROLE_EB: return "Executive Board";
    case ROLE_DELEGATE: return "Delegate";
    default: return "Unknown";
    }
}

std::string RoleManager::ebRoleName(int ebRole) {
    switch (ebRole) {
    case EB_CHAIRPERSON: return "Chairperson";
    case EB_MODERATOR: return "Moderator";
    case EB_SCRIBE: return "Scribe";
    default: return "Unknown";
    }
}

int RoleManager::parseEbRole(const std::string& s) {
    for (int r = 0; r < EB_ROLE_COUNT; ++r) {
        std::string name = ebRoleName(r);
        std::string lower;
        for (char c : name) lower += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        if (s == name || s == lower) return r;
    }
    throw ApiError(400, "VALIDATION", "EB role must be Chairperson, Moderator or Scribe.");
}

Json RoleManager::permissionCatalog() {
    Json arr = Json::array();
    for (const PermInfo& p : kPerms) {
        Json j = Json::object();
        j.set("key", p.key).set("label", p.label).set("bit", p.bit);
        arr.push(j);
    }
    return arr;
}

Json RoleManager::permissionsToJson(int mask) {
    Json arr = Json::array();
    for (const PermInfo& p : kPerms)
        if (mask & p.bit) arr.push(p.key);
    return arr;
}

int RoleManager::parsePermissions(const Json& arr) {
    if (!arr.isArray())
        throw ApiError(400, "VALIDATION", "Permissions must be a list of permission keys.");
    int mask = 0;
    for (const Json& item : arr.asArray()) {
        if (!item.isString())
            throw ApiError(400, "VALIDATION", "Each permission must be a text key.");
        bool found = false;
        for (const PermInfo& p : kPerms)
            if (item.asString() == p.key) { mask |= p.bit; found = true; }
        if (!found)
            throw ApiError(400, "VALIDATION", "Unknown permission '" + item.asString() + "'.");
    }
    return mask | perm::VIEW;  // an EB member can always see their own committee
}

void RoleManager::requireAdmin(const AuthContext& ctx) {
    if (!ctx.isAdmin())
        throw ApiError(403, "FORBIDDEN", "Only an Admin can do this.");
}

void RoleManager::requireDelegate(const AuthContext& ctx) {
    if (!ctx.isDelegate())
        throw ApiError(403, "FORBIDDEN", "This is only available to delegates.");
}

void RoleManager::requireEb(const AuthContext& ctx) {
    if (!ctx.isEb())
        throw ApiError(403, "FORBIDDEN", "This is only available to Executive Board members.");
}

bool RoleManager::canCommittee(const AuthContext& ctx, const std::string& committeeId,
                               int permission) {
    if (ctx.isAdmin()) return true;
    if (!ctx.isEb()) return false;
    return ctx.committeeId == committeeId && (ctx.permissions & permission) == permission;
}

void RoleManager::requireCommittee(const AuthContext& ctx, const std::string& committeeId,
                                   int permission) {
    if (canCommittee(ctx, committeeId, permission)) return;
    if (ctx.isEb() && ctx.committeeId != committeeId)
        throw ApiError(403, "FORBIDDEN", "You can only manage your assigned committee.");
    if (ctx.isEb())
        throw ApiError(403, "FORBIDDEN", "Your EB role doesn't include this permission.");
    throw ApiError(403, "FORBIDDEN", "You don't have access to this committee's operations.");
}

}  // namespace mun
