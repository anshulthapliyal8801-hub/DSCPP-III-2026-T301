// MUNSphere — Shared/RoleManager.h
// Who may do what. Every protected API handler calls one of these checks
// on the server; the browser is never trusted to decide.
#pragma once

#include <string>

#include "Common.h"

namespace mun {

// Permission bits stored in EbRec.permissions.
namespace perm {
enum : int {
    VIEW = 1 << 0,             // committee, delegates, sessions
    MANAGE_SESSIONS = 1 << 1,  // create, edit, delete sessions
    RUN_SESSIONS = 1 << 2,     // activate, pause, complete
    SPEAKERS = 1 << 3,         // speaker list and timer
    POI = 1 << 4,              // accept or reject POIs
    MOTIONS = 1 << 5,
    VOTING = 1 << 6,
    ATTENDANCE = 1 << 7,
    EVALUATE = 1 << 8,         // marksheets
    REPORTS = 1 << 9,
    ALL = (1 << 10) - 1
};
}  // namespace perm

// The signed-in user, built by Auth::require() from the token and the
// stored account on EVERY request (never from data the browser sends).
struct AuthContext {
    std::string accountId;
    int role = -1;               // AccountRole
    std::string name;
    bool mustChangePassword = false;
    // EB only
    std::string committeeId;
    int ebRole = -1;
    int permissions = 0;

    bool isAdmin() const;
    bool isEb() const;
    bool isDelegate() const;
};

class RoleManager {
public:
    static std::string roleKey(int role);        // "admin" | "eb" | "delegate"
    static std::string roleTitle(int role);      // "Admin" | "Executive Board" | "Delegate"
    static std::string ebRoleName(int ebRole);   // "Chairperson" | ...
    static int parseEbRole(const std::string& s);  // throws ApiError(400)

    static Json permissionCatalog();             // [{key,label,bit}]
    static Json permissionsToJson(int mask);     // ["view","run_sessions",...]
    static int parsePermissions(const Json& arr);  // throws ApiError(400)

    // Throw ApiError(403) when not allowed.
    static void requireAdmin(const AuthContext& ctx);
    static void requireDelegate(const AuthContext& ctx);
    static void requireEb(const AuthContext& ctx);
    // Admin always passes. An EB member passes only for their own
    // committee AND when they hold the permission. Delegates never pass.
    static void requireCommittee(const AuthContext& ctx, const std::string& committeeId,
                                 int permission);
    static bool canCommittee(const AuthContext& ctx, const std::string& committeeId,
                             int permission);
};

}  // namespace mun
