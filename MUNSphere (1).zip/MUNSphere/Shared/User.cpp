// MUNSphere — Shared/User.cpp
#include "User.h"

#include "RoleManager.h"

namespace mun {

User::User(std::string id, int role, std::string name) : Entity(std::move(id)), role_(role) {
    if (role < 0 || role >= ROLE_COUNT) throw ApiError(400, "VALIDATION", "Unknown account role.");
    setName(name);
}

User User::fromRecord(const AccountRec& r) {
    // Start from a valid object, then copy stored fields in exactly (reading never throws).
    User u(r.id, r.role >= 0 && r.role < ROLE_COUNT ? r.role : ROLE_DELEGATE, "placeholder");
    u.role_ = r.role;
    u.name_ = r.name;
    u.passHash_ = r.passHash;
    u.active_ = r.active != 0;
    u.mustChange_ = r.mustChangePassword != 0;
    u.resetRequested_ = r.resetRequested != 0;
    u.createdAt_ = r.createdAt;
    return u;
}

AccountRec User::toRecord() const {
    AccountRec r{};
    pers_copy_field(r.id, id_.c_str(), DSA_ID_LEN);
    r.role = role_;
    pers_copy_field(r.name, name_.c_str(), DSA_NAME_LEN);
    pers_copy_field(r.passHash, passHash_.c_str(), DSA_PASS_LEN);
    r.active = active_ ? 1 : 0;
    r.mustChangePassword = mustChange_ ? 1 : 0;
    r.resetRequested = resetRequested_ ? 1 : 0;
    pers_copy_field(r.createdAt, createdAt_.c_str(), DSA_STAMP_LEN);
    return r;
}

void User::setName(const std::string& name) {
    std::string s = validate::trim(name);
    if (s.size() < 2) throw ApiError(400, "VALIDATION", "Name must be at least 2 characters.");
    if (s.size() > DSA_NAME_LEN - 1)
        throw ApiError(400, "VALIDATION", "Name is too long (max 100 characters).");
    name_ = s;
}

Json User::toJson() const {
    Json j = Json::object();
    j.set("id", id_)
        .set("role", RoleManager::roleKey(role_))
        .set("roleTitle", RoleManager::roleTitle(role_))
        .set("name", name_)
        .set("active", active_)
        .set("mustChangePassword", mustChange_)
        .set("resetRequested", resetRequested_)
        .set("createdAt", createdAt_);
    return j;
}

const char* User::idPrefix(int role) {
    switch (role) {
    case ROLE_ADMIN: return "ADM";
    case ROLE_EB: return "EB";
    default: return "D";
    }
}

}  // namespace mun
