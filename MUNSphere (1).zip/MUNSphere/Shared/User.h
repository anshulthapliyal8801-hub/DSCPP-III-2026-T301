// MUNSphere — Shared/User.h
// A login account (Admin, EB member or Delegate). The person behind the
// account is modelled separately (Person -> Delegate / EBMember), which
// HAS a User: composition for the account, inheritance for the person.
#pragma once

#include <string>

#include "Common.h"
#include "dsa_api.h"

namespace mun {

class User : public Entity {
public:
    User(std::string id, int role, std::string name);

    static User fromRecord(const AccountRec& r);
    AccountRec toRecord() const;

    int role() const { return role_; }
    const std::string& name() const { return name_; }
    bool active() const { return active_; }
    bool mustChangePassword() const { return mustChange_; }
    bool resetRequested() const { return resetRequested_; }
    const std::string& createdAt() const { return createdAt_; }
    const std::string& passHash() const { return passHash_; }

    void setName(const std::string& name);
    void setActive(bool v) { active_ = v; }
    void setMustChangePassword(bool v) { mustChange_ = v; }
    void setResetRequested(bool v) { resetRequested_ = v; }
    void setPassHash(const std::string& h) { passHash_ = h; }
    void setCreatedAt(const std::string& t) { createdAt_ = t; }

    // Never includes the password hash.
    Json toJson() const override;
    std::string entityName() const override { return "Account"; }

    // ID prefixes: ADM001, EB001, D001
    static const char* idPrefix(int role);

private:
    int role_;
    std::string name_;
    std::string passHash_;
    bool active_ = true;
    bool mustChange_ = false;
    bool resetRequested_ = false;
    std::string createdAt_;
};

}  // namespace mun
