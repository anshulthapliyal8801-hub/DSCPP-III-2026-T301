// MUNSphere — live.js
// Shared pieces for live session pages: polling that stops when you leave
// the page, a speaking clock synchronised to the server, and small renderers.
"use strict";

const Live = {
  offsetMs: 0,      // server clock minus browser clock
  clockTimer: null,

  // Calls fn now and every `ms`; stops automatically when the section changes.
  poll(fn, ms) {
    let stopped = false;
    let busy = false;
    const run = async () => {
      if (stopped || busy || document.hidden) return;
      busy = true;
      try { await fn(); } catch (err) { if (err.status !== 401) UI.toast(err.message, "error"); }
      busy = false;
    };
    run();
    const id = setInterval(run, ms);
    this.clockTimer = this.clockTimer || setInterval(() => this.tick(), 250);
    Shell.cleanup = () => {
      stopped = true;
      clearInterval(id);
      clearInterval(this.clockTimer);
      this.clockTimer = null;
    };
  },

  sync(serverNow) { this.offsetMs = serverNow * 1000 - Date.now(); },
  now() { return (Date.now() + this.offsetMs) / 1000; },

  fmt(sec) {
    const neg = sec < 0;
    const s = Math.abs(Math.round(sec));
    return `${neg ? "+" : ""}${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  },

  // A countdown that tick() keeps current. Over time shows as +0:12.
  clock(startedAt, allotted) {
    if (!startedAt) return `<div class="clock idle">${this.fmt(allotted)}</div>`;
    return `<div class="clock" data-started="${startedAt}" data-allotted="${allotted}" role="timer" aria-live="off">–</div>`;
  },

  tick() {
    document.querySelectorAll(".clock[data-started]").forEach((el) => {
      const left = Number(el.dataset.allotted) - (this.now() - Number(el.dataset.started));
      el.textContent = this.fmt(left);
      el.classList.toggle("warn", left <= 10 && left > 0);
      el.classList.toggle("over", left <= 0);
    });
  },

  who(d) { return d ? `${UI.esc(d.portfolio || d.id)}` : ""; },
  whoFull(d) { return d ? `<strong>${UI.esc(d.portfolio)}</strong> <span class="sub-inline">${UI.esc(d.name)}</span>` : ""; },

  floorPlacard(sp) {
    if (!sp.current) {
      return `<div class="floor-empty"><p>Nobody has the floor.</p>${this.clock(0, sp.speakingSeconds)}
        <p class="sub">Speaking time ${sp.speakingSeconds} s per speaker.</p></div>`;
    }
    return `<article class="placard floor-placard">
      <div class="live">Has the floor</div>
      <div class="abbr">${UI.esc(sp.current.portfolio)}</div>
      <div class="title">${UI.esc(sp.current.name)}</div>
      ${this.clock(sp.startedAt, sp.speakingSeconds)}
    </article>`;
  },

  tallyBars(v) {
    if (!v.tally) return "";
    const total = Math.max(1, v.tally.yes + v.tally.no + v.tally.abstain);
    const bar = (k, label) => `<div class="tally-row"><span>${label}</span>
      <div class="tally-bar"><span class="t-${k}" data-w="${Math.round((v.tally[k] / total) * 100)}"></span></div>
      <b>${v.tally[k]}</b></div>`;
    return `<div class="tally">${bar("yes", "Yes")}${bar("no", "No")}${v.kind === "substantive" ? bar("abstain", "Abstain") : ""}</div>`;
  },

  // CSP forbids inline styles in markup, so bar widths are set here.
  sizeBars(root) {
    root.querySelectorAll(".tally-bar span[data-w]").forEach((s) => { s.style.width = `${s.dataset.w}%`; });
  },

  motionLine(m) {
    return `<span class="prec" title="Order of precedence">${m.precedence}</span>
      <span><strong>${UI.esc(m.description)}</strong>
      <span class="sub">Proposed by ${UI.esc(m.proposer ? m.proposer.portfolio : "")}</span></span>`;
  },

  resultLine(v) {
    return `<li><span class="badge ${v.outcome === "passed" ? "badge-completed" : "badge-danger"}">${v.outcome === "passed" ? "Passed" : "Failed"}</span>
      ${UI.esc(v.subject)} <span class="sub-inline">${v.tally.yes} yes, ${v.tally.no} no${v.kind === "substantive" ? `, ${v.tally.abstain} abstain` : ""}</span></li>`;
  },
};

// Fields for proposing a motion. The server checks which ones each type needs.
function motionFields(delegateOptions) {
  const f = [];
  if (delegateOptions) f.push({ name: "delegateId", label: "Proposed by", type: "select", required: true, options: delegateOptions });
  f.push(
    { name: "type", label: "Motion", type: "select", required: true, value: "moderated", options: [
      { value: "adjourn", label: "1. Adjourn the meeting" },
      { value: "suspend", label: "2. Suspend the meeting" },
      { value: "close_debate", label: "3. Close debate (two-thirds)" },
      { value: "unmoderated", label: "4. Unmoderated caucus: needs total minutes" },
      { value: "moderated", label: "5. Moderated caucus: needs topic, minutes, seconds each" },
      { value: "introduce_draft", label: "6. Introduce a draft resolution: needs topic" },
      { value: "speaking_time", label: "7. Set the speaking time: needs seconds" }] },
    { name: "topic", label: "Topic or draft name", maxlength: 300, omitIfEmpty: true },
    { name: "totalMinutes", label: "Total minutes", type: "number", min: 1, max: 60, half: true, omitIfEmpty: true },
    { name: "speakingSeconds", label: "Seconds per speaker", type: "number", min: 10, max: 300, half: true, omitIfEmpty: true });
  return f;
}

// Renders a report returned by /api/reports/:key (table, summary, chart).
function renderReport(r) {
  const esc = UI.esc;
  const sum = r.summary.length ? `<dl class="report-summary">${r.summary.map((x) =>
    `<div><dt>${esc(x.label)}</dt><dd>${esc(x.value)}</dd></div>`).join("")}</dl>` : "";
  let chart = "";
  if (r.chart && r.chart.values) {
    const max = Math.max(1, ...r.chart.values);
    chart = `<div class="histogram" role="img" aria-label="${esc(r.chart.title)}">${r.chart.values.map((v, i) => `
      <div class="hist-col"><span class="hist-n">${v}</span><div class="hist-bar"><span data-h="${Math.round((v / max) * 100)}"></span></div>
      <span class="hist-label">${esc(r.chart.labels[i])}</span></div>`).join("")}</div><p class="table-note">${esc(r.chart.title)}</p>`;
  }
  const numeric = (v) => /^[0-9.\-/ =]+$/.test(v);
  const table = r.rows.length ? `<div class="table-wrap"><table><thead><tr>${r.columns.map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead>
    <tbody>${r.rows.map((row) => `<tr>${row.map((v) => `<td class="${numeric(v) ? "num" : ""}">${esc(v)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`
    : `<div class="empty"><p>No rows for this scope yet.</p></div>`;
  return `${sum}${chart}${table}<p class="table-note">${esc(r.scope)}. Generated ${esc(r.generatedAt)}.</p>`;
}
function sizeHistogram(root) {
  root.querySelectorAll(".hist-bar span[data-h]").forEach((s) => { s.style.height = `${s.dataset.h}%`; });
}

function announcementsHtml(list) {
  if (!list.length) return "";
  return `<section class="panel"><div class="panel-head"><h2>Announcements</h2></div><div class="panel-body">${list.slice(0, 5).map((a) => `
    <article class="announcement${a.pinned ? " pinned" : ""}"><header><h3>${UI.esc(a.title)}</h3><span class="sub">${UI.esc(a.at)}</span></header>
    <p>${UI.esc(a.body)}</p></article>`).join("")}</div></section>`;
}
