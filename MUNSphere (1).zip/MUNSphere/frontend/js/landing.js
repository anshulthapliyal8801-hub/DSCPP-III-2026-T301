// MUNSphere — landing.js
// Shows the committees that are in session, refreshed every 20 seconds.
"use strict";

const liveBox = document.getElementById("live");

async function refreshLive() {
  try {
    const sessions = await Api.get("/api/public/live");
    if (sessions.length === 0) {
      liveBox.innerHTML = `<p class="sub">No committee is in session right now.</p>`;
      return;
    }
    liveBox.innerHTML = `<div class="placards">${sessions.map((s) => `
      <article class="placard">
        <div class="live">In session</div>
        <div class="abbr">${UI.esc(s.committee ? s.committee.abbreviation : "")}</div>
        <div class="title">${UI.esc(s.title)}</div>
        <div class="meta">${UI.esc(s.committee ? s.committee.name : "")}</div>
        <div class="meta">${UI.esc(s.startTime)} to ${UI.esc(s.endTime)}</div>
      </article>`).join("")}</div>`;
  } catch (err) {
    liveBox.innerHTML = `<div class="banner">${UI.esc(err.message)}</div>`;
  }
}

refreshLive();
setInterval(refreshLive, 20000);
