// MUNSphere — shell.js
// The frame shared by the three dashboards: sidebar navigation, signed-in
// user, hash routing (#section), and an error banner.
"use strict";

const Shell = {
  sections: [],
  renderers: {},
  view: null,
  banner: null,
  user: null,
  cleanup: null,   // set by a section that polls; called before the next render

  async start({ role, sections, renderers, footLinks = [] }) {
    this.sections = sections;
    this.renderers = renderers;
    this.user = await Auth.requireRole(role);
    const u = this.user;
    const subtitle = u.role === "eb" && u.eb && u.eb.committeeAbbreviation
      ? `${u.eb.ebRole}, ${u.eb.committeeAbbreviation}` : u.roleTitle;

    document.body.innerHTML = `
      <div class="shell">
        <aside class="sidebar">
          <a class="brand" href="/"><img src="/assets/logo.svg" alt=""><span>MUNSphere</span></a>
          <nav class="nav" aria-label="Sections">
            ${sections.map((s) => s.heading
              ? `<span class="nav-heading">${UI.esc(s.heading)}</span>`
              : `<a href="#${s.key}" data-section="${s.key}">${UI.esc(s.label)}</a>`).join("")}
          </nav>
          <div class="sidebar-foot">
            ${footLinks.map((l) => `<a href="${l.href}">${UI.esc(l.label)}</a>`).join("")}
            <div class="who">
              <strong>${UI.esc(u.name)}</strong>
              <span>${UI.esc(u.id)}, ${UI.esc(subtitle)}</span>
            </div>
            <button type="button" class="link-btn" data-shell="password">Change password</button>
            <button type="button" class="link-btn" data-shell="logout">Log out</button>
          </div>
        </aside>
        <main class="main" id="main" tabindex="-1">
          <div class="banner" id="banner" hidden></div>
          <div id="view"></div>
        </main>
      </div>`;
    this.view = document.getElementById("view");
    this.banner = document.getElementById("banner");
    document.querySelector(".sidebar").addEventListener("click", (e) => {
      const b = e.target.closest("[data-shell]");
      if (!b) return;
      if (b.dataset.shell === "logout") Auth.logout();
      else Auth.changePassword(false);
    });
    window.addEventListener("hashchange", () => this.render());
    await this.render();
    return u;
  },

  current() {
    const h = location.hash.slice(1);
    const pages = this.sections.filter((s) => s.key);
    return pages.some((s) => s.key === h) ? h : pages[0].key;
  },

  async render() {
    const key = this.current();
    document.querySelectorAll(".nav a").forEach((a) => {
      if (a.dataset.section === key) a.setAttribute("aria-current", "page");
      else a.removeAttribute("aria-current");
    });
    if (this.cleanup) { this.cleanup(); this.cleanup = null; }
    try {
      this.banner.hidden = true;
      await this.renderers[key](this.view);
    } catch (err) {
      this.banner.textContent = err.message;
      this.banner.hidden = false;
    }
  },

  // Runs a button action, shows any error as a toast, then re-renders.
  async act(fn) {
    try {
      await fn();
    } catch (err) {
      UI.toast(err.message, "error");
    }
    await this.render();
  },
};
