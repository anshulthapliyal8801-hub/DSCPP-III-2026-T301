// MUNSphere — ui.js
// Shared interface helpers: HTML escaping, toasts, confirmation dialogs
// and generated form dialogs. Every piece of data shown with innerHTML
// passes through UI.esc() first, so names typed by users can never inject
// markup or scripts.
"use strict";

const UI = {
  esc(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  },

  toast(message, kind = "info") {
    let box = document.querySelector(".toasts");
    if (!box) {
      box = document.createElement("div");
      box.className = "toasts";
      box.setAttribute("role", "status");
      box.setAttribute("aria-live", "polite");
      document.body.appendChild(box);
    }
    const t = document.createElement("div");
    t.className = kind === "error" ? "toast toast-error" : "toast";
    t.textContent = message;
    box.appendChild(t);
    setTimeout(() => t.remove(), kind === "error" ? 6000 : 3500);
  },

  // Resolves true if the user confirms, false otherwise.
  confirm({ title, message, confirmLabel = "Confirm", danger = false }) {
    return new Promise((resolve) => {
      const d = document.createElement("dialog");
      d.innerHTML = `
        <div class="dialog-body">
          <h2>${UI.esc(title)}</h2>
          <p>${UI.esc(message)}</p>
          <div class="dialog-actions">
            <button type="button" class="btn" data-choice="no">Cancel</button>
            <button type="button" class="btn ${danger ? "btn-danger" : "btn-primary"}" data-choice="yes">${UI.esc(confirmLabel)}</button>
          </div>
        </div>`;
      let answer = false;
      d.addEventListener("click", (e) => {
        const choice = e.target.closest("[data-choice]");
        if (!choice) return;
        answer = choice.dataset.choice === "yes";
        d.close();
      });
      d.addEventListener("close", () => { d.remove(); resolve(answer); });
      document.body.appendChild(d);
      d.showModal();
      d.querySelector('[data-choice="no"]').focus();
    });
  },

  // fields: [{ name, label, type, value, required, options:[{value,label}],
  //            min, max, maxlength, hint, omitIfEmpty, half }]
  // onSubmit(values) may throw an ApiError; its message is shown in the form.
  form({ title, intro = "", fields, submitLabel = "Save", onSubmit, dismissible = true }) {
    const d = document.createElement("dialog");
    const renderField = (f) => {
      const id = `f-${f.name}`;
      const req = f.required ? "required" : "";
      const val = UI.esc(f.value ?? "");
      const attrs = [
        f.maxlength ? `maxlength="${f.maxlength}"` : "",
        f.min !== undefined ? `min="${f.min}"` : "",
        f.max !== undefined ? `max="${f.max}"` : "",
      ].join(" ");
      let control;
      if (f.type === "textarea") {
        control = `<textarea id="${id}" name="${f.name}" ${req} ${attrs}>${val}</textarea>`;
      } else if (f.type === "checkboxes") {
        const chosen = new Set(f.value || []);
        const boxes = (f.options || []).map((o) => `
          <label class="check"><input type="checkbox" name="${f.name}" value="${UI.esc(o.value)}"
            ${chosen.has(o.value) ? "checked" : ""} ${o.locked ? "disabled checked" : ""}>
            <span>${UI.esc(o.label)}</span></label>`).join("");
        return `<fieldset class="field"><legend>${UI.esc(f.label)}</legend>${boxes}${f.hint ? `<span class="hint">${UI.esc(f.hint)}</span>` : ""}</fieldset>`;
      } else if (f.type === "select") {
        const opts = (f.options || []).map((o) =>
          `<option value="${UI.esc(o.value)}" ${String(o.value) === String(f.value ?? "") ? "selected" : ""}>${UI.esc(o.label)}</option>`).join("");
        control = `<select id="${id}" name="${f.name}" ${req}>${opts}</select>`;
      } else {
        control = `<input id="${id}" name="${f.name}" type="${f.type || "text"}" value="${val}" ${req} ${attrs}>`;
      }
      const hint = f.hint ? `<span class="hint">${UI.esc(f.hint)}</span>` : "";
      return `<div class="field"><label for="${id}">${UI.esc(f.label)}</label>${control}${hint}</div>`;
    };

    // Pair consecutive "half" fields side by side.
    let body = "";
    for (let i = 0; i < fields.length; i++) {
      if (fields[i].half && fields[i + 1] && fields[i + 1].half) {
        body += `<div class="field-row">${renderField(fields[i])}${renderField(fields[i + 1])}</div>`;
        i++;
      } else {
        body += renderField(fields[i]);
      }
    }

    d.innerHTML = `
      <form method="dialog" novalidate>
        <h2>${UI.esc(title)}</h2>
        ${intro ? `<p class="sub">${UI.esc(intro)}</p>` : ""}
        <div class="form-error" hidden></div>
        ${body}
        <div class="dialog-actions">
          ${dismissible ? `<button type="button" class="btn" data-cancel>Cancel</button>` : ""}
          <button type="submit" class="btn btn-primary">${UI.esc(submitLabel)}</button>
        </div>
      </form>`;

    const form = d.querySelector("form");
    const errorBox = d.querySelector(".form-error");
    const submit = d.querySelector('button[type="submit"]');

    const cancel = d.querySelector("[data-cancel]");
    if (cancel) cancel.addEventListener("click", () => d.close());
    if (!dismissible) d.addEventListener("cancel", (e) => e.preventDefault());  // Esc does nothing
    d.addEventListener("close", () => d.remove());

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      errorBox.hidden = true;
      if (!form.checkValidity()) {
        const first = form.querySelector(":invalid");
        const label = form.querySelector(`label[for="${first.id}"]`);
        errorBox.textContent = `Check “${label ? label.textContent : first.name}”: ${first.validationMessage}`;
        errorBox.hidden = false;
        first.focus();
        return;
      }
      const values = {};
      for (const f of fields) {
        if (f.type === "checkboxes") {
          values[f.name] = [...form.querySelectorAll(`input[name="${f.name}"]:checked`)].map((c) => c.value);
          continue;
        }
        const el = form.elements[f.name];
        let v = el.value;
        if (f.type !== "textarea") v = v.trim();
        if (f.omitIfEmpty && v === "") continue;
        values[f.name] = f.type === "number" ? Number(v) : v;
      }
      submit.disabled = true;
      try {
        await onSubmit(values);
        d.close();
      } catch (err) {
        errorBox.textContent = err.message;
        errorBox.hidden = false;
      } finally {
        submit.disabled = false;
      }
    });

    document.body.appendChild(d);
    d.showModal();
    const firstInput = d.querySelector("input, select, textarea");
    if (firstInput) firstInput.focus();
  },

  // Shows a new ID and temporary password once, with copy buttons.
  credentials({ title, message, id, password }) {
    const d = document.createElement("dialog");
    d.innerHTML = `
      <div class="dialog-body">
        <h2>${UI.esc(title)}</h2>
        <p>${UI.esc(message)}</p>
        <dl class="creds">
          <dt>ID</dt><dd><code>${UI.esc(id)}</code><button type="button" class="btn btn-small" data-copy="${UI.esc(id)}">Copy</button></dd>
          ${password ? `<dt>Temporary password</dt><dd><code>${UI.esc(password)}</code><button type="button" class="btn btn-small" data-copy="${UI.esc(password)}">Copy</button></dd>` : ""}
        </dl>
        ${password ? `<p class="sub">This password is shown only now. They must choose a new one at first login.</p>` : ""}
        <div class="dialog-actions"><button type="button" class="btn btn-primary" data-done>Done</button></div>
      </div>`;
    d.addEventListener("click", async (e) => {
      const copy = e.target.closest("[data-copy]");
      if (copy) {
        try { await navigator.clipboard.writeText(copy.dataset.copy); copy.textContent = "Copied"; }
        catch (err) { copy.textContent = "Select and copy"; }
      }
      if (e.target.closest("[data-done]")) d.close();
    });
    d.addEventListener("close", () => d.remove());
    document.body.appendChild(d);
    d.showModal();
  },

  formatDate(iso) {
    if (!iso) return "";
    const [y, m, d] = iso.split("-").map(Number);
    return new Date(y, m - 1, d).toLocaleDateString(undefined, {
      day: "numeric", month: "short", year: "numeric",
    });
  },
};
