// MUNSphere — delegate.js
// Delegate portal: status and placement, conference registration with
// committee preferences, committee sessions, profile and sign-ins.
"use strict";

const esc = UI.esc;
let me = null;

async function loadMe() { me = await Api.get("/api/delegate/me"); return me; }

// ------------------------------------------------------------- overview
async function renderHome(view) {
  await loadMe();
  let body;
  if (me.committeeId && me.committee) {
    body = `
      <div class="placards"><article class="placard placard-own">
        <div class="live">Your placard</div>
        <div class="abbr">${esc(me.portfolio)}</div>
        <div class="title">${esc(me.committee.name)} (${esc(me.committee.abbreviation)})</div>
        <div class="meta">${esc(me.conference ? me.conference.name : "")}</div>
        <div class="meta">${esc(me.committee.agenda)}</div>
      </article></div>
      <p class="next-step">You represent <strong>${esc(me.portfolio)}</strong>. Follow your committee on the
        <a href="#live">live session</a> page, or see the <a href="#sessions">schedule</a>.</p>`;
  } else if (me.status === "approved") {
    body = `<div class="status-card"><h2>Registration approved</h2>
      <p>The conference team is placing you in a committee and choosing your portfolio. You’ll see it here.</p>
      ${prefsList()}</div>`;
  } else if (me.status === "pending") {
    body = `<div class="status-card"><h2>Registration under review</h2>
      <p>You applied to ${esc(me.conference ? me.conference.name : me.conferenceId)} on ${esc(me.registeredAt.slice(0, 10))}.</p>
      ${prefsList()}<a class="btn" href="#register">Change preferences</a></div>`;
  } else if (me.status === "rejected") {
    body = `<div class="status-card status-bad"><h2>Registration not accepted</h2>
      <p>Reason given: ${esc(me.note)}</p>
      <a class="btn btn-primary" href="#register">Apply again</a></div>`;
  } else {
    body = `<div class="status-card"><h2>You’re not registered for a conference yet</h2>
      <p>Choose a conference and up to three committees you’d like to join.</p>
      <a class="btn btn-primary" href="#register">Register for a conference</a></div>`;
  }
  const anns = await Api.get("/api/announcements");
  view.innerHTML = `<div class="page-head"><div><h1>Welcome, ${esc(me.name.split(" ")[0])}</h1>
    <p>Delegate ID ${esc(me.id)}</p></div></div>${body}${announcementsHtml(anns)}`;
}

function prefsList() {
  if (!me.preferenceDetails.length) return "";
  return `<p class="sub">Your committee preferences:</p><ol class="prefs">${me.preferenceDetails
    .map((c) => `<li><strong>${esc(c.abbreviation)}</strong> ${esc(c.name)}</li>`).join("")}</ol>`;
}

// --------------------------------------------------------- registration
async function renderRegister(view) {
  await loadMe();
  const [conferences, committees] = await Promise.all([Api.get("/api/conferences"), Api.get("/api/committees")]);
  if (me.status === "approved") {
    view.innerHTML = `<div class="page-head"><div><h1>Registration</h1></div></div>
      <div class="status-card"><h2>Your registration is approved</h2>
      <p>To change it, contact the conference admin.</p></div>`;
    return;
  }
  const today = new Date().toISOString().slice(0, 10);
  const open = conferences.filter((c) => c.endDate >= today);
  if (!open.length) {
    view.innerHTML = `<div class="page-head"><div><h1>Registration</h1></div></div>
      <section class="panel"><div class="empty"><p>No conferences are open for registration right now.</p></div></section>`;
    return;
  }
  const selected = me.conferenceId && open.some((c) => c.id === me.conferenceId) ? me.conferenceId : open[0].id;
  const cards = open.map((c) => {
    const coms = committees.filter((m) => m.conferenceId === c.id);
    return `<label class="choice">
      <input type="radio" name="conference" value="${esc(c.id)}" ${c.id === selected ? "checked" : ""}>
      <span><strong>${esc(c.name)}</strong>
        <span class="sub">${esc(c.venue)}, ${esc(UI.formatDate(c.startDate))} to ${esc(UI.formatDate(c.endDate))}</span>
        <span class="sub">${coms.length ? coms.map((m) => esc(m.abbreviation)).join(", ") : "Committees to be announced"}</span></span>
    </label>`;
  }).join("");
  view.innerHTML = `<div class="page-head"><div><h1>Register for a conference</h1>
      <p>${me.status === "pending" ? "You can change your choices while your registration is under review." : "Pick a conference, then rank the committees you’d like."}</p></div></div>
    <section class="panel"><div class="panel-body">
      <form id="reg-form" novalidate>
        <fieldset class="field"><legend>Conference</legend>${cards}</fieldset>
        <div id="pref-fields"></div>
        <div class="form-error" id="reg-error" hidden></div>
        <div class="dialog-actions">
          ${me.status === "pending" || me.status === "rejected" ? `<button type="button" class="btn btn-danger" id="withdraw">Withdraw registration</button>` : ""}
          <button type="submit" class="btn btn-primary">${me.status === "pending" ? "Update registration" : "Submit registration"}</button>
        </div>
      </form></div></section>`;

  const form = document.getElementById("reg-form");
  const drawPrefs = () => {
    const confId = form.conference.value;
    const coms = committees.filter((m) => m.conferenceId === confId);
    const current = confId === me.conferenceId ? me.preferences : [];
    const opts = (k) => `<option value="">${k === 0 ? "Choose a committee" : "No further choice"}</option>` +
      coms.map((m) => `<option value="${esc(m.id)}" ${current[k] === m.id ? "selected" : ""}>${esc(m.abbreviation)}: ${esc(m.name)}</option>`).join("");
    document.getElementById("pref-fields").innerHTML = coms.length
      ? ["First choice", "Second choice", "Third choice"].map((label, k) => `
        <div class="field"><label for="pref${k}">${label}</label><select id="pref${k}" name="pref${k}">${opts(k)}</select></div>`).join("")
      : `<p class="sub">This conference has no committees yet, so it can’t take registrations.</p>`;
  };
  form.addEventListener("change", (e) => { if (e.target.name === "conference") drawPrefs(); });
  drawPrefs();

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = document.getElementById("reg-error");
    err.hidden = true;
    const prefs = [0, 1, 2].map((k) => (form[`pref${k}`] || {}).value).filter(Boolean);
    if (!prefs.length) { err.textContent = "Choose at least your first-choice committee."; err.hidden = false; return; }
    try {
      await Api.post("/api/delegate/me/registration", { conferenceId: form.conference.value, preferences: prefs });
      UI.toast("Registration submitted. You’ll see the decision on your home page.");
      location.hash = "#home";
    } catch (ex) { err.textContent = ex.message; err.hidden = false; }
  });
  const w = document.getElementById("withdraw");
  if (w) w.addEventListener("click", () => Shell.act(async () => {
    if (!await UI.confirm({ title: "Withdraw registration?", danger: true, confirmLabel: "Withdraw",
      message: "Your conference choice and preferences will be cleared. You can register again later." })) return;
    await Api.del("/api/delegate/me/registration");
    UI.toast("Registration withdrawn.");
  }));
}

// ------------------------------------------------------------ sessions
async function renderSessions(view) {
  await loadMe();
  if (!me.committeeId) {
    view.innerHTML = `<div class="page-head"><div><h1>Sessions</h1></div></div>
      <section class="panel"><div class="empty"><p>You’ll see your committee’s sessions once you’re placed in a committee.</p></div></section>`;
    return;
  }
  const [sessions, att] = await Promise.all([Api.get("/api/delegate/me/sessions"), Api.get("/api/delegate/me/attendance")]);
  const attOf = {};
  att.sessions.forEach((a) => { attOf[a.sessionId] = a.statusLabel; });
  const rows = sessions.map((s) => `<tr${s.status === "active" ? ` class="row-live"` : ""}>
    <td><strong>${esc(s.title)}</strong></td><td>${esc(UI.formatDate(s.date))}</td>
    <td>${esc(s.startTime)} to ${esc(s.endTime)}</td>
    <td><span class="badge ${s.status === "active" ? "badge-active" : s.status === "completed" ? "badge-completed" : ""}">${esc(s.statusLabel)}</span></td>
    <td>${esc(attOf[s.id] || "")}</td></tr>`).join("");
  view.innerHTML = `<div class="page-head"><div><h1>${esc(me.committee.abbreviation)} sessions</h1>
    <p>Your committee’s schedule, in time order. Attendance: ${att.attended} of ${att.sessionsHeld} sessions held (${att.percentage}%).</p></div>
    ${sessions.some((x) => x.status === "active") ? `<a class="btn btn-primary" href="#live">Join the live session</a>` : ""}</div>
    <section class="panel">${rows ? `<div class="table-wrap"><table>
      <thead><tr><th>Session</th><th>Date</th><th>Time</th><th>Status</th><th>Your attendance</th></tr></thead><tbody>${rows}</tbody></table></div>`
      : `<div class="empty"><p>No sessions are scheduled for ${esc(me.committee.abbreviation)} yet.</p></div>`}</section>`;
}

// ------------------------------------------------------------- profile
async function renderProfile(view) {
  await loadMe();
  const history = await Api.get("/api/auth/history");
  const hist = history.map((h) => `<tr><td>${esc(h.at)}</td><td>${h.success ? "Signed in" : "Failed attempt"}</td><td>${esc(h.detail)}</td></tr>`).join("");
  view.innerHTML = `<div class="page-head"><div><h1>Profile</h1><p>Delegate ID ${esc(me.id)}, registered ${esc(me.createdAt.slice(0, 10))}</p></div>
      <button class="btn btn-primary" id="edit-profile">Edit profile</button></div>
    <section class="panel"><div class="panel-body"><dl class="details">
      <dt>Name</dt><dd>${esc(me.name)}</dd>
      <dt>Email</dt><dd>${esc(me.email)}</dd>
      <dt>School or university</dt><dd>${esc(me.institution) || "<span class='sub'>Not given</span>"}</dd>
    </dl></div></section>
    <section class="panel"><div class="panel-head"><h2>Recent sign-ins</h2></div>
      ${hist ? `<div class="table-wrap"><table><thead><tr><th>When</th><th>Result</th><th>Detail</th></tr></thead><tbody>${hist}</tbody></table></div>`
        : `<div class="empty"><p>No sign-ins recorded.</p></div>`}
      <p class="table-note">If you see a sign-in you don’t recognise, change your password.</p></section>`;
  document.getElementById("edit-profile").addEventListener("click", () => UI.form({
    title: "Edit profile", submitLabel: "Save changes",
    fields: [
      { name: "name", label: "Full name", required: true, maxlength: 100, value: me.name },
      { name: "email", label: "Email", type: "email", required: true, maxlength: 100, value: me.email },
      { name: "institution", label: "School or university", maxlength: 100, value: me.institution },
    ],
    onSubmit: async (v) => { await Api.put("/api/delegate/me", v); UI.toast("Profile saved."); Shell.render(); },
  }));
}


// ---------------------------------------------------------- live session
let L = null;
async function renderLive(view) {
  await loadMe();
  if (!me.committeeId) {
    view.innerHTML = `<div class="page-head"><div><h1>Live session</h1></div></div>
      <section class="panel"><div class="empty"><p>You’ll follow your committee here once you’re placed in one.</p></div></section>`;
    return;
  }
  const cur = await Api.get("/api/live/current");
  if (!cur.sessionId) {
    view.innerHTML = `<div class="page-head"><div><h1>${esc(me.committee.abbreviation)} live</h1></div></div>
      <section class="panel"><div class="empty"><p>Your committee isn’t in session. This page opens by itself when the chair starts a session.</p>
      <a class="btn" href="#sessions">See the schedule</a></div></section>`;
    Live.poll(async () => { if ((await Api.get("/api/live/current")).sessionId) Shell.render(); }, 5000);
    return;
  }
  view.innerHTML = `<div class="page-head"><div><h1>${esc(me.committee.abbreviation)} in session</h1><p id="live-sub"></p></div></div>
    <div id="seat-bar"></div><div id="live-panels" class="live-grid"></div>`;
  Live.poll(() => drawLive(cur.sessionId), 3000);
}

async function drawLive(sessionId) {
  const box = document.getElementById("live-panels");
  if (!box) return;
  L = await Api.get(`/api/sessions/${encodeURIComponent(sessionId)}/live`);
  if (L.session.status !== "active") { Shell.render(); return; }
  Live.sync(L.serverNow);
  const sp = L.speakers, mo = L.motions, vo = L.vote, att = L.attendance;
  const seated = att.seated;
  document.getElementById("live-sub").textContent = `${L.session.title}. You represent ${me.portfolio}.`;

  const seatText = {
    unmarked: `<div class="callout"><span>Check in so the Executive Board can mark you present. You can speak, raise POIs, propose motions and vote once you’re marked present.</span>
      <button class="btn btn-small btn-primary" data-action="check-in">Check in</button></div>`,
    checked_in: `<div class="callout"><span>Checked in. Waiting for the Executive Board to mark you present.</span></div>`,
    absent: `<div class="callout callout-bad"><span>You’re marked absent for this session. Speak to the Executive Board if that’s wrong.</span></div>`,
  };
  document.getElementById("seat-bar").innerHTML = seated ? "" : (seatText[att.mine] || "");

  const speaking = sp.current && sp.current.id === me.id;
  const myPos = sp.myPosition;
  let floorAction = "";
  if (seated && !speaking) {
    if (myPos >= 0) floorAction = `<p class="next-step">You’re number <strong>${myPos + 1}</strong> on the list.</p>
      <button class="btn btn-small" data-action="leave-list">Leave the list</button>`;
    else if (sp.myRequest) floorAction = `<p class="next-step">Your request to speak is waiting for the chair.</p>
      <button class="btn btn-small" data-action="withdraw-request">Withdraw request</button>`;
    else floorAction = `<button class="btn btn-primary" data-action="request">Request to speak</button>`;
  }
  const floor = `<section class="panel"><div class="panel-head"><h2>Floor</h2></div>
    <div class="panel-body">${speaking ? `<p class="you-speak">You have the floor.</p>` : ""}${Live.floorPlacard(sp)}${floorAction}</div>
    <div class="panel-sub"><h3>Speakers list <span class="count">${sp.queue.length}</span></h3>
      ${sp.queue.length ? `<ol class="queue small">${sp.queue.map((d) => `<li${d.id === me.id ? ` class="me"` : ""}>${Live.whoFull(d)}</li>`).join("")}</ol>`
        : `<p class="sub">Nobody is waiting.</p>`}</div></section>`;

  const v = vo.open;
  let voteBody = `<p class="sub">No vote is open.</p>`;
  if (v) {
    const choices = v.myChoice ? `<p class="next-step">You voted <strong>${esc(v.myChoice)}</strong>.</p>`
      : seated ? `<div class="vote-buttons">
          <button class="btn vote-yes" data-action="vote" data-id="yes">Yes</button>
          <button class="btn vote-no" data-action="vote" data-id="no">No</button>
          ${v.kind === "substantive" ? `<button class="btn" data-action="vote" data-id="abstain">Abstain</button>` : ""}</div>`
      : `<p class="sub">You can vote once you’re marked present.</p>`;
    voteBody = `<p><strong>${esc(v.subject)}</strong></p>
      <p class="sub">${v.kind === "substantive" ? "Substantive vote" : "Procedural vote, no abstentions"},
        ${v.majority === "two_thirds" ? "two-thirds" : "simple"} majority. ${v.ballotsCast} of ${v.eligible} have voted.</p>${choices}`;
  }
  const vote = `<section class="panel${v && !v.myChoice && seated ? " attention" : ""}"><div class="panel-head"><h2>Voting</h2></div>
    <div class="panel-body">${voteBody}
      ${vo.recent.length ? `<h3>Results</h3><ul class="results">${vo.recent.map(Live.resultLine).join("")}</ul>` : ""}</div></section>`;

  const motions = `<section class="panel"><div class="panel-head"><h2>Motions <span class="count">${mo.pending.length}</span></h2>
      ${seated ? `<button class="btn btn-small" data-action="propose">Propose a motion</button>` : ""}</div>
    ${mo.onFloor ? `<div class="panel-sub on-floor"><span class="badge badge-active">Being voted on</span> ${esc(mo.onFloor.description)}</div>` : ""}
    ${mo.pending.length ? `<ol class="motions">${mo.pending.map((m) => `<li>${Live.motionLine(m)}
        ${m.proposer && m.proposer.id === me.id ? `<button class="btn btn-small btn-ghost" data-action="withdraw-motion" data-id="${esc(m.id)}">Withdraw</button>` : ""}</li>`).join("")}</ol>`
      : `<p class="panel-body sub">No motions pending. They are taken in order of precedence.</p>`}</section>`;

  const myPois = sp.myPois.map((p) => `<li><div class="poi-meta">To ${Live.who(p.to)}:
      <span class="badge ${{ accepted: "badge-completed", rejected: "badge-danger", pending: "badge-active" }[p.status] || ""}">${esc(p.status[0].toUpperCase() + p.status.slice(1))}</span></div>
      <p>${esc(p.text)}</p>${p.status === "rejected" ? `<p class="sub">Reason: ${esc(p.reason)}</p>` : ""}
      ${p.status === "pending" ? `<button class="btn btn-small btn-ghost" data-action="withdraw-poi" data-id="${esc(p.id)}">Withdraw</button>` : ""}</li>`).join("");
  const pois = `<section class="panel"><div class="panel-head"><h2>Points of information</h2>
      ${seated && sp.current && !speaking ? `<button class="btn btn-small" data-action="raise-poi">Raise a POI to ${esc(sp.current.portfolio)}</button>` : ""}</div>
    ${myPois ? `<ul class="poi-list">${myPois}</ul>` : `<p class="panel-body sub">${sp.current ? "Raise a POI to ask the speaker a question." : "POIs go to whoever has the floor."}</p>`}
    ${sp.poisAccepted.length ? `<div class="panel-sub"><h3>Accepted in this session</h3><ul class="poi-list small">${sp.poisAccepted.map((p) =>
      `<li><div class="poi-meta">${Live.who(p.from)} to ${Live.who(p.to)}</div><p>${esc(p.text)}</p></li>`).join("")}</ul></div>` : ""}</section>`;

  box.innerHTML = `<div class="live-col">${floor}${pois}</div><div class="live-col">${vote}${motions}</div>`;
  Live.tick();
}

const sid = () => encodeURIComponent(L.session.id);
const ACTIONS = {
  "check-in": async () => { await Api.post(`/api/sessions/${sid()}/check-in`); UI.toast("Checked in."); },
  "request": async () => { await Api.post(`/api/sessions/${sid()}/speak-requests`); UI.toast("Request sent to the chair."); },
  "withdraw-request": async () => { await Api.del(`/api/sessions/${sid()}/speak-requests`); },
  "leave-list": async () => { await Api.del(`/api/sessions/${sid()}/speakers/${encodeURIComponent(me.id)}`); },
  "vote": async (choice) => { await Api.post(`/api/votes/${encodeURIComponent(L.vote.open.id)}/ballot`, { choice }); UI.toast(`Vote recorded: ${choice}.`); },
  "raise-poi": () => UI.form({ title: `POI to ${L.speakers.current.portfolio}`, intro: "The chair decides whether it is taken.", submitLabel: "Raise POI",
    fields: [{ name: "text", label: "Your question", type: "textarea", required: true, maxlength: 300 }],
    onSubmit: async (v) => { await Api.post(`/api/sessions/${sid()}/pois`, { text: v.text, targetId: L.speakers.current.id }); UI.toast("POI sent to the chair."); Shell.render(); } }),
  "withdraw-poi": async (id) => { await Api.post(`/api/pois/${encodeURIComponent(id)}/withdraw`); },
  "propose": () => UI.form({ title: "Propose a motion", intro: "Motions are considered in order of precedence, most disruptive first.", submitLabel: "Propose motion",
    fields: motionFields(null),
    onSubmit: async (v) => { await Api.post(`/api/sessions/${sid()}/motions`, v); UI.toast("Motion proposed."); Shell.render(); } }),
  "withdraw-motion": async (id) => { await Api.post(`/api/motions/${encodeURIComponent(id)}/withdraw`); UI.toast("Motion withdrawn."); },
};
document.addEventListener("click", (e) => {
  const b = e.target.closest("#view [data-action]");
  if (b && ACTIONS[b.dataset.action]) Shell.act(() => ACTIONS[b.dataset.action](b.dataset.id));
});

// --------------------------------------------------------------- results
async function renderResults(view) {
  await loadMe();
  const r = await Api.get("/api/delegate/me/results");
  if (!r.marksheet) {
    view.innerHTML = `<div class="page-head"><div><h1>Results</h1></div></div>
      <section class="panel"><div class="empty"><p>Your results aren’t published yet. They appear here once the conference team publishes them.</p></div></section>`;
    return;
  }
  const m = r.marksheet;
  const crit = m.criteria.map((c) => `<tr><td>${esc(c.name)}</td>
    <td><div class="bench-cell"><div class="bench-bar"><span data-w="${Math.round((c.mark / c.max) * 100)}"></span></div>
      <span class="num">${c.mark} / ${c.max}</span></div></td></tr>`).join("");
  const awards = r.committeeAwards.map((a) => `<li><span class="badge badge-active">${esc(a.award)}</span> ${esc(a.delegate.portfolio)}</li>`).join("");
  view.innerHTML = `<div class="page-head"><div><h1>Your results</h1><p>${esc(me ? me.portfolio : "")}</p></div></div>
    <div class="result-hero">
      ${r.award ? `<article class="placard award-placard"><div class="live">Award</div><div class="abbr">${esc(r.award)}</div></article>` : ""}
      <div class="stats result-stats">
        <div class="stat"><b>${m.percent}%</b><span>${m.total} of ${m.maxTotal} marks</span></div>
        <div class="stat"><b>${r.rank}</b><span>Rank of ${r.of} published</span></div>
      </div>
    </div>
    <section class="panel"><div class="panel-head"><h2>Marksheet</h2></div>
      <div class="table-wrap"><table class="bench"><tbody>${crit}</tbody></table></div>
      ${m.remarks ? `<div class="panel-sub"><h3>Remarks from the Executive Board</h3><p>${esc(m.remarks)}</p></div>` : ""}</section>
    ${awards ? `<section class="panel"><div class="panel-head"><h2>Committee awards</h2></div><ul class="results panel-body">${awards}</ul></section>` : ""}`;
  view.querySelectorAll(".bench-bar span").forEach((sp) => { sp.style.width = `${sp.dataset.w}%`; });
}

Shell.start({
  role: "delegate",
  sections: [
    { key: "home", label: "Home" },
    { key: "live", label: "Live session" },
    { key: "register", label: "Registration" },
    { key: "sessions", label: "Sessions" },
    { key: "results", label: "Results" },
    { key: "profile", label: "Profile" },
  ],
  renderers: { home: renderHome, live: renderLive, results: renderResults, register: renderRegister, sessions: renderSessions, profile: renderProfile },
});
