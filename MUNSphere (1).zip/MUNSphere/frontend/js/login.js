// MUNSphere — login.js
"use strict";

const ROLE_TEXT = {
  delegate: { label: "Delegate ID", hint: "The ID you got when you registered, like D001." },
  eb: { label: "Executive Board ID", hint: "The ID the conference admin gave you, like EB001." },
  admin: { label: "Admin ID", hint: "Like ADM001." },
};
const TITLES = { delegate: "Delegate", eb: "Executive Board", admin: "Admin" };
const Auth_DASH = { admin: "/admin.html", eb: "/eb.html", delegate: "/delegate.html" };
let chosenRole = "delegate";

const $ = (id) => document.getElementById(id);
const cards = ["register-card", "welcome-card", "reset-card"];
const loginCard = document.querySelector(".login-card");

function show(cardId) {
  loginCard.hidden = cardId !== null;
  cards.forEach((c) => { $(c).hidden = c !== cardId; });
}

function chooseRole(role) {
  chosenRole = role;
  document.querySelectorAll(".tabs [role=tab]").forEach((t) =>
    t.setAttribute("aria-selected", String(t.dataset.role === role)));
  $("id-label").textContent = ROLE_TEXT[role].label;
  $("id-hint").textContent = ROLE_TEXT[role].hint;
  $("delegate-links").hidden = role !== "delegate";
  $("staff-links").hidden = role === "delegate";
  $("login-error").hidden = true;
}

function showError(box, message) {
  box.textContent = message;
  box.hidden = false;
}

// Already signed in? Go straight to the dashboard.
(async () => {
  const params = new URLSearchParams(location.search);
  if (params.get("ended")) {
    $("notice").textContent = "Your session ended. Log in again to continue.";
    $("notice").hidden = false;
  }
  if (Session.token()) {
    try {
      const me = await Api.get("/api/auth/me");
      location.href = Auth_DASH[me.role];
    } catch (e) { Session.clear(); }
  }
})();

document.querySelector(".tabs").addEventListener("click", (e) => {
  const t = e.target.closest("[data-role]");
  if (t) chooseRole(t.dataset.role);
});

$("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = $("login-id").value.trim();
  const password = $("login-password").value;
  const err = $("login-error");
  err.hidden = true;
  if (!id || !password) { showError(err, "Enter your ID and password."); return; }
  try {
    const res = await Api.post("/api/auth/login", { id, password });
    if (res.user.role !== chosenRole) {
      // Right password, wrong door: don't keep this session.
      Session.set(res.token, res.user);
      await Api.post("/api/auth/logout").catch(() => {});
      Session.clear();
      showError(err, `This is ${res.user.role === "admin" ? "an" : "a"} ${TITLES[res.user.role]} account. ` +
        `Use the ${TITLES[res.user.role]} tab.`);
      return;
    }
    Session.set(res.token, res.user);
    const next = new URLSearchParams(location.search).get("next");
    const target = Auth_DASH[res.user.role];
    location.href = next && next.startsWith(target) ? next : target;
  } catch (ex) {
    showError(err, ex.message);
  }
});

$("show-register").addEventListener("click", () => show("register-card"));
$("show-reset").addEventListener("click", () => show("reset-card"));
$("show-reset-staff").addEventListener("click", () => show("reset-card"));
document.querySelectorAll("[data-back]").forEach((b) => b.addEventListener("click", () => show(null)));

$("register-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const err = $("register-error");
  err.hidden = true;
  if (!f.checkValidity()) {
    const first = f.querySelector(":invalid");
    showError(err, `Check “${f.querySelector(`label[for="${first.id}"]`).textContent}”: ${first.validationMessage}`);
    first.focus();
    return;
  }
  if (f.password.value !== f.confirm.value) { showError(err, "The passwords don’t match."); return; }
  try {
    const res = await Api.post("/api/auth/register", {
      name: f.name.value.trim(), email: f.email.value.trim(),
      institution: f.institution.value.trim(), password: f.password.value,
    });
    Session.set(res.token, res.user);
    $("new-id").textContent = res.user.id;
    show("welcome-card");
  } catch (ex) {
    showError(err, ex.message);
  }
});

$("reset-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = $("reset-id").value.trim();
  if (!id) return;
  try {
    const res = await Api.post("/api/auth/request-reset", { id });
    $("reset-done").textContent = res.message;
  } catch (ex) {
    $("reset-done").textContent = ex.message;
  }
  $("reset-done").hidden = false;
  e.target.hidden = true;
});

chooseRole("delegate");
if (location.hash === "#register") show("register-card");
