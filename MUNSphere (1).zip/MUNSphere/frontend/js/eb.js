// MUNSphere — eb.js
// Executive Board portal. Everything is scoped to the one committee the
// Admin assigned. Buttons appear only for permissions the member holds;
// the server checks every action again regardless.
"use strict";

const esc = UI.esc;
const can = (p) => Shell.user.eb && Shell.user.eb.permissions.includes(p);
let committee = null;
let sessions = [];

function notAssigned(view) {
  view.innerHTML = `<div class="page-head"><div><h1>No committee assigned</h1></div></div>
    <section class="panel"><div class="empty"><p>Ask the conference admin to assign you to a committee.</p></div></section>`;
}

async function loadCommittee() {
  const id = Shell.user.eb && Shell.user.eb.committeeId;
  committee = id ? await Api.get(`/api/committees/${encodeURIComponent(id)}`) : null;
  return committee;
}

// ------------------------------------------------------------ committee
async function renderCommittee(view) {
  if (!await loadCommittee()) { notAssigned(view); return; }
  const [anns, member, roster, list] = await Promise.all([
    Api.get("/api/announcements"),
    Api.get("/api/eb/me"),
    can("view") ? Api.get(`/api/committees/${encodeURIComponent(committee.id)}/roster`) : null,
    Api.get("/api/sessions"),
  ]);
  const active = list.find((s) => s.status === "active");
  const upcoming = list.filter((s) => s.status === "scheduled").slice(0, 3);
  view.innerHTML = `<div class="page-head"><div><h1>${esc(committee.name)}</h1>
      <p>You are the ${esc(member.ebRole)} of ${esc(committee.abbreviation)}.</p></div></div>
    <div class="stats">
      <div class="stat"><b>${roster ? roster.assigned : "–"}</b><span>Delegates placed</span></div>
      <div class="stat"><b>${committee.capacity}</b><span>Capacity</span></div>
      <div class="stat"><b>${list.length}</b><span>Sessions</span></div>
      <div class="stat"><b>${member.permissions.length}</b><span>Your permissions</span></div>
    </div>
    <section class="panel"><div class="panel-head"><h2>${active ? "In session now" : "Next up"}</h2>
      <a class="btn btn-small" href="#sessions">All sessions</a></div>
      <div class="panel-body">${active ? `<div class="placards"><article class="placard">
          <div class="live">In session</div><div class="abbr">${esc(committee.abbreviation)}</div>
          <div class="title">${esc(active.title)}</div><div class="meta">${esc(active.startTime)} to ${esc(active.endTime)}</div></article></div>`
        : upcoming.length ? `<ul class="upcoming">${upcoming.map((s) => `<li><time>${esc(UI.formatDate(s.date))}<br>${esc(s.startTime)}</time>
            <div><strong>${esc(s.title)}</strong></div><div></div></li>`).join("")}</ul>`
          : `<p class="sub">No sessions scheduled yet.</p>`}</div></section>
    <section class="panel"><div class="panel-head"><h2>Agenda</h2></div>
      <div class="panel-body"><p>${esc(committee.agenda) || "<span class='sub'>No agenda set.</span>"}</p></div></section>
    <section class="panel"><div class="panel-head"><h2>Your role</h2></div><div class="panel-body">
      <p>${esc(member.responsibilities)}</p>
      <p class="sub">Permissions: ${esc(member.permissions.join(", "))}</p></div></section>${announcementsHtml(anns)}`;
}

// ------------------------------------------------------------- sessions
function sessionButtons(s) {
  const id = esc(s.id);
  let b = "";
  if (s.status === "scheduled") {
    if (can("run_sessions")) b += `<button class="btn btn-small btn-brass" data-action="activate" data-id="${id}">Activate</button>`;
    if (can("manage_sessions")) b += `<button class="btn btn-small" data-action="edit" data-id="${id}">Edit</button>
      <button class="btn btn-small btn-danger" data-action="delete" data-id="${id}">Delete</button>`;
  } else if (s.status === "active" && can("run_sessions")) {
    b = `<button class="btn btn-small" data-action="deactivate" data-id="${id}">Pause</button>
      <button class="btn btn-small btn-primary" data-action="complete" data-id="${id}">Complete</button>`;
  }
  return b || `<span class="sub">${s.status === "completed" ? "Kept as record" : ""}</span>`;
}

async function renderSessions(view) {
  if (!await loadCommittee()) { notAssigned(view); return; }
  sessions = await Api.get("/api/sessions");
  const rows = sessions.map((s) => `<tr${s.status === "active" ? ` class="row-live"` : ""}>
    <td class="id">${esc(s.id)}</td><td><strong>${esc(s.title)}</strong></td>
    <td>${esc(UI.formatDate(s.date))}</td><td>${esc(s.startTime)} to ${esc(s.endTime)}</td>
    <td><span class="badge ${s.status === "active" ? "badge-active" : s.status === "completed" ? "badge-completed" : ""}">${esc(s.statusLabel)}</span></td>
    <td class="actions">${sessionButtons(s)}</td></tr>`).join("");
  view.innerHTML = `<div class="page-head"><div><h1>${esc(committee.abbreviation)} sessions</h1>
      <p>One session can be active at a time.</p></div>
      ${can("manage_sessions") ? `<button class="btn btn-primary" data-action="new">New session</button>` : ""}</div>
    <section class="panel">${rows ? `<div class="table-wrap"><table>
      <thead><tr><th>ID</th><th>Title</th><th>Date</th><th>Time</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`
      : `<div class="empty"><p>No sessions yet.${can("manage_sessions") ? "" : " The Chairperson or Admin schedules them."}</p></div>`}</section>`;
}

function sessionFields(s) {
  return [
    { name: "title", label: "Title", required: true, maxlength: 100, value: s && s.title },
    { name: "date", label: "Date", type: "date", required: true, value: s && s.date, hint: "Must fall within the conference dates." },
    { name: "startTime", label: "Starts", type: "time", required: true, half: true, value: s && s.startTime },
    { name: "endTime", label: "Ends", type: "time", required: true, half: true, value: s && s.endTime },
  ];
}

// ------------------------------------------------------------ delegates
let rosterSort = "portfolio";
async function renderDelegates(view) {
  if (!await loadCommittee()) { notAssigned(view); return; }
  const r = await Api.get(`/api/committees/${encodeURIComponent(committee.id)}/roster?sort=${rosterSort}`);
  const rows = r.delegates.map((d) => `<tr><td><strong>${esc(d.portfolio)}</strong></td><td>${esc(d.name)}</td><td class="id">${esc(d.id)}</td></tr>`).join("");
  const opt = (v, l) => `<option value="${v}" ${v === rosterSort ? "selected" : ""}>${l}</option>`;
  view.innerHTML = `<div class="page-head"><div><h1>${esc(committee.abbreviation)} delegates</h1>
      <p>${r.assigned} of ${r.capacity} seats filled.</p></div></div>
    <section class="panel">
      <div class="toolbar"><label>Sort by <select id="sort">${opt("portfolio", "Portfolio")}${opt("name", "Name")}${opt("id", "Delegate ID")}</select></label>
        <span class="sub">${esc(r.sort.algorithm)}: ${r.sort.comparisons} comparisons, ${r.sort.moves} moves</span></div>
      ${rows ? `<div class="table-wrap"><table><thead><tr><th>Portfolio</th><th>Delegate</th><th>ID</th></tr></thead><tbody>${rows}</tbody></table></div>`
        : `<div class="empty"><p>The Admin hasn’t placed any delegates in ${esc(committee.abbreviation)} yet.</p></div>`}
    </section>`;
  document.getElementById("sort").addEventListener("change", (e) => { rosterSort = e.target.value; Shell.render(); });
}


// ---------------------------------------------------------- live session
let L = null;   // latest live state

async function renderLive(view) {
  if (!await loadCommittee()) { notAssigned(view); return; }
  const cur = await Api.get("/api/live/current");
  if (!cur.sessionId) {
    view.innerHTML = `<div class="page-head"><div><h1>${esc(committee.abbreviation)} live</h1>
      <p>No session is in progress.</p></div></div>
      <section class="panel"><div class="empty"><p>${can("run_sessions")
        ? "Activate a session from Sessions to open the floor." : "This page opens when the chair activates a session."}</p>
      ${can("run_sessions") ? `<a class="btn btn-primary" href="#sessions">Go to sessions</a>` : ""}</div></section>`;
    Live.poll(async () => { if ((await Api.get("/api/live/current")).sessionId) Shell.render(); }, 5000);
    return;
  }
  view.innerHTML = `<div class="page-head"><div><h1 id="live-title">${esc(committee.abbreviation)} in session</h1>
    <p id="live-sub"></p></div></div><div id="live-panels" class="live-grid"></div>`;
  Live.poll(() => drawLive(cur.sessionId), 3000);
}

async function drawLive(sessionId) {
  const box = document.getElementById("live-panels");
  if (!box) return;
  L = await Api.get(`/api/sessions/${encodeURIComponent(sessionId)}/live`);
  if (L.session.status !== "active") { Shell.render(); return; }
  Live.sync(L.serverNow);
  document.getElementById("live-sub").textContent =
    `${L.session.title}, ${L.session.startTime} to ${L.session.endTime}. ${L.attendance.tally.present + L.attendance.tally.late} of ${L.roster.length} seated.`;
  const sp = L.speakers, mo = L.motions, vo = L.vote;
  const btn = (perm, action, label, cls = "", id = "") => can(perm)
    ? `<button class="btn btn-small ${cls}" data-action="${action}" ${id ? `data-id="${esc(id)}"` : ""}>${label}</button>` : "";

  const floor = `<section class="panel"><div class="panel-head"><h2>Floor</h2>
      <div class="btn-row">${btn("speakers", "set-time", `Speaking time ${sp.speakingSeconds} s`)}</div></div>
    <div class="panel-body">${Live.floorPlacard(sp)}
      <div class="btn-row">${btn("speakers", "next-speaker", sp.queue.length ? "Next speaker" : "List is empty", "btn-primary")}
        ${sp.current ? btn("speakers", "finish-speech", "End speech") : ""}</div></div></section>`;

  const queue = `<section class="panel"><div class="panel-head"><h2>Speakers list <span class="count">${sp.queue.length}</span></h2>
      ${btn("speakers", "add-speaker", "Add speaker")}</div>
    ${sp.queue.length ? `<ol class="queue">${sp.queue.map((d) => `<li>${Live.whoFull(d)}
      ${btn("speakers", "remove-speaker", "Remove", "btn-ghost", d.id)}</li>`).join("")}</ol>`
      : `<p class="panel-body sub">Nobody is waiting. Add speakers or approve requests.</p>`}
    ${sp.requests.length ? `<div class="panel-sub"><h3>Requests to speak <span class="count">${sp.requests.length}</span></h3>
      <ol class="queue small">${sp.requests.map((d) => `<li>${Live.whoFull(d)}</li>`).join("")}</ol>
      <div class="btn-row">${btn("speakers", "approve-request", `Add ${esc(sp.requests[0].portfolio)} to the list`, "btn-primary")}
        ${btn("speakers", "decline-request", "Decline")}</div></div>` : ""}</section>`;

  const pois = `<section class="panel"><div class="panel-head"><h2>Points of information <span class="count">${sp.poisPending.length}</span></h2></div>
    ${sp.poisPending.length ? `<ul class="poi-list">${sp.poisPending.map((p) => `<li>
        <div class="poi-meta">${Live.who(p.from)} to ${Live.who(p.to)}</div>
        <p>${esc(p.text)}</p>
        <div class="btn-row">${btn("poi", "accept-poi", "Accept", "btn-primary", p.id)}${btn("poi", "reject-poi", "Reject", "btn-danger", p.id)}</div>
      </li>`).join("")}</ul>` : `<p class="panel-body sub">No POIs waiting.</p>`}</section>`;

  const motions = `<section class="panel"><div class="panel-head"><h2>Motions <span class="count">${mo.pending.length}</span></h2>
      <div class="btn-row">${btn("motions", "enter-motion", "Enter motion")}</div></div>
    ${mo.onFloor ? `<div class="panel-sub on-floor"><span class="badge badge-active">On the floor</span> ${esc(mo.onFloor.description)}</div>` : ""}
    ${mo.pending.length ? `<ol class="motions">${mo.pending.map((m) => `<li>${Live.motionLine(m)}
        ${btn("motions", "out-of-order", "Out of order", "btn-ghost", m.id)}</li>`).join("")}</ol>`
      : `<p class="panel-body sub">No motions pending.</p>`}
    <div class="btn-row panel-foot">${mo.pending.length && !vo.open ? btn("motions", "motion-next", `Put ${esc(mo.pending[0].typeLabel.toLowerCase())} to a vote`, "btn-primary") : ""}
      ${mo.undo ? btn("motions", "motion-undo", `Undo: ${esc(mo.undo.motionId)} ${esc(mo.undo.action)}`) : ""}</div></section>`;

  const v = vo.open;
  const vote = `<section class="panel"><div class="panel-head"><h2>Voting</h2>
      ${!v ? btn("voting", "open-vote", "Open a vote") : ""}</div>
    <div class="panel-body">${v ? `<p><strong>${esc(v.subject)}</strong></p>
        <p class="sub">${v.kind === "substantive" ? "Substantive" : "Procedural, no abstentions"},
          ${v.majority === "two_thirds" ? "two-thirds majority" : "simple majority"}. ${v.ballotsCast} of ${v.eligible} seated have voted.</p>
        ${Live.tallyBars(v)}
        <div class="btn-row">${btn("voting", "record-ballot", "Record or correct a ballot")}${btn("voting", "close-vote", "Close vote and count", "btn-primary", v.id)}</div>`
      : `<p class="sub">No vote is open.</p>`}
      ${vo.recent.length ? `<h3>Results</h3><ul class="results">${vo.recent.map(Live.resultLine).join("")}</ul>` : ""}</div></section>`;

  box.innerHTML = `<div class="live-col">${floor}${queue}</div><div class="live-col">${vote}${motions}${pois}</div>`;
  Live.sizeBars(box);
  Live.tick();
}

const seated = () => L.attendance.delegates.filter((d) => d.status === "present" || d.status === "late");
const sid = () => encodeURIComponent(L.session.id);

// ------------------------------------------------------------ attendance
let attSessionId = null;
async function renderAttendance(view) {
  if (!await loadCommittee()) { notAssigned(view); return; }
  const list = (await Api.get("/api/sessions")).filter((s) => s.status !== "scheduled");
  if (!list.length) {
    view.innerHTML = `<div class="page-head"><div><h1>Attendance</h1></div></div>
      <section class="panel"><div class="empty"><p>Attendance opens when a session is activated.</p></div></section>`;
    return;
  }
  if (!attSessionId || !list.some((s) => s.id === attSessionId))
    attSessionId = (list.find((s) => s.status === "active") || list[list.length - 1]).id;
  const [sheet, report] = await Promise.all([
    Api.get(`/api/sessions/${encodeURIComponent(attSessionId)}/attendance`),
    Api.get(`/api/committees/${encodeURIComponent(committee.id)}/attendance-report`),
  ]);
  const t = sheet.tally;
  const opts = list.map((s) => `<option value="${esc(s.id)}" ${s.id === attSessionId ? "selected" : ""}>${esc(s.title)}, ${esc(UI.formatDate(s.date))}${s.status === "active" ? " (in session)" : ""}</option>`).join("");
  const mark = (d, st, label) => `<button class="seg ${d.status === st ? "on" : ""}" data-action="att" data-id="${esc(d.delegateId)}|${st}" ${can("attendance") ? "" : "disabled"}>${label}</button>`;
  const rows = sheet.delegates.map((d) => `<tr${d.status === "checked_in" ? ` class="row-flag"` : ""}>
    <td><strong>${esc(d.portfolio)}</strong><span class="sub">${esc(d.name)}</span></td>
    <td>${d.status === "checked_in" ? `<span class="badge badge-active">Checked in</span>` : esc(d.statusLabel)}</td>
    <td class="actions"><div class="segmented">${mark(d, "present", "Present")}${mark(d, "late", "Late")}${mark(d, "absent", "Absent")}</div></td></tr>`).join("");
  const rep = report.map((r) => `<tr><td><strong>${esc(r.portfolio)}</strong><span class="sub">${esc(r.name)}</span></td>
    <td class="num">${r.attended} of ${r.sessionsHeld}</td><td class="num">${r.percentage}%</td></tr>`).join("");
  view.innerHTML = `<div class="page-head"><div><h1>Attendance</h1>
      <p>${t.present} present, ${t.late} late, ${t.absent} absent, ${t.checked_in} checked in, ${t.unmarked} not marked.</p></div>
      ${can("attendance") && (t.unmarked + t.checked_in) ? `<button class="btn btn-primary" data-action="att-all">Mark everyone else present</button>` : ""}</div>
    <section class="panel"><div class="toolbar"><label>Session <select id="att-session">${opts}</select></label>
      <span class="sub">Late counts as attending. Delegates who checked in are highlighted.</span></div>
      ${rows ? `<div class="table-wrap"><table><thead><tr><th>Delegate</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`
        : `<div class="empty"><p>No delegates are placed in this committee.</p></div>`}</section>
    <section class="panel"><div class="panel-head"><h2>Attendance across all sessions</h2></div>
      ${rep ? `<div class="table-wrap"><table><thead><tr><th>Delegate</th><th class="num">Attended</th><th class="num">Rate</th></tr></thead><tbody>${rep}</tbody></table></div>` : ""}</section>`;
  document.getElementById("att-session").addEventListener("change", (e) => { attSessionId = e.target.value; Shell.render(); });
}


// ------------------------------------------------------------ evaluation
let sheetRows = [];
const SHEET_LABEL = { none: "Not started", draft: "Draft", submitted: "With the Admin", returned: "Returned to you",
  approved: "Approved", published: "Published" };
const SHEET_BADGE = { draft: "", submitted: "badge-active", returned: "badge-danger", approved: "badge-completed", published: "badge-completed" };

async function renderEvaluation(view) {
  if (!await loadCommittee()) { notAssigned(view); return; }
  const [rows, ranking] = await Promise.all([
    Api.get(`/api/committees/${encodeURIComponent(committee.id)}/marksheets`),
    Api.get(`/api/committees/${encodeURIComponent(committee.id)}/rankings`),
  ]);
  sheetRows = rows;
  const mine = can("evaluate");
  const body = rows.map((r) => {
    let actions = "";
    if (mine) {
      if (r.status === "none") actions = `<button class="btn btn-small btn-primary" data-action="sheet-new" data-id="${esc(r.delegate.id)}">Start marksheet</button>`;
      else if (r.status === "draft" || r.status === "returned") actions = `
        <button class="btn btn-small" data-action="sheet-edit" data-id="${esc(r.marksheetId)}">Edit marks</button>
        <button class="btn btn-small btn-primary" data-action="sheet-submit" data-id="${esc(r.marksheetId)}">Submit to Admin</button>`;
    }
    return `<tr${r.status === "returned" ? ` class="row-flag"` : ""}>
      <td><strong>${esc(r.delegate.portfolio)}</strong><span class="sub">${esc(r.delegate.name)}</span></td>
      <td><span class="badge ${SHEET_BADGE[r.status] || ""}">${SHEET_LABEL[r.status]}</span>
        ${r.status === "returned" ? `<span class="sub">Admin: ${esc(r.adminNote)}</span>` : ""}</td>
      <td class="num">${r.status === "none" ? "" : `${r.total} / ${r.maxTotal}`}</td>
      <td class="num">${r.status === "none" ? "" : `${r.percent}%`}</td>
      <td class="actions">${actions}</td></tr>`;
  }).join("");
  const rank = ranking.rows.map((r) => `<tr><td class="num">${r.rank}${r.tied ? "=" : ""}</td>
    <td><strong>${esc(r.delegate.portfolio)}</strong></td><td class="num">${r.percent}%</td>
    <td>${r.award ? `<span class="badge badge-active">${esc(r.award)}</span>` : ""}</td></tr>`).join("");
  view.innerHTML = `<div class="page-head"><div><h1>Evaluation</h1>
      <p>${mine ? "Mark each delegate, then submit the marksheet to the Admin for approval." : "Your role doesn’t include evaluation; this is a read-only view."}</p></div></div>
    <section class="panel">${body ? `<div class="table-wrap"><table>
      <thead><tr><th>Delegate</th><th>Marksheet</th><th class="num">Marks</th><th class="num">Score</th><th></th></tr></thead>
      <tbody>${body}</tbody></table></div>` : `<div class="empty"><p>No delegates are placed in this committee yet.</p></div>`}</section>
    <section class="panel"><div class="panel-head"><h2>Provisional ranking</h2>
      <span class="sub">From every marksheet, including drafts. Final results come from published marksheets.</span></div>
      ${rank ? `<div class="table-wrap"><table><thead><tr><th class="num">Rank</th><th>Delegate</th><th class="num">Score</th><th>Award if confirmed</th></tr></thead>
        <tbody>${rank}</tbody></table></div><p class="table-note">${esc(ranking.config.order)}. Sorted with ${esc(ranking.sort.name.toLowerCase())}: ${ranking.sort.comparisons} comparisons.</p>`
        : `<div class="empty"><p>No marksheets yet.</p></div>`}</section>`;
}

async function editSheet(id) {
  const m = await Api.get(`/api/marksheets/${encodeURIComponent(id)}`);
  UI.form({
    title: `Marks for ${m.delegate.portfolio}`,
    intro: m.status === "returned" ? `Returned by the Admin: ${m.adminNote}` : `${m.delegate.name}. Whole marks only.`,
    submitLabel: "Save marks",
    fields: [
      ...m.criteria.map((c) => ({ name: `c_${c.key}`, label: `${c.name} (out of ${c.max})`, type: "number",
        min: 0, max: c.max, required: true, value: c.mark, half: true })),
      { name: "remarks", label: "Remarks for the delegate", type: "textarea", maxlength: 300, value: m.remarks },
    ],
    onSubmit: async (v) => {
      const marks = {};
      m.criteria.forEach((c) => { marks[c.key] = v[`c_${c.key}`]; });
      const saved = await Api.put(`/api/marksheets/${encodeURIComponent(id)}`, { marks, remarks: v.remarks });
      UI.toast(`Saved: ${saved.total} / ${saved.maxTotal}.`);
      Shell.render();
    },
  });
}


// --------------------------------------------------------------- reports
let ebReport = "committee";
async function renderReports(view) {
  if (!await loadCommittee()) { notAssigned(view); return; }
  const catalog = await Api.get("/api/reports");
  if (!can("reports")) {
    view.innerHTML = `<div class="page-head"><div><h1>Reports</h1></div></div>
      <section class="panel"><div class="empty"><p>Your role doesn’t include committee reports.</p></div></section>`;
    return;
  }
  const meta = catalog.find((r) => r.key === ebReport) || catalog[0];
  const r = await Api.get(`/api/reports/${encodeURIComponent(meta.key)}`);
  view.innerHTML = `<div class="page-head"><div><h1>${esc(committee.abbreviation)} reports</h1><p>${esc(meta.description)}</p></div></div>
    <section class="panel"><div class="toolbar">
      <label>Report <select id="eb-rep">${catalog.map((c) => `<option value="${esc(c.key)}" ${c.key === meta.key ? "selected" : ""}>${esc(c.title)}</option>`).join("")}</select></label>
      <button class="btn btn-small" data-action="rep-export" data-id="csv">Export CSV</button>
      <button class="btn btn-small" data-action="rep-export" data-id="txt">Export text</button></div>
      <div class="panel-body">${renderReport(r)}</div></section>`;
  sizeHistogram(view);
  document.getElementById("eb-rep").addEventListener("change", (e) => { ebReport = e.target.value; Shell.render(); });
}

// -------------------------------------------------------------- actions
const enc = encodeURIComponent;
const ACTIONS = {
  "rep-export": async (format) => { await Api.download(`/api/reports/${encodeURIComponent(ebReport)}?format=${format}`); },
  // evaluation
  "sheet-new": async (delegateId) => {
    const m = await Api.post(`/api/committees/${encodeURIComponent(committee.id)}/marksheets`, { delegateId });
    await editSheet(m.id); },
  "sheet-edit": (id) => editSheet(id),
  "sheet-submit": async (id) => {
    const r = sheetRows.find((x) => x.marksheetId === id);
    if (!await UI.confirm({ title: "Submit marksheet?", confirmLabel: "Submit to Admin",
      message: `${r.delegate.portfolio}: ${r.total} / ${r.maxTotal}. You can’t edit it after submitting unless the Admin returns it.` })) return;
    await Api.post(`/api/marksheets/${encodeURIComponent(id)}/submit`); UI.toast("Submitted to the Admin."); },
  // live floor
  "next-speaker": async () => { await Api.post(`/api/sessions/${sid()}/speakers/next`); },
  "finish-speech": async () => { await Api.post(`/api/sessions/${sid()}/speakers/finish`); },
  "set-time": () => UI.form({ title: "Speaking time", submitLabel: "Set time",
    fields: [{ name: "seconds", label: "Seconds per speaker", type: "number", min: 10, max: 600, required: true, value: L.speakers.speakingSeconds }],
    onSubmit: async (v) => { await Api.put(`/api/sessions/${sid()}/speakers/time`, v); UI.toast(`Speaking time is ${v.seconds} s.`); Shell.render(); } }),
  "add-speaker": () => {
    const taken = new Set([...(L.speakers.queue.map((d) => d.id)), L.speakers.current && L.speakers.current.id]);
    const options = seated().filter((d) => !taken.has(d.delegateId)).map((d) => ({ value: d.delegateId, label: `${d.portfolio} (${d.name})` }));
    if (!options.length) { UI.toast("Every seated delegate is already on the list.", "error"); return; }
    UI.form({ title: "Add to speakers list", submitLabel: "Add speaker",
      fields: [{ name: "delegateId", label: "Delegate", type: "select", required: true, options }],
      onSubmit: async (v) => { await Api.post(`/api/sessions/${sid()}/speakers`, v); Shell.render(); } });
  },
  "remove-speaker": async (id) => { await Api.del(`/api/sessions/${sid()}/speakers/${encodeURIComponent(id)}`); },
  "approve-request": async () => { await Api.post(`/api/sessions/${sid()}/speak-requests/approve-next`); },
  "decline-request": async () => { await Api.post(`/api/sessions/${sid()}/speak-requests/decline-next`); },
  "accept-poi": async (id) => { await Api.post(`/api/pois/${encodeURIComponent(id)}/accept`); UI.toast("POI accepted."); },
  "reject-poi": (id) => UI.form({ title: "Reject POI", intro: "The delegate sees this reason.", submitLabel: "Reject POI",
    fields: [{ name: "reason", label: "Reason", type: "textarea", required: true, maxlength: 300, value: "Out of order: not a question to the speaker." }],
    onSubmit: async (v) => { await Api.post(`/api/pois/${encodeURIComponent(id)}/reject`, v); Shell.render(); } }),
  "motion-next": async () => { const m = await Api.post(`/api/sessions/${sid()}/motions/next`); UI.toast(`${m.id} is now being voted on.`); },
  "motion-undo": async () => { const r = await Api.post(`/api/sessions/${sid()}/motions/undo`); UI.toast(`Undone. ${r.motion.id} is pending again.`); },
  "out-of-order": async (id) => {
    if (!await UI.confirm({ title: "Rule out of order?", confirmLabel: "Rule out of order", message: `${id} will be removed from the motions list. You can undo this.` })) return;
    await Api.post(`/api/motions/${encodeURIComponent(id)}/out-of-order`); },
  "enter-motion": () => UI.form({ title: "Enter a motion", intro: "For a motion raised on the floor. Fill in what the motion type needs.", submitLabel: "Add motion",
    fields: motionFields(seated().map((d) => ({ value: d.delegateId, label: `${d.portfolio} (${d.name})` }))),
    onSubmit: async (v) => { await Api.post(`/api/sessions/${sid()}/motions`, v); UI.toast("Motion added."); Shell.render(); } }),
  "open-vote": () => UI.form({ title: "Open a vote", submitLabel: "Open vote",
    fields: [
      { name: "subject", label: "What is being voted on", required: true, maxlength: 300, value: "Draft resolution 1.1" },
      { name: "kind", label: "Kind", type: "select", half: true, value: "substantive",
        options: [{ value: "substantive", label: "Substantive (abstain allowed)" }, { value: "procedural", label: "Procedural" }] },
      { name: "majority", label: "Majority", type: "select", half: true, value: "simple",
        options: [{ value: "simple", label: "Simple majority" }, { value: "two_thirds", label: "Two-thirds" }] }],
    onSubmit: async (v) => { await Api.post(`/api/sessions/${sid()}/votes`, { subject: v.subject, majority: v.majority, substantive: v.kind === "substantive" }); Shell.render(); } }),
  "record-ballot": () => UI.form({ title: "Record or correct a ballot", intro: "Use this for roll-call votes or to correct a mistaken vote. Corrections are counted.",
    submitLabel: "Save ballot", fields: [
      { name: "delegateId", label: "Delegate", type: "select", required: true, options: seated().map((d) => ({ value: d.delegateId, label: `${d.portfolio} (${d.name})` })) },
      { name: "choice", label: "Vote", type: "select", required: true, options: [{ value: "yes", label: "Yes" }, { value: "no", label: "No" },
        ...(L.vote.open.kind === "substantive" ? [{ value: "abstain", label: "Abstain" }] : [])] }],
    onSubmit: async (v) => { await Api.post(`/api/votes/${encodeURIComponent(L.vote.open.id)}/record`, v); Shell.render(); } }),
  "close-vote": async (id) => {
    if (!await UI.confirm({ title: "Close the vote?", confirmLabel: "Close and count", message: "No more ballots can be cast. The result is final." })) return;
    const v = await Api.post(`/api/votes/${encodeURIComponent(id)}/close`);
    UI.toast(`${v.subject}: ${v.outcome === "passed" ? "passed" : "failed"} (${v.tally.yes} to ${v.tally.no}).`); },
  // attendance
  "att": async (pair) => { const [delegateId, status] = pair.split("|");
    await Api.post(`/api/sessions/${encodeURIComponent(attSessionId)}/attendance`, { delegateId, status }); },
  "att-all": async () => { await Api.post(`/api/sessions/${encodeURIComponent(attSessionId)}/attendance/all`, { status: "present" }); UI.toast("Everyone else marked present."); },
  new: () => UI.form({ title: "Schedule session", submitLabel: "Schedule session", fields: sessionFields(null),
    onSubmit: async (v) => { const s = await Api.post("/api/sessions", { ...v, committeeId: committee.id }); UI.toast(`Scheduled ${s.title}.`); Shell.render(); } }),
  edit: (id) => { const s = sessions.find((x) => x.id === id); UI.form({ title: `Edit ${s.title}`, submitLabel: "Save changes", fields: sessionFields(s),
    onSubmit: async (v) => { await Api.put(`/api/sessions/${enc(id)}`, v); UI.toast("Changes saved."); Shell.render(); } }); },
  delete: async (id) => { const s = sessions.find((x) => x.id === id);
    if (!await UI.confirm({ title: "Delete session?", danger: true, confirmLabel: "Delete session", message: `${s.title} will be deleted. This can’t be undone.` })) return;
    await Api.del(`/api/sessions/${enc(id)}`); UI.toast(`Deleted ${s.title}.`); },
  activate: async (id) => { const s = await Api.post(`/api/sessions/${enc(id)}/activate`); UI.toast(`${s.title} is now in session.`); },
  deactivate: async (id) => { const s = await Api.post(`/api/sessions/${enc(id)}/deactivate`); UI.toast(`${s.title} is paused.`); },
  complete: async (id) => { const s = sessions.find((x) => x.id === id);
    if (!await UI.confirm({ title: "Complete session?", confirmLabel: "Complete session", message: `${s.title} will be closed and kept as a record.` })) return;
    await Api.post(`/api/sessions/${enc(id)}/complete`); UI.toast(`Completed ${s.title}.`); },
};

document.addEventListener("click", (e) => {
  const btn = e.target.closest("#view [data-action]");
  if (btn && ACTIONS[btn.dataset.action]) Shell.act(() => ACTIONS[btn.dataset.action](btn.dataset.id));
});

Shell.start({
  role: "eb",
  sections: [
    { key: "committee", label: "Committee" },
    { key: "live", label: "Live session" },
    { key: "attendance", label: "Attendance" },
    { key: "sessions", label: "Sessions" },
    { key: "delegates", label: "Delegates" },
    { key: "evaluation", label: "Evaluation" },
    { key: "reports", label: "Reports" },
  ],
  renderers: { committee: renderCommittee, live: renderLive, attendance: renderAttendance, sessions: renderSessions,
    delegates: renderDelegates, evaluation: renderEvaluation, reports: renderReports },
});
