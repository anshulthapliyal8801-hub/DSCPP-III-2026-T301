// MUNSphere — admin.js
// Admin dashboard: conference setup, delegate approvals and placement,
// Executive Board accounts, and account security.
"use strict";

const esc = UI.esc;
const state = {
  conferences: [], committees: [], sessions: [], summaries: [],
  filters: { conferenceId: "", query: "", committeeId: "", status: "", dStatus: "", dQuery: "", dConf: "", aRole: "" },
};

// ------------------------------------------------------------- helpers
const conferenceById = (id) => state.conferences.find((c) => c.id === id);
const committeeById = (id) => state.committees.find((c) => c.id === id);
const committeeLabel = (id) => (committeeById(id) || { abbreviation: id }).abbreviation;

function badge(kind, label) {
  const cls = { active: "badge-active", completed: "badge-completed", approved: "badge-completed",
    rejected: "badge-danger", revoked: "badge-danger", pending: "badge-active" }[kind] || "";
  return `<span class="badge ${cls}">${esc(label)}</span>`;
}

function emptyState(message, action, actionLabel) {
  const button = action ? `<button class="btn btn-primary" data-action="${action}">${esc(actionLabel)}</button>` : "";
  return `<div class="empty"><p>${esc(message)}</p>${button}</div>`;
}

function pageHead(title, sub, action, actionLabel) {
  return `<div class="page-head"><div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div>
    ${action ? `<button class="btn btn-primary" data-action="${action}">${esc(actionLabel)}</button>` : ""}</div>`;
}

async function loadCore() {
  const [conferences, committees, sessions, summaries] = await Promise.all([
    Api.get("/api/conferences"), Api.get("/api/committees"), Api.get("/api/sessions"),
    Api.get("/api/committee-summaries"),
  ]);
  Object.assign(state, { conferences, committees, sessions, summaries });
}

// ------------------------------------------------------------ overview
async function renderOverview(view) {
  await loadCore();
  const [ov, pending] = await Promise.all([Api.get("/api/overview"), Api.get("/api/delegates?status=pending")]);
  const c = ov.counts;
  if (c.conferences === 0) {
    view.innerHTML = pageHead("Overview", "Nothing is set up yet.") + `<section class="panel">${emptyState(
      "Create a conference first. Committees and sessions are added inside it.", "new-conference", "Create conference")}</section>`;
    return;
  }
  const placards = ov.activeSessions.map((s) => `
    <article class="placard">
      <div class="live">In session</div>
      <div class="abbr">${esc(s.committee ? s.committee.abbreviation : s.committeeId)}</div>
      <div class="title">${esc(s.title)}</div>
      <div class="meta">${esc(s.committee ? s.committee.name : "")}</div>
      <div class="meta">${esc(s.startTime)} to ${esc(s.endTime)}, ${esc(UI.formatDate(s.date))}</div>
    </article>`).join("");
  const upcoming = ov.upcomingSessions.map((s) => `
    <li><time datetime="${esc(s.date)}">${esc(UI.formatDate(s.date))}<br>${esc(s.startTime)}</time>
      <div><strong>${esc(s.title)}</strong><span class="sub">${esc(s.committee ? s.committee.name : s.committeeId)}</span></div>
      <div><button class="btn btn-small btn-brass" data-action="activate" data-id="${esc(s.id)}">Activate</button></div></li>`).join("");
  const assigned = state.summaries.reduce((n, x) => n + x.assigned, 0);
  view.innerHTML = pageHead("Overview", "What’s happening across your conferences right now.") + `
    <div class="stats">
      <div class="stat"><b>${c.committees}</b><span>Committees</span></div>
      <div class="stat"><b>${assigned}</b><span>Delegates placed</span></div>
      <div class="stat"><b>${pending.length}</b><span>Registrations to review</span></div>
      <div class="stat"><b>${c.activeSessions}</b><span>In session now</span></div>
    </div>
    ${pending.length ? `<div class="callout"><span>${pending.length} delegate registration${pending.length === 1 ? " is" : "s are"} waiting for review.</span>
      <a class="btn btn-small btn-primary" href="#delegates" data-filter-pending>Review</a></div>` : ""}
    <section class="panel"><div class="panel-head"><h2>In session now</h2></div>
      <div class="panel-body">${placards ? `<div class="placards">${placards}</div>`
        : `<p class="sub">No committee is in session. Activate a session to start one.</p>`}</div></section>
    <section class="panel"><div class="panel-head"><h2>Coming up</h2><a class="btn btn-small" href="#sessions">All sessions</a></div>
      <div class="panel-body">${upcoming ? `<ul class="upcoming">${upcoming}</ul>`
        : `<p class="sub">No scheduled sessions from today onward.</p>`}</div></section>`;
  const link = view.querySelector("[data-filter-pending]");
  if (link) link.addEventListener("click", () => { state.filters.dStatus = "pending"; });
}

// --------------------------------------------------------- conferences
async function renderConferences(view) {
  await loadCore();
  const rows = state.conferences.map((c) => `<tr>
    <td class="id">${esc(c.id)}</td>
    <td><strong>${esc(c.name)}</strong><span class="sub">${esc(c.description)}</span></td>
    <td>${esc(c.venue)}</td>
    <td>${esc(UI.formatDate(c.startDate))} to ${esc(UI.formatDate(c.endDate))}</td>
    <td class="num">${state.committees.filter((m) => m.conferenceId === c.id).length}</td>
    <td class="actions">
      <button class="btn btn-small" data-action="edit-conference" data-id="${esc(c.id)}">Edit</button>
      <button class="btn btn-small btn-danger" data-action="delete-conference" data-id="${esc(c.id)}">Delete</button></td></tr>`).join("");
  view.innerHTML = pageHead("Conferences", "Each conference holds its committees and their sessions.", "new-conference", "New conference") +
    `<section class="panel">${rows ? `<div class="table-wrap"><table>
      <thead><tr><th>ID</th><th>Name</th><th>Venue</th><th>Dates</th><th class="num">Committees</th><th></th></tr></thead>
      <tbody>${rows}</tbody></table></div>` : emptyState("No conferences yet.", "new-conference", "Create conference")}</section>`;
}

function conferenceFields(c) {
  const f = [];
  if (!c) f.push({ name: "id", label: "Conference ID", maxlength: 15, omitIfEmpty: true,
    hint: "Optional. Leave blank to number it automatically, like CONF001." });
  f.push(
    { name: "name", label: "Name", required: true, maxlength: 100, value: c && c.name },
    { name: "venue", label: "Venue", required: true, maxlength: 100, value: c && c.venue },
    { name: "startDate", label: "Starts", type: "date", required: true, half: true, value: c && c.startDate },
    { name: "endDate", label: "Ends", type: "date", required: true, half: true, value: c && c.endDate },
    { name: "description", label: "Description", type: "textarea", maxlength: 300, value: c && c.description });
  return f;
}

// ---------------------------------------------------------- committees
async function renderCommittees(view) {
  await loadCore();
  const confOptions = state.conferences.map((c) =>
    `<option value="${esc(c.id)}" ${c.id === state.filters.conferenceId ? "selected" : ""}>${esc(c.name)}</option>`).join("");
  view.innerHTML = pageHead("Committees", "Capacity, placed delegates and Executive Board per committee.", "new-committee", "New committee") + `
    <section class="panel">
      <div class="toolbar">
        <label>Conference <select id="filter-conference"><option value="">All conferences</option>${confOptions}</select></label>
        <label>Search <input id="filter-query" type="search" placeholder="Name or abbreviation" value="${esc(state.filters.query)}"></label>
      </div>
      <div id="committee-table"></div>
    </section>`;
  document.getElementById("filter-conference").addEventListener("change", (e) => {
    state.filters.conferenceId = e.target.value; refreshCommitteeTable();
  });
  let timer;
  document.getElementById("filter-query").addEventListener("input", (e) => {
    clearTimeout(timer);
    timer = setTimeout(() => { state.filters.query = e.target.value.trim(); refreshCommitteeTable(); }, 250);
  });
  await refreshCommitteeTable();
}

async function refreshCommitteeTable() {
  const box = document.getElementById("committee-table");
  if (!box) return;
  if (state.conferences.length === 0) {
    box.innerHTML = emptyState("Create a conference before adding committees.", "new-conference", "Create conference");
    return;
  }
  const params = new URLSearchParams();
  if (state.filters.conferenceId) params.set("conferenceId", state.filters.conferenceId);
  if (state.filters.query) params.set("q", state.filters.query);  // C linear search on the server
  const list = await Api.get(`/api/committees?${params}`);
  const rows = list.map((c) => {
    const sum = state.summaries.find((s) => s.id === c.id) || { assigned: 0, ebCount: 0 };
    const conf = conferenceById(c.conferenceId);
    const full = sum.assigned >= c.capacity;
    return `<tr>
      <td class="id">${esc(c.id)}</td>
      <td><strong>${esc(c.abbreviation)}</strong><span class="sub">${esc(c.name)}</span></td>
      <td>${esc(conf ? conf.name : c.conferenceId)}</td>
      <td>${esc(c.agenda)}</td>
      <td class="num">${sum.assigned} / ${c.capacity}${full ? `<span class="sub">Full</span>` : ""}</td>
      <td class="num">${sum.ebCount}</td>
      <td class="actions">
        <button class="btn btn-small" data-action="roster" data-id="${esc(c.id)}">Roster</button>
        <button class="btn btn-small" data-action="edit-committee" data-id="${esc(c.id)}">Edit</button>
        <button class="btn btn-small btn-danger" data-action="delete-committee" data-id="${esc(c.id)}">Delete</button></td></tr>`;
  }).join("");
  box.innerHTML = rows ? `<div class="table-wrap"><table>
    <thead><tr><th>ID</th><th>Committee</th><th>Conference</th><th>Agenda</th><th class="num">Delegates</th><th class="num">EB</th><th></th></tr></thead>
    <tbody>${rows}</tbody></table></div>`
    : (state.filters.query || state.filters.conferenceId) ? emptyState("No committees match these filters.")
      : emptyState("No committees yet.", "new-committee", "Create committee");
}

function committeeFields(c) {
  const f = [];
  if (!c) {
    f.push({ name: "conferenceId", label: "Conference", type: "select", required: true,
      value: state.filters.conferenceId || (state.conferences[0] && state.conferences[0].id),
      options: state.conferences.map((x) => ({ value: x.id, label: x.name })) });
    f.push({ name: "id", label: "Committee ID", maxlength: 15, omitIfEmpty: true,
      hint: "Optional. Leave blank to number it automatically, like COM001." });
  }
  f.push(
    { name: "name", label: "Full name", required: true, maxlength: 100, value: c && c.name },
    { name: "abbreviation", label: "Abbreviation", required: true, maxlength: 20, half: true, value: c && c.abbreviation },
    { name: "capacity", label: "Delegate capacity", type: "number", required: true, min: 1, max: 500, half: true, value: c ? c.capacity : 40 },
    { name: "agenda", label: "Agenda", type: "textarea", maxlength: 300, value: c && c.agenda });
  return f;
}

async function showRoster(committeeId, sort = "name") {
  const r = await Api.get(`/api/committees/${encodeURIComponent(committeeId)}/roster?sort=${sort}`);
  const d = document.createElement("dialog");
  d.className = "wide";
  const rows = r.delegates.map((x) => `<tr><td class="id">${esc(x.id)}</td><td>${esc(x.name)}</td><td>${esc(x.portfolio)}</td></tr>`).join("");
  d.innerHTML = `<div class="dialog-body">
    <h2>${esc(r.committee.abbreviation)} roster</h2>
    <p class="sub">${r.assigned} of ${r.capacity} seats filled. Sorted by ${esc(r.sort.key)} with ${esc(r.sort.algorithm.toLowerCase())}:
      ${r.sort.comparisons} comparisons, ${r.sort.moves} moves.</p>
    ${rows ? `<div class="table-wrap"><table><thead><tr><th>ID</th><th>Delegate</th><th>Portfolio</th></tr></thead><tbody>${rows}</tbody></table></div>`
      : `<p class="sub">No delegates assigned yet.</p>`}
    <div class="dialog-actions"><button type="button" class="btn btn-primary" data-done>Close</button></div></div>`;
  d.addEventListener("click", (e) => { if (e.target.closest("[data-done]")) d.close(); });
  d.addEventListener("close", () => d.remove());
  document.body.appendChild(d);
  d.showModal();
}

// ------------------------------------------------------------ sessions
async function renderSessions(view) {
  await loadCore();
  const comOptions = state.committees.map((c) =>
    `<option value="${esc(c.id)}" ${c.id === state.filters.committeeId ? "selected" : ""}>${esc(c.abbreviation)}</option>`).join("");
  const statusOptions = ["scheduled", "active", "completed"].map((s) =>
    `<option value="${s}" ${s === state.filters.status ? "selected" : ""}>${s[0].toUpperCase() + s.slice(1)}</option>`).join("");
  view.innerHTML = pageHead("Sessions", "Listed in time order. One session per committee can be active at a time.", "new-session", "New session") + `
    <section class="panel">
      <div class="toolbar">
        <label>Committee <select id="filter-committee"><option value="">All committees</option>${comOptions}</select></label>
        <label>Status <select id="filter-status"><option value="">Any status</option>${statusOptions}</select></label>
      </div>
      <div id="session-table"></div>
    </section>`;
  document.getElementById("filter-committee").addEventListener("change", (e) => { state.filters.committeeId = e.target.value; refreshSessionTable(); });
  document.getElementById("filter-status").addEventListener("change", (e) => { state.filters.status = e.target.value; refreshSessionTable(); });
  await refreshSessionTable();
}

function sessionActions(s) {
  const id = esc(s.id);
  if (s.status === "scheduled") return `
    <button class="btn btn-small btn-brass" data-action="activate" data-id="${id}">Activate</button>
    <button class="btn btn-small" data-action="edit-session" data-id="${id}">Edit</button>
    <button class="btn btn-small btn-danger" data-action="delete-session" data-id="${id}">Delete</button>`;
  if (s.status === "active") return `
    <button class="btn btn-small" data-action="deactivate" data-id="${id}">Pause</button>
    <button class="btn btn-small btn-primary" data-action="complete" data-id="${id}">Complete</button>`;
  return `<span class="sub">Kept as record</span>`;
}

async function refreshSessionTable() {
  const box = document.getElementById("session-table");
  if (!box) return;
  if (state.committees.length === 0) {
    box.innerHTML = emptyState("Create a committee before scheduling sessions.", "new-committee", "Create committee");
    return;
  }
  const params = new URLSearchParams();
  if (state.filters.committeeId) params.set("committeeId", state.filters.committeeId);
  if (state.filters.status) params.set("status", state.filters.status);
  const list = await Api.get(`/api/sessions?${params}`);
  const rows = list.map((s) => `<tr>
    <td class="id">${esc(s.id)}</td><td><strong>${esc(s.title)}</strong></td>
    <td>${esc(committeeLabel(s.committeeId))}</td><td>${esc(UI.formatDate(s.date))}</td>
    <td>${esc(s.startTime)} to ${esc(s.endTime)}</td><td>${badge(s.status, s.statusLabel)}</td>
    <td class="actions">${sessionActions(s)}</td></tr>`).join("");
  box.innerHTML = rows ? `<div class="table-wrap"><table>
    <thead><tr><th>ID</th><th>Title</th><th>Committee</th><th>Date</th><th>Time</th><th>Status</th><th></th></tr></thead>
    <tbody>${rows}</tbody></table></div>`
    : (state.filters.committeeId || state.filters.status) ? emptyState("No sessions match these filters.")
      : emptyState("No sessions yet.", "new-session", "Schedule session");
}

function sessionFields(s) {
  const f = [];
  if (!s) {
    f.push({ name: "committeeId", label: "Committee", type: "select", required: true,
      value: state.filters.committeeId || (state.committees[0] && state.committees[0].id),
      options: state.committees.map((c) => {
        const conf = conferenceById(c.conferenceId);
        return { value: c.id, label: `${c.abbreviation} (${conf ? conf.name : c.conferenceId})` };
      }) });
    f.push({ name: "id", label: "Session ID", maxlength: 15, omitIfEmpty: true,
      hint: "Optional. Leave blank to number it automatically, like SES001." });
  }
  f.push(
    { name: "title", label: "Title", required: true, maxlength: 100, value: s && s.title },
    { name: "date", label: "Date", type: "date", required: true, value: s && s.date, hint: "Must fall within the conference dates." },
    { name: "startTime", label: "Starts", type: "time", required: true, half: true, value: s && s.startTime },
    { name: "endTime", label: "Ends", type: "time", required: true, half: true, value: s && s.endTime });
  return f;
}

// ----------------------------------------------------------- delegates
async function renderDelegates(view) {
  await loadCore();
  const f = state.filters;
  const statusOpts = [["pending", "Waiting for review"], ["approved", "Approved"], ["unassigned", "Approved, not placed"],
    ["assigned", "Placed in a committee"], ["rejected", "Rejected"], ["none", "Not registered"]]
    .map(([v, l]) => `<option value="${v}" ${v === f.dStatus ? "selected" : ""}>${l}</option>`).join("");
  const confOpts = state.conferences.map((c) => `<option value="${esc(c.id)}" ${c.id === f.dConf ? "selected" : ""}>${esc(c.name)}</option>`).join("");
  view.innerHTML = pageHead("Delegates", "Review registrations, then place each delegate in a committee with a portfolio.") + `
    <section class="panel">
      <div class="toolbar">
        <label>Status <select id="d-status"><option value="">Everyone</option>${statusOpts}</select></label>
        <label>Conference <select id="d-conf"><option value="">All</option>${confOpts}</select></label>
        <label>Search <input id="d-query" type="search" placeholder="Name, ID, school or country" value="${esc(f.dQuery)}"></label>
      </div>
      <div id="delegate-table"></div>
    </section>`;
  document.getElementById("d-status").addEventListener("change", (e) => { f.dStatus = e.target.value; refreshDelegateTable(); });
  document.getElementById("d-conf").addEventListener("change", (e) => { f.dConf = e.target.value; refreshDelegateTable(); });
  let timer;
  document.getElementById("d-query").addEventListener("input", (e) => {
    clearTimeout(timer);
    timer = setTimeout(() => { f.dQuery = e.target.value.trim(); refreshDelegateTable(); }, 250);
  });
  await refreshDelegateTable();
}

let delegateCache = [];
async function refreshDelegateTable() {
  const box = document.getElementById("delegate-table");
  if (!box) return;
  const f = state.filters;
  const params = new URLSearchParams();
  if (f.dStatus) params.set("status", f.dStatus);
  if (f.dConf) params.set("conferenceId", f.dConf);
  if (f.dQuery) params.set("q", f.dQuery);
  delegateCache = await Api.get(`/api/delegates?${params}`);
  const rows = delegateCache.map((d) => {
    const conf = conferenceById(d.conferenceId);
    const prefs = d.preferences.map(committeeLabel).join(", ");
    let actions = "";
    if (d.status === "pending") actions = `
      <button class="btn btn-small btn-primary" data-action="approve" data-id="${esc(d.id)}">Approve</button>
      <button class="btn btn-small btn-danger" data-action="reject" data-id="${esc(d.id)}">Reject</button>`;
    else if (d.status === "approved" && !d.committeeId) actions = `
      <button class="btn btn-small btn-primary" data-action="assign" data-id="${esc(d.id)}">Place</button>`;
    else if (d.committeeId) actions = `
      <button class="btn btn-small" data-action="assign" data-id="${esc(d.id)}">Move</button>
      <button class="btn btn-small" data-action="unassign" data-id="${esc(d.id)}">Remove from committee</button>`;
    if (!d.committeeId) actions += `<button class="btn btn-small btn-danger" data-action="delete-delegate" data-id="${esc(d.id)}">Delete</button>`;
    const statusLabel = d.committeeId ? "Placed" : { pending: "Pending", approved: "Approved", rejected: "Rejected", none: "Not registered" }[d.status];
    return `<tr>
      <td class="id">${esc(d.id)}</td>
      <td><strong>${esc(d.name)}</strong><span class="sub">${esc(d.email)}</span></td>
      <td>${esc(d.institution)}</td>
      <td>${esc(conf ? conf.name : "")}${prefs ? `<span class="sub">Prefers ${esc(prefs)}</span>` : ""}</td>
      <td>${badge(d.committeeId ? "approved" : d.status, statusLabel)}${d.status === "rejected" ? `<span class="sub">${esc(d.note)}</span>` : ""}</td>
      <td>${d.committeeId ? `<strong>${esc(d.portfolio)}</strong><span class="sub">${esc(committeeLabel(d.committeeId))}</span>` : ""}</td>
      <td class="actions">${actions}</td></tr>`;
  }).join("");
  const filtered = f.dStatus || f.dConf || f.dQuery;
  box.innerHTML = rows ? `<div class="table-wrap"><table>
    <thead><tr><th>ID</th><th>Delegate</th><th>School</th><th>Conference</th><th>Status</th><th>Placement</th><th></th></tr></thead>
    <tbody>${rows}</tbody></table></div><p class="table-note">Listed alphabetically by an in-order walk of the delegate BST.</p>`
    : emptyState(filtered ? "No delegates match these filters." : "No delegates have registered yet. They sign up from the login page.");
}

// ------------------------------------------------------ Executive Board
let ebCache = [];
let permInfo = null;
async function renderEB(view) {
  await loadCore();
  [ebCache, permInfo] = await Promise.all([Api.get("/api/eb"), Api.get("/api/eb/permissions")]);
  const rows = ebCache.map((m) => `<tr>
    <td class="id">${esc(m.id)}</td>
    <td><strong>${esc(m.name)}</strong><span class="sub">${esc(m.email)}</span></td>
    <td>${esc(m.ebRole)}</td>
    <td>${esc(committeeLabel(m.committeeId))}</td>
    <td>${m.permissions.length} of ${permInfo.permissions.length}<span class="sub">${esc(m.permissions.join(", "))}</span></td>
    <td>${m.active ? (m.mustChangePassword ? badge("pending", "Not signed in yet") : badge("approved", "Active")) : badge("revoked", "Revoked")}</td>
    <td class="actions">
      <button class="btn btn-small" data-action="edit-eb" data-id="${esc(m.id)}">Edit</button>
      <button class="btn btn-small" data-action="reset-password" data-id="${esc(m.id)}">Reset password</button>
      ${m.active ? `<button class="btn btn-small btn-danger" data-action="revoke-eb" data-id="${esc(m.id)}">Revoke</button>`
        : `<button class="btn btn-small" data-action="restore-eb" data-id="${esc(m.id)}">Restore</button>`}</td></tr>`).join("");
  view.innerHTML = pageHead("Executive Board", "Each EB member works only in their assigned committee, within their permissions.", "new-eb", "New EB member") +
    `<section class="panel">${rows ? `<div class="table-wrap"><table>
      <thead><tr><th>ID</th><th>Member</th><th>Role</th><th>Committee</th><th>Permissions</th><th>Access</th><th></th></tr></thead>
      <tbody>${rows}</tbody></table></div>`
      : state.committees.length ? emptyState("No Executive Board members yet.", "new-eb", "Create EB member")
        : emptyState("Create a committee first; every EB member is assigned to one.", "new-committee", "Create committee")}</section>`;
}

function ebFields(m) {
  const permOptions = permInfo.permissions.map((p) => ({ value: p.key, label: p.label, locked: p.key === "view" }));
  const f = [
    { name: "name", label: "Full name", required: true, maxlength: 100, value: m && m.name },
    { name: "email", label: "Email", type: "email", required: true, maxlength: 100, value: m && m.email },
    { name: "ebRole", label: "Role", type: "select", required: true, half: true, value: m ? m.ebRole : "Chairperson",
      options: ["Chairperson", "Moderator", "Scribe"].map((r) => ({ value: r, label: r })) },
    { name: "committeeId", label: m ? "Committee (change to transfer)" : "Committee", type: "select", required: true, half: true,
      value: m ? m.committeeId : state.committees[0] && state.committees[0].id,
      options: state.committees.map((c) => ({ value: c.id, label: `${c.abbreviation} (${(conferenceById(c.conferenceId) || {}).name || ""})` })) },
  ];
  if (m) f.push({ name: "permissions", label: "Permissions", type: "checkboxes", options: permOptions, value: m.permissions,
    hint: "Changing the role resets permissions to that role’s defaults unless you also change these." });
  return f;
}

// -------------------------------------------------------------- accounts
async function renderAccounts(view) {
  const [accounts, history] = await Promise.all([
    Api.get(`/api/admin/accounts${state.filters.aRole ? `?role=${state.filters.aRole}` : ""}`),
    Api.get("/api/admin/login-history"),
  ]);
  accounts.sort((a, b) => Number(b.resetRequested) - Number(a.resetRequested));
  const me = Shell.user.id;
  const rows = accounts.map((a) => `<tr${a.resetRequested ? ` class="row-flag"` : ""}>
    <td class="id">${esc(a.id)}</td><td><strong>${esc(a.name)}</strong></td><td>${esc(a.roleTitle)}</td>
    <td>${a.active ? badge("approved", "Active") : badge("revoked", "Deactivated")}
      ${a.resetRequested ? `<span class="sub">Asked for a password reset</span>` : ""}</td>
    <td>${esc(a.createdAt)}</td>
    <td class="actions">
      <button class="btn btn-small ${a.resetRequested ? "btn-primary" : ""}" data-action="reset-password" data-id="${esc(a.id)}">Reset password</button>
      ${a.id === me ? "" : a.active
        ? `<button class="btn btn-small btn-danger" data-action="deactivate" data-id="${esc(a.id)}">Deactivate</button>`
        : `<button class="btn btn-small" data-action="reactivate" data-id="${esc(a.id)}">Activate</button>`}</td></tr>`).join("");
  const hist = history.slice(0, 40).map((h) => `<tr><td>${esc(h.at)}</td><td class="id">${esc(h.accountId)}</td>
    <td>${h.success ? badge("approved", "Signed in") : badge("revoked", "Failed")}</td><td>${esc(h.detail)}</td></tr>`).join("");
  const roleOpts = [["admin", "Admins"], ["eb", "Executive Board"], ["delegate", "Delegates"]]
    .map(([v, l]) => `<option value="${v}" ${v === state.filters.aRole ? "selected" : ""}>${l}</option>`).join("");
  view.innerHTML = pageHead("Accounts", "Password resets, access, and sign-in history for every account.") + `
    <section class="panel">
      <div class="toolbar"><label>Show <select id="a-role"><option value="">All accounts</option>${roleOpts}</select></label></div>
      <div class="table-wrap"><table><thead><tr><th>ID</th><th>Name</th><th>Type</th><th>Status</th><th>Created</th><th></th></tr></thead>
      <tbody>${rows}</tbody></table></div></section>
    <section class="panel"><div class="panel-head"><h2>Recent sign-ins</h2></div>
      ${hist ? `<div class="table-wrap"><table><thead><tr><th>When</th><th>Account</th><th>Result</th><th>Detail</th></tr></thead>
      <tbody>${hist}</tbody></table></div>` : emptyState("No sign-ins recorded yet.")}</section>`;
  document.getElementById("a-role").addEventListener("change", (e) => { state.filters.aRole = e.target.value; Shell.render(); });
}



// ------------------------------------------------------------ marksheets
const SHEET_TEXT = { draft: "Draft", submitted: "Waiting for review", returned: "Returned", approved: "Approved", published: "Published" };
const SHEET_KIND = { submitted: "pending", returned: "rejected", approved: "approved", published: "approved" };
let sheetCache = [];
async function renderMarksheets(view) {
  await loadCore();
  const f = state.filters;
  if (f.msStatus === undefined) f.msStatus = "submitted";
  const params = new URLSearchParams();
  if (f.msStatus) params.set("status", f.msStatus);
  if (f.msCommittee) params.set("committeeId", f.msCommittee);
  sheetCache = await Api.get(`/api/marksheets?${params}`);
  const statusOpts = Object.entries(SHEET_TEXT).map(([k, l]) => `<option value="${k}" ${k === f.msStatus ? "selected" : ""}>${l}</option>`).join("");
  const comOpts = state.committees.map((c) => `<option value="${esc(c.id)}" ${c.id === f.msCommittee ? "selected" : ""}>${esc(c.abbreviation)}</option>`).join("");
  const approvedHere = f.msCommittee && (await Api.get(`/api/marksheets?status=approved&committeeId=${encodeURIComponent(f.msCommittee)}`)).length;
  const rows = sheetCache.map((m) => {
    let actions = `<button class="btn btn-small" data-action="sheet-view" data-id="${esc(m.id)}">View</button>`;
    if (m.status === "submitted") actions += `<button class="btn btn-small btn-primary" data-action="sheet-approve" data-id="${esc(m.id)}">Approve</button>
      <button class="btn btn-small btn-danger" data-action="sheet-return" data-id="${esc(m.id)}">Return</button>`;
    if (m.status === "approved") actions += `<button class="btn btn-small btn-primary" data-action="sheet-publish" data-id="${esc(m.id)}">Publish</button>
      <button class="btn btn-small" data-action="sheet-return" data-id="${esc(m.id)}">Return</button>`;
    return `<tr><td class="id">${esc(m.id)}</td>
      <td><strong>${esc(m.delegate.portfolio)}</strong><span class="sub">${esc(m.delegate.name)}</span></td>
      <td>${esc(committeeLabel(m.committeeId))}</td>
      <td class="num">${m.total} / ${m.maxTotal}<span class="sub">${m.percent}%</span></td>
      <td>${badge(SHEET_KIND[m.status] || "", SHEET_TEXT[m.status])}</td>
      <td><span class="sub">${esc(m.createdBy)}, rev. ${m.revision}</span></td>
      <td class="actions">${actions}</td></tr>`;
  }).join("");
  view.innerHTML = pageHead("Marksheets", "The Executive Board submits marksheets; you approve, return or publish them. You can’t change marks.") + `
    <section class="panel">
      <div class="toolbar">
        <label>Status <select id="ms-status"><option value="">Any</option>${statusOpts}</select></label>
        <label>Committee <select id="ms-com"><option value="">All</option>${comOpts}</select></label>
        ${approvedHere ? `<button class="btn btn-primary btn-small" data-action="sheet-publish-all">Publish ${approvedHere} approved in ${esc(committeeLabel(f.msCommittee))}</button>` : ""}
      </div>
      ${rows ? `<div class="table-wrap"><table><thead><tr><th>ID</th><th>Delegate</th><th>Committee</th><th class="num">Score</th>
        <th>Status</th><th>By</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`
        : emptyState(f.msStatus === "submitted" ? "Nothing is waiting for review." : "No marksheets match these filters.")}
    </section>`;
  document.getElementById("ms-status").addEventListener("change", (e) => { f.msStatus = e.target.value; Shell.render(); });
  document.getElementById("ms-com").addEventListener("change", (e) => { f.msCommittee = e.target.value; Shell.render(); });
}

async function showSheet(id) {
  const m = await Api.get(`/api/marksheets/${encodeURIComponent(id)}`);
  const d = document.createElement("dialog");
  d.className = "wide";
  const crit = m.criteria.map((c) => `<tr><td>${esc(c.name)}</td><td class="num">${c.mark}</td><td class="num">${c.max}</td></tr>`).join("");
  const hist = m.history.map((h) => `<tr><td class="num">${h.revision}</td><td>${esc(h.action)}</td><td>${esc(h.by)}</td>
    <td>${esc(h.at)}</td><td class="num">${h.total}</td><td>${esc(h.note)}</td></tr>`).join("");
  d.innerHTML = `<div class="dialog-body">
    <h2>${esc(m.delegate.portfolio)}: ${m.total} / ${m.maxTotal} (${m.percent}%)</h2>
    <p class="sub">${esc(m.delegate.name)}, ${esc(committeeLabel(m.committeeId))}. ${esc(SHEET_TEXT[m.status])}.</p>
    <div class="table-wrap"><table><thead><tr><th>Criterion</th><th class="num">Mark</th><th class="num">Out of</th></tr></thead><tbody>${crit}</tbody></table></div>
    ${m.remarks ? `<p><strong>EB remarks:</strong> ${esc(m.remarks)}</p>` : ""}
    <h3>Revision history</h3>
    <div class="table-wrap"><table><thead><tr><th class="num">Rev.</th><th>Action</th><th>By</th><th>When</th><th class="num">Total</th><th>Note</th></tr></thead><tbody>${hist}</tbody></table></div>
    <div class="dialog-actions"><button type="button" class="btn btn-primary" data-done>Close</button></div></div>`;
  d.addEventListener("click", (e) => { if (e.target.closest("[data-done]")) d.close(); });
  d.addEventListener("close", () => d.remove());
  document.body.appendChild(d);
  d.showModal();
}

// -------------------------------------------------------------- rankings
async function renderRankings(view) {
  await loadCore();
  const f = state.filters;
  f.rkCom = f.rkCom || (state.committees[0] && state.committees[0].id) || "overall";
  f.rkAlg = f.rkAlg || "merge";
  f.rkScope = f.rkScope || "approved";
  const algs = [["bubble", "Bubble sort"], ["selection", "Selection sort"], ["insertion", "Insertion sort"], ["merge", "Merge sort"], ["quick", "Quick sort"]];
  const r = f.rkCom === "overall"
    ? await Api.get(`/api/rankings/overall?algorithm=${f.rkAlg}&scope=${f.rkScope}`)
    : await Api.get(`/api/committees/${encodeURIComponent(f.rkCom)}/rankings?algorithm=${f.rkAlg}&scope=${f.rkScope}`);
  const overall = f.rkCom === "overall";
  const rows = r.rows.map((x) => `<tr${x.award ? ` class="row-award"` : ""}>
    <td class="num rank">${x.rank}${x.tied ? "=" : ""}</td>
    <td><strong>${esc(x.delegate.portfolio)}</strong><span class="sub">${esc(x.delegate.name)}</span></td>
    ${overall ? `<td>${esc(x.committee)}</td>` : ""}
    <td class="num">${x.percent}%</td><td class="num">${x.tiebreak}%</td><td class="num">${x.attendance}%</td>
    <td><span class="sub">${x.separatedBy === "tied" ? "Tied: shares the rank" : x.separatedBy ? `Below by ${esc(x.separatedBy)}` : ""}</span></td>
    ${overall ? "" : `<td>${x.award ? `<span class="badge badge-active">${esc(x.award)}</span>` : ""}</td>`}</tr>`).join("");
  const opt = (v, l, cur) => `<option value="${v}" ${v === cur ? "selected" : ""}>${l}</option>`;
  view.innerHTML = pageHead("Rankings and awards", r.config.order + ".") + `
    <section class="panel">
      <div class="toolbar">
        <label>Ranking <select id="rk-com">${opt("overall", "Overall (all committees)", f.rkCom)}${state.committees.map((c) => opt(c.id, c.abbreviation, f.rkCom)).join("")}</select></label>
        <label>Marksheets <select id="rk-scope">${opt("approved", "Approved and published", f.rkScope)}${opt("published", "Published only", f.rkScope)}${opt("all", "All, including drafts", f.rkScope)}</select></label>
        <label>Sort with <select id="rk-alg">${algs.map(([v, l]) => opt(v, l, f.rkAlg)).join("")}</select></label>
      </div>
      ${rows ? `<div class="table-wrap"><table><thead><tr><th class="num">Rank</th><th>Delegate</th>${overall ? "<th>Committee</th>" : ""}
        <th class="num">Score</th><th class="num">Tie-break</th><th class="num">Attendance</th><th></th>${overall ? "" : "<th>Award</th>"}</tr></thead>
        <tbody>${rows}</tbody></table></div>
        <p class="table-note">${esc(r.sort.name)} on ${r.sort.n} entries: ${r.sort.comparisons} comparisons, ${r.sort.moves} ${f.rkAlg === "insertion" || f.rkAlg === "merge" ? "moves" : "swaps"}, ${(r.sort.elapsedNs / 1000).toFixed(1)} µs measured.</p>`
        : emptyState("No marksheets in this scope yet.")}
    </section>
    <section class="panel"><div class="panel-head"><h2>Compare the five algorithms</h2>
      <div class="btn-row"><button class="btn btn-small" data-action="rk-compare">On these marksheets</button></div></div>
      <div class="toolbar"><label>Generated entries <input id="bm-n" type="number" min="10" max="5000" value="${esc(f.bmN || 1000)}"></label>
        <label>Starting order <select id="bm-order">${opt("random", "Random", f.bmOrder || "random")}${opt("sorted", "Already sorted", f.bmOrder)}${opt("reversed", "Reversed", f.bmOrder)}</select></label>
        <button class="btn btn-small btn-primary" data-action="rk-bench">Run benchmark</button></div>
      <div id="bench" class="panel-body"><p class="sub">Each algorithm runs once in the C code. Counts and times are measured, not estimated.</p></div>
    </section>`;
  if (state.bench) benchTable(state.bench);   // results survive re-renders
  document.getElementById("rk-com").addEventListener("change", (e) => { f.rkCom = e.target.value; state.bench = null; Shell.render(); });
  document.getElementById("rk-alg").addEventListener("change", (e) => { f.rkAlg = e.target.value; Shell.render(); });
  document.getElementById("rk-scope").addEventListener("change", (e) => { f.rkScope = e.target.value; Shell.render(); });
}

function benchTable(b) {
  state.bench = b;
  const maxCmp = Math.max(1, ...b.results.map((x) => x.comparisons));
  const box = document.getElementById("bench");
  box.innerHTML = `<p class="sub">${esc(b.data)}. n = ${b.n}${b.order ? `, ${esc(b.order)} order` : ""}.
    ${b.identicalRankings !== undefined ? (b.identicalRankings ? "All five produced the same ranking." : "The rankings differ.") : ""}</p>
    <div class="table-wrap"><table class="bench"><thead><tr><th>Algorithm</th><th>Comparisons</th><th class="num">Swaps or moves</th><th class="num">Time</th></tr></thead>
    <tbody>${b.results.map((x) => `<tr><td><strong>${esc(x.name)}</strong></td>
      <td><div class="bench-cell"><div class="bench-bar"><span data-w="${Math.max(1, Math.round((x.comparisons / maxCmp) * 100))}"></span></div>
        <span class="num">${x.comparisons.toLocaleString()}</span></div></td>
      <td class="num">${x.moves.toLocaleString()}<span class="sub">${esc(x.movesAre)}</span></td>
      <td class="num">${x.elapsedNs >= 1e6 ? `${(x.elapsedNs / 1e6).toFixed(2)} ms` : `${(x.elapsedNs / 1000).toFixed(1)} µs`}</td></tr>`).join("")}</tbody></table></div>
    <p class="table-note">Times vary between runs with CPU load; comparison counts don’t. Quick sort here uses the last element as the pivot, so already-sorted input is its worst case.</p>`;
  box.querySelectorAll(".bench-bar span").forEach((sp) => { sp.style.width = `${sp.dataset.w}%`; });
}

// ------------------------------------------------------- scoring & awards
let cfgCriteria = null, cfgAwards = null;
async function renderScoring(view) {
  const [c, a] = await Promise.all([Api.get("/api/scoring/criteria"), Api.get("/api/awards/config")]);
  cfgCriteria = c.criteria.map((x) => ({ key: x.key, name: x.name, maxMarks: x.maxMarks, fromAttendance: x.fromAttendance }));
  cfgAwards = { rules: a.rules.map((x) => ({ ...x })), tiebreakKey: a.tiebreakKey };
  const crit = cfgCriteria.map((x, i) => `<tr><td class="num">${i + 1}</td><td><strong>${esc(x.name)}</strong>
      ${x.fromAttendance ? `<span class="sub">Prefilled from attendance</span>` : ""}</td><td class="num">${x.maxMarks}</td>
    <td class="actions">
      <button class="btn btn-small" data-action="crit-up" data-id="${i}" ${i === 0 ? "disabled" : ""} aria-label="Move up">↑</button>
      <button class="btn btn-small" data-action="crit-edit" data-id="${i}">Edit</button>
      <button class="btn btn-small btn-danger" data-action="crit-delete" data-id="${i}" ${cfgCriteria.length === 1 ? "disabled" : ""}>Delete</button></td></tr>`).join("");
  const rules = cfgAwards.rules.map((r, i) => `<tr><td class="num">${i + 1}</td><td><strong>${esc(r.name)}</strong></td>
    <td class="num">${r.positions}</td><td class="num">${r.minPercent}%</td>
    <td class="actions"><button class="btn btn-small" data-action="award-edit" data-id="${i}">Edit</button>
      <button class="btn btn-small btn-danger" data-action="award-delete" data-id="${i}" ${cfgAwards.rules.length === 1 ? "disabled" : ""}>Delete</button></td></tr>`).join("");
  const tbOpts = cfgCriteria.map((x) => `<option value="${esc(x.key)}" ${x.key === cfgAwards.tiebreakKey ? "selected" : ""}>${esc(x.name)}</option>`).join("");
  view.innerHTML = pageHead("Scoring and awards", "Changes apply to marksheets started from now on. Existing marksheets keep the criteria they were marked against.") + `
    <section class="panel"><div class="panel-head"><h2>Scoring criteria <span class="count">total ${c.total}</span></h2>
      <button class="btn btn-small btn-primary" data-action="crit-add" ${cfgCriteria.length >= 10 ? "disabled" : ""}>Add criterion</button></div>
      <div class="table-wrap"><table><thead><tr><th class="num">#</th><th>Criterion</th><th class="num">Out of</th><th></th></tr></thead><tbody>${crit}</tbody></table></div></section>
    <section class="panel"><div class="panel-head"><h2>Awards</h2>
      <button class="btn btn-small btn-primary" data-action="award-add" ${cfgAwards.rules.length >= 8 ? "disabled" : ""}>Add award</button></div>
      <div class="table-wrap"><table><thead><tr><th class="num">Order</th><th>Award</th><th class="num">Places</th><th class="num">Minimum score</th><th></th></tr></thead><tbody>${rules}</tbody></table></div>
      <div class="toolbar"><label>Tie-break criterion <select id="tiebreak">${tbOpts}</select></label>
        <span class="sub">Ties on score are broken by this criterion, then by attendance. Delegates still level share the rank and the award.</span></div></section>`;
  document.getElementById("tiebreak").addEventListener("change", (e) => Shell.act(async () => {
    cfgAwards.tiebreakKey = e.target.value;
    await Api.put("/api/awards/config", cfgAwards); UI.toast("Tie-break saved.");
  }));
}
const saveCriteria = async () => { await Api.put("/api/scoring/criteria", { criteria: cfgCriteria }); UI.toast("Criteria saved."); };
const saveAwards = async () => { await Api.put("/api/awards/config", cfgAwards); UI.toast("Awards saved."); };
const critFields = (x) => [
  { name: "name", label: "Name", required: true, maxlength: 40, value: x && x.name },
  { name: "maxMarks", label: "Out of", type: "number", min: 1, max: 100, required: true, value: x ? x.maxMarks : 10 },
  { name: "fromAttendance", label: "Prefill from attendance", type: "select", value: x && x.fromAttendance ? "yes" : "no",
    options: [{ value: "no", label: "No" }, { value: "yes", label: "Yes: start from the delegate’s attendance rate" }] }];
const awardFields = (x) => [
  { name: "name", label: "Award", required: true, maxlength: 40, value: x && x.name },
  { name: "positions", label: "Places", type: "number", min: 1, max: 50, required: true, half: true, value: x ? x.positions : 1 },
  { name: "minPercent", label: "Minimum score %", type: "number", min: 0, max: 100, required: true, half: true, value: x ? x.minPercent : 60 }];


// --------------------------------------------------------------- reports
let reportCatalog = [];
async function renderReports(view) {
  await loadCore();
  const f = state.filters;
  reportCatalog = await Api.get("/api/reports");
  f.rpKey = f.rpKey || "conference";
  const meta = reportCatalog.find((r) => r.key === f.rpKey) || reportCatalog[0];
  if (meta.requiresCommittee && !f.rpCom) f.rpCom = state.committees[0] ? state.committees[0].id : "";
  const qs = f.rpCom ? `?committeeId=${enc(f.rpCom)}` : "";
  let body;
  try {
    body = renderReport(await Api.get(`/api/reports/${enc(meta.key)}${qs}`));
  } catch (err) {
    body = `<div class="banner">${esc(err.message)}</div>`;
  }
  const opt = (v, l, cur) => `<option value="${esc(v)}" ${v === cur ? "selected" : ""}>${esc(l)}</option>`;
  view.innerHTML = pageHead("Reports", "Built from the live data. Export any report as CSV for a spreadsheet or plain text for printing.") + `
    <section class="panel">
      <div class="toolbar">
        <label>Report <select id="rp-key">${reportCatalog.map((r) => opt(r.key, r.title, meta.key)).join("")}</select></label>
        <label>Committee <select id="rp-com">${meta.requiresCommittee ? "" : opt("", "All committees", f.rpCom || "")}
          ${state.committees.map((c) => opt(c.id, c.abbreviation, f.rpCom)).join("")}</select></label>
        <button class="btn btn-small" data-action="rp-export" data-id="csv">Export CSV</button>
        <button class="btn btn-small" data-action="rp-export" data-id="txt">Export text</button>
      </div>
      <div class="panel-body"><p class="sub">${esc(meta.description)}</p>${body}</div>
    </section>`;
  sizeHistogram(view);
  document.getElementById("rp-key").addEventListener("change", (e) => { f.rpKey = e.target.value; Shell.render(); });
  document.getElementById("rp-com").addEventListener("change", (e) => { f.rpCom = e.target.value; Shell.render(); });
}

// ---------------------------------------------------------- DSA analytics
async function renderAnalytics(view) {
  const a = await Api.get("/api/analytics/dsa");
  const st = a.structures;
  const maxAvg = Math.max(1, ...a.searches.map((x) => x.averageComparisons));
  const searchRows = a.searches.map((x) => `<tr><td><strong>${esc(x.name)}</strong><span class="sub">${esc(x.complexity)}</span></td>
    <td><div class="bench-cell"><div class="bench-bar"><span data-w="${Math.max(1, Math.round((x.averageComparisons / maxAvg) * 100))}"></span></div>
      <span class="num">${x.averageComparisons.toFixed(2)}</span></div></td>
    <td class="num">${x.minComparisons} to ${x.maxComparisons}</td>
    <td class="num">${x.averageNs >= 1000 ? `${(x.averageNs / 1000).toFixed(1)} µs` : `${Math.round(x.averageNs)} ns`}</td></tr>`).join("");
  const card = (label, value, note) => `<div class="stat"><b>${value}</b><span>${esc(label)}</span>${note ? `<span class="sub">${esc(note)}</span>` : ""}</div>`;
  view.innerHTML = pageHead("DSA analytics", "Measured on the real data in the C structures. Counts are exact; times vary with load.") + `
    <section class="panel"><div class="panel-head"><h2>Searching: every delegate, four ways</h2></div>
      ${st.delegates ? `<div class="table-wrap"><table class="bench"><thead><tr><th>Search</th><th>Average comparisons</th><th class="num">Range</th><th class="num">Time per lookup</th></tr></thead>
        <tbody>${searchRows}</tbody></table></div><p class="table-note">${esc(a.note)}</p>` : `<div class="empty"><p>No delegates yet.</p></div>`}
      <div class="toolbar"><label>Trace one search <input id="an-key" placeholder="Delegate ID, e.g. D001" maxlength="15"></label>
        <button class="btn btn-small btn-primary" data-action="an-trace">Show the path</button></div>
      <div id="an-trace" class="panel-body"></div>
    </section>
    <section class="panel"><div class="panel-head"><h2>Structure shapes</h2></div>
      <div class="stats stats-wrap">
        ${card("Hash buckets / load factor", `${st.hashBuckets} / ${st.loadFactor.toFixed(2)}`, `longest chain ${st.longestChain}, resized ${st.rehashes}×`)}
        ${card("BST height", st.bstHeight, `minimum possible ${st.bstMinimumHeight}`)}
        ${card("Linked lists (Module 1)", `${st.conferences} / ${st.committees} / ${st.sessions}`, "conferences / committees / sessions")}
        ${card("EB adjacency list", st.ebMembers, `${st.ebCommitteeVertices} committee vertices`)}
        ${card("Attendance entries", st.attendanceEntries, "dynamic arrays per session")}
        ${card("Speeches / POIs", `${st.speeches} / ${st.pois}`, "history list / pending queue")}
        ${card("Marksheets", st.marksheets, "dynamic array")}
        ${card("Audit entries", st.auditEntries, "hash-chained, append-only")}
      </div></section>
    <section class="panel"><div class="panel-head"><h2>Sorting: the five algorithms on every marksheet</h2>
      <a class="btn btn-small" href="#rankings">Benchmark larger inputs</a></div>
      <div class="panel-body" id="an-sort"></div></section>`;
  view.querySelectorAll(".bench-bar span").forEach((sp) => { sp.style.width = `${sp.dataset.w}%`; });
  if (state.trace) {
    document.getElementById("an-trace").innerHTML = `<div class="table-wrap"><table><thead><tr><th>Search</th><th>Found</th><th class="num">Steps</th><th>Path (what was compared, in order)</th></tr></thead>
      <tbody>${state.trace.map((t) => `<tr><td><strong>${esc(t.algorithm)}</strong></td><td>${t.found ? esc(t.result) : "Not found"}</td>
        <td class="num">${t.comparisons}</td><td class="path">${t.path.map(esc).join(" → ")}${t.pathTruncated ? " …" : ""}</td></tr>`).join("")}</tbody></table></div>`;
  }
  const sortBox = document.getElementById("an-sort");
  const srt = a.sorting;
  sortBox.innerHTML = srt.n ? `<div class="table-wrap"><table><thead><tr><th>Algorithm</th><th class="num">Comparisons</th><th class="num">Swaps or moves</th><th class="num">Time</th></tr></thead>
    <tbody>${srt.results.map((x) => `<tr><td><strong>${esc(x.name)}</strong></td><td class="num">${x.comparisons}</td>
      <td class="num">${x.moves} <span class="sub-inline">${esc(x.movesAre)}</span></td><td class="num">${(x.elapsedNs / 1000).toFixed(1)} µs</td></tr>`).join("")}</tbody></table></div>
    <p class="table-note">n = ${srt.n} marksheets. ${srt.identicalRankings ? "All five produced the same ranking." : "The rankings differ."}</p>`
    : `<p class="sub">No marksheets yet.</p>`;
}

// ---------------------------------------------------------- data & audit
async function renderData(view) {
  const f = state.filters;
  const params = new URLSearchParams({ limit: "100" });
  if (f.auQ) params.set("q", f.auQ);
  if (f.auRole) params.set("role", f.auRole);
  if (f.auFailed) params.set("result", "failed");
  const [status, backups, audit] = await Promise.all([
    Api.get("/api/persistence/status"), Api.get("/api/backups"), Api.get(`/api/audit?${params}`)]);
  const kb = (b) => b >= 1024 ? `${(b / 1024).toFixed(1)} KB` : `${b} B`;
  const files = status.files.map((x) => `<tr><td>${esc(x.file)}</td><td class="num">${x.exists ? x.records : "–"}</td>
    <td class="num">${x.exists ? kb(x.bytes) : "–"}</td><td>${!x.exists ? `<span class="sub">Not created yet</span>` : x.valid ? badge("approved", "Valid") : badge("revoked", "Invalid header")}</td></tr>`).join("");
  const bk = backups.map((b) => `<tr><td class="id">${esc(b.id)}</td><td>${esc(b.label || "")}</td><td>${esc(b.created || "")}</td>
    <td class="num">${b.files || 0} files, ${kb(b.bytes || 0)}</td>
    <td class="actions">${b.valid ? `<button class="btn btn-small btn-danger" data-action="restore" data-id="${esc(b.id)}">Restore</button>` : badge("revoked", "Unreadable")}</td></tr>`).join("");
  const rows = audit.entries.map((e) => `<tr${e.status >= 400 ? ` class="row-flag"` : ""}><td class="num">${e.seq}</td><td>${esc(e.at)}</td>
    <td><strong>${esc(e.actor)}</strong><span class="sub">${esc(e.role)}</span></td><td>${esc(e.action)}</td><td class="id">${esc(e.target)}</td>
    <td class="num">${e.status}</td></tr>`).join("");
  const opt = (v, l, cur) => `<option value="${v}" ${v === cur ? "selected" : ""}>${l}</option>`;
  view.innerHTML = pageHead("Data and audit", `Every change is saved to ${status.dataDir} as it happens.`) + `
    <section class="panel"><div class="panel-head"><h2>Backups</h2>
      <div class="btn-row"><button class="btn btn-small" data-action="verify">Check consistency</button>
        <button class="btn btn-small btn-primary" data-action="backup">Back up now</button></div></div>
      <div id="verify-result"></div>
      ${bk ? `<div class="table-wrap"><table><thead><tr><th>Backup</th><th>Label</th><th>Created</th><th class="num">Size</th><th></th></tr></thead><tbody>${bk}</tbody></table></div>`
        : `<div class="empty"><p>No backups yet. Back up before each conference day.</p></div>`}
      <p class="table-note">Restoring checks every file against the backup’s SHA-256 manifest first, keeps an automatic backup of the current data, and rolls back if anything fails.</p></section>
    <section class="panel"><div class="panel-head"><h2>Audit log <span class="count">${audit.total}</span></h2>
      <div class="btn-row"><button class="btn btn-small" data-action="audit-verify">Verify hash chain</button>
        <button class="btn btn-small" data-action="audit-export">Export CSV</button></div></div>
      <div id="audit-verify"></div>
      <div class="toolbar">
        <label>Search <input id="au-q" type="search" placeholder="Action or record" value="${esc(f.auQ || "")}"></label>
        <label>Role <select id="au-role">${opt("", "Everyone", f.auRole || "")}${opt("admin", "Admin", f.auRole)}${opt("eb", "Executive Board", f.auRole)}${opt("delegate", "Delegates", f.auRole)}${opt("public", "Not signed in", f.auRole)}</select></label>
        <label><input type="checkbox" id="au-failed" ${f.auFailed ? "checked" : ""}> Refused only</label>
      </div>
      ${rows ? `<div class="table-wrap"><table><thead><tr><th class="num">#</th><th>When</th><th>Who</th><th>Action</th><th>Record</th><th class="num">Result</th></tr></thead><tbody>${rows}</tbody></table></div>`
        : `<div class="empty"><p>No entries match.</p></div>`}
      <p class="table-note">Newest first, up to 100 shown. Request contents are never recorded, so passwords and ballot choices stay out of the log.</p></section>
    <section class="panel"><div class="panel-head"><h2>Data files</h2><span class="sub">${kb(status.totalBytes)} in total</span></div>
      <div class="table-wrap"><table><thead><tr><th>File</th><th class="num">Records</th><th class="num">Size</th><th>Check</th></tr></thead><tbody>${files}</tbody></table></div></section>`;
  let timer;
  document.getElementById("au-q").addEventListener("input", (e) => { clearTimeout(timer); timer = setTimeout(() => { f.auQ = e.target.value.trim(); Shell.render(); }, 300); });
  document.getElementById("au-role").addEventListener("change", (e) => { f.auRole = e.target.value; Shell.render(); });
  document.getElementById("au-failed").addEventListener("change", (e) => { f.auFailed = e.target.checked; Shell.render(); });
  if (state.verify) showVerify(state.verify);
  if (state.auditCheck) showAuditCheck(state.auditCheck);
}
function showVerify(v) {
  const box = document.getElementById("verify-result");
  if (!box) return;
  const bad = v.files.filter((x) => !x.match);
  const issues = v.integrity.issues.map((i) => `<li><span class="badge ${i.severity === "error" ? "badge-danger" : "badge-active"}">${esc(i.severity)}</span>
    ${esc(i.store)} ${esc(i.record)}: ${esc(i.message)}</li>`).join("");
  box.innerHTML = `<div class="panel-sub">
    <p class="${v.roundTripOk ? "verdict-found" : "verdict-missing"}">${v.roundTripOk
      ? `Save, reload and save again gave identical files for all ${v.files.length} stores.`
      : `${bad.length} file(s) changed in the round trip: ${esc(bad.map((x) => x.file).join(", "))}.`}</p>
    <p class="${v.integrity.errors ? "verdict-missing" : "verdict-found"}">${v.integrity.errors || v.integrity.warnings
      ? `${v.integrity.errors} integrity error(s), ${v.integrity.warnings} warning(s).` : "No broken links between stores."}</p>
    ${issues ? `<ul class="results">${issues}</ul>` : ""}</div>`;
}
function showAuditCheck(r) {
  const box = document.getElementById("audit-verify");
  if (box) box.innerHTML = `<div class="panel-sub"><p class="${r.intact ? "verdict-found" : "verdict-missing"}">${esc(r.message)}</p></div>`;
}

// --------------------------------------------------------- announcements
async function renderAnnouncements(view) {
  await loadCore();
  const list = await Api.get("/api/announcements");
  const who = { all: "Everyone", delegates: "All delegates", eb: "Executive Board", committee: "Committee" };
  const rows = list.map((a) => `<article class="announcement${a.pinned ? " pinned" : ""}">
    <header><h3>${esc(a.title)}</h3><span class="sub">${esc(a.at)}, ${esc(a.audience === "committee" ? committeeLabel(a.committeeId) : who[a.audience])}${a.pinned ? ", pinned" : ""}</span></header>
    <p>${esc(a.body)}</p>
    <button class="btn btn-small btn-danger" data-action="ann-delete" data-id="${esc(a.id)}">Delete</button></article>`).join("");
  view.innerHTML = pageHead("Announcements", "Shown on delegates’ and Executive Board dashboards, depending on the audience.", "ann-new", "New announcement") +
    `<section class="panel"><div class="panel-body">${rows || `<div class="empty"><p>No announcements yet.</p></div>`}</div></section>`;
}

// --------------------------------------------------------- live monitor
async function renderMonitor(view) {
  view.innerHTML = pageHead("Live monitor", "Every committee in session, refreshed every few seconds.") + `<div id="monitor"></div>`;
  Live.poll(async () => {
    const box = document.getElementById("monitor");
    if (!box) return;
    const list = await Api.get("/api/live/overview");
    if (list.length) Live.sync(list[0].serverNow);
    box.innerHTML = list.length ? `<div class="monitor-grid">${list.map((x) => `<section class="panel monitor">
        <div class="panel-head"><h2>${esc(x.committee.abbreviation)}</h2><span class="sub">${esc(x.session.title)}</span></div>
        <div class="panel-body">
          ${x.current ? `<p class="mon-speaker"><strong>${esc(x.current.portfolio)}</strong> has the floor ${Live.clock(x.startedAt, x.speakingSeconds)}</p>`
            : `<p class="sub">Nobody has the floor.</p>`}
          <dl class="mon-stats">
            <dt>Waiting to speak</dt><dd>${x.queueLength}</dd>
            <dt>Speaking requests</dt><dd>${x.requests}</dd>
            <dt>POIs to decide</dt><dd>${x.poisPending}</dd>
            <dt>Motions pending</dt><dd>${x.motionsPending}</dd>
          </dl>
          ${x.openVote ? `<p class="mon-vote"><span class="badge badge-active">Voting</span> ${esc(x.openVote.subject)}: ${x.openVote.ballotsCast} of ${x.openVote.eligible} voted</p>` : ""}
        </div></section>`).join("")}</div>`
      : `<section class="panel"><div class="empty"><p>No committee is in session right now.</p><a class="btn" href="#sessions">Sessions</a></div></section>`;
    Live.tick();
  }, 4000);
}

// ------------------------------------------------------------- actions
const enc = encodeURIComponent;
const ACTIONS = {
  "rp-export": async (format) => {
    const f = state.filters;
    const qs = new URLSearchParams({ format });
    if (f.rpCom) qs.set("committeeId", f.rpCom);
    await Api.download(`/api/reports/${enc(f.rpKey || "conference")}?${qs}`); },
  "an-trace": async () => {
    const key = document.getElementById("an-key").value.trim().toUpperCase();
    if (!key) return;
    const methods = ["hash", "linear", "binary"];
    const results = await Promise.all(methods.map((m) => Api.get(`/api/dsa/module2/search?method=${m}&key=${enc(key)}`)));
    const d = results[0].found ? await Api.get(`/api/delegates/${enc(key)}`) : null;
    if (d) results.push(await Api.get(`/api/dsa/module2/search?method=bst&key=${enc(d.name)}`));
    state.trace = results; },
  "backup": () => UI.form({ title: "Back up now", submitLabel: "Create backup",
    fields: [{ name: "label", label: "Label (optional)", maxlength: 100, value: "Manual backup" }],
    onSubmit: async (v) => { const b = await Api.post("/api/backups", v); UI.toast(`Backup ${b.id} saved: ${b.files} files.`); Shell.render(); } }),
  "restore": async (id) => {
    if (!await UI.confirm({ title: `Restore ${id}?`, danger: true, confirmLabel: "Restore backup",
      message: "All data goes back to how it was when this backup was made, except the audit log, which keeps its full history. The current data is backed up automatically first, so this can be reversed." })) return;
    const r = await Api.post(`/api/backups/${enc(id)}/restore`);
    UI.toast(`Restored ${r.restored}. Safety backup: ${r.safetyBackup}.`); },
  "verify": async () => { state.verify = await Api.post("/api/persistence/verify"); },
  "audit-verify": async () => { state.auditCheck = await Api.get("/api/audit/verify"); },
  "audit-export": async () => { await Api.download("/api/audit/export"); },
  "ann-new": () => UI.form({ title: "New announcement", submitLabel: "Post announcement",
    fields: [
      { name: "title", label: "Title", required: true, maxlength: 100 },
      { name: "body", label: "Message", type: "textarea", required: true, maxlength: 600 },
      { name: "audience", label: "Who sees it", type: "select", half: true, value: "all", options: [
        { value: "all", label: "Everyone" }, { value: "delegates", label: "All delegates" },
        { value: "eb", label: "Executive Board" }, { value: "committee", label: "One committee" }] },
      { name: "committeeId", label: "Committee (if one committee)", type: "select", half: true,
        options: [{ value: "", label: "–" }, ...state.committees.map((c) => ({ value: c.id, label: c.abbreviation }))] },
      { name: "pinned", label: "Pin to the top", type: "select", value: "no", options: [{ value: "no", label: "No" }, { value: "yes", label: "Yes" }] }],
    onSubmit: async (v) => {
      await Api.post("/api/announcements", { title: v.title, body: v.body, audience: v.audience, committeeId: v.committeeId, pinned: v.pinned === "yes" });
      UI.toast("Announcement posted."); Shell.render(); } }),
  "ann-delete": async (id) => {
    if (!await UI.confirm({ title: "Delete announcement?", danger: true, confirmLabel: "Delete", message: "It disappears from every dashboard." })) return;
    await Api.del(`/api/announcements/${enc(id)}`); },

  "sheet-view": (id) => showSheet(id),
  "sheet-approve": async (id) => { await Api.post(`/api/marksheets/${enc(id)}/approve`); UI.toast(`Approved ${id}.`); },
  "sheet-return": (id) => UI.form({ title: `Return ${id}`, intro: "The Executive Board sees this note and can correct the marks.", submitLabel: "Return marksheet",
    fields: [{ name: "note", label: "What needs correcting", type: "textarea", required: true, maxlength: 300 }],
    onSubmit: async (v) => { await Api.post(`/api/marksheets/${enc(id)}/return`, v); UI.toast(`Returned ${id}.`); Shell.render(); } }),
  "sheet-publish": async (id) => {
    if (!await UI.confirm({ title: "Publish marksheet?", confirmLabel: "Publish", message: "The delegate will see their marks, rank and award. Published marksheets are final." })) return;
    await Api.post(`/api/marksheets/${enc(id)}/publish`); UI.toast(`Published ${id}.`); },
  "sheet-publish-all": async () => {
    if (!await UI.confirm({ title: "Publish results?", confirmLabel: "Publish all approved", message: `Every approved marksheet in ${committeeLabel(state.filters.msCommittee)} becomes visible to its delegate. This is final.` })) return;
    const r = await Api.post(`/api/committees/${enc(state.filters.msCommittee)}/marksheets/publish`); UI.toast(`Published ${r.published} marksheets.`); },
  "rk-compare": async () => {
    const f = state.filters;
    const qs = f.rkCom === "overall" ? `scope=${f.rkScope}` : `committeeId=${enc(f.rkCom)}&scope=${f.rkScope}`;
    state.bench = await Api.get(`/api/rankings/compare?${qs}`); },
  "rk-bench": async () => {
    const n = document.getElementById("bm-n").value, order = document.getElementById("bm-order").value;
    state.filters.bmN = n; state.filters.bmOrder = order;
    state.bench = await Api.get(`/api/rankings/benchmark?n=${enc(n)}&order=${enc(order)}`); },
  "crit-add": () => UI.form({ title: "Add criterion", submitLabel: "Add", fields: critFields(null),
    onSubmit: async (v) => { cfgCriteria.push({ name: v.name, maxMarks: v.maxMarks, fromAttendance: v.fromAttendance === "yes" }); await saveCriteria(); Shell.render(); } }),
  "crit-edit": (i) => { const x = cfgCriteria[Number(i)]; UI.form({ title: `Edit ${x.name}`, submitLabel: "Save", fields: critFields(x),
    // Look the item up again at submit: the page re-renders (and reloads the list) after the dialog opens.
    onSubmit: async (v) => { Object.assign(cfgCriteria[Number(i)], { name: v.name, maxMarks: v.maxMarks, fromAttendance: v.fromAttendance === "yes" }); await saveCriteria(); Shell.render(); } }); },
  "crit-delete": async (i) => { const x = cfgCriteria[Number(i)];
    if (!await UI.confirm({ title: "Delete criterion?", danger: true, confirmLabel: "Delete", message: `${x.name} won’t appear on new marksheets. Existing marksheets keep it.` })) return;
    cfgCriteria.splice(Number(i), 1); await saveCriteria(); },
  "crit-up": async (i) => { const k = Number(i); [cfgCriteria[k - 1], cfgCriteria[k]] = [cfgCriteria[k], cfgCriteria[k - 1]]; await saveCriteria(); },
  "award-add": () => UI.form({ title: "Add award", intro: "Awards are given in this list’s order, down the ranking.", submitLabel: "Add", fields: awardFields(null),
    onSubmit: async (v) => { cfgAwards.rules.push(v); await saveAwards(); Shell.render(); } }),
  "award-edit": (i) => { const x = cfgAwards.rules[Number(i)]; UI.form({ title: `Edit ${x.name}`, submitLabel: "Save", fields: awardFields(x),
    onSubmit: async (v) => { Object.assign(cfgAwards.rules[Number(i)], v); await saveAwards(); Shell.render(); } }); },
  "award-delete": async (i) => { cfgAwards.rules.splice(Number(i), 1); await saveAwards(); },
  "new-conference": () => UI.form({ title: "New conference", submitLabel: "Create conference", fields: conferenceFields(null),
    onSubmit: async (v) => { const c = await Api.post("/api/conferences", v); UI.toast(`Created ${c.name} (${c.id}).`); Shell.render(); } }),
  "edit-conference": (id) => { const c = conferenceById(id); UI.form({ title: `Edit ${c.name}`, submitLabel: "Save changes", fields: conferenceFields(c),
    onSubmit: async (v) => { await Api.put(`/api/conferences/${enc(id)}`, v); UI.toast("Changes saved."); Shell.render(); } }); },
  "delete-conference": async (id) => { const c = conferenceById(id);
    if (!await UI.confirm({ title: "Delete conference?", danger: true, confirmLabel: "Delete conference", message: `${c.name} (${c.id}) will be deleted. This can’t be undone.` })) return;
    await Api.del(`/api/conferences/${enc(id)}`); UI.toast(`Deleted ${c.name}.`); },

  "new-committee": () => { if (!state.conferences.length) { UI.toast("Create a conference first.", "error"); return; }
    UI.form({ title: "New committee", submitLabel: "Create committee", fields: committeeFields(null),
      onSubmit: async (v) => { const c = await Api.post("/api/committees", v); UI.toast(`Created ${c.abbreviation} (${c.id}).`); Shell.render(); } }); },
  "edit-committee": (id) => { const c = committeeById(id); UI.form({ title: `Edit ${c.abbreviation}`, submitLabel: "Save changes", fields: committeeFields(c),
    onSubmit: async (v) => { await Api.put(`/api/committees/${enc(id)}`, v); UI.toast("Changes saved."); Shell.render(); } }); },
  "delete-committee": async (id) => { const c = committeeById(id);
    if (!await UI.confirm({ title: "Delete committee?", danger: true, confirmLabel: "Delete committee", message: `${c.abbreviation} (${c.id}) will be deleted. This can’t be undone.` })) return;
    await Api.del(`/api/committees/${enc(id)}`); UI.toast(`Deleted ${c.abbreviation}.`); },
  "roster": (id) => showRoster(id),

  "new-session": () => { if (!state.committees.length) { UI.toast("Create a committee first.", "error"); return; }
    UI.form({ title: "Schedule session", submitLabel: "Schedule session", fields: sessionFields(null),
      onSubmit: async (v) => { const s = await Api.post("/api/sessions", v); UI.toast(`Scheduled ${s.title} (${s.id}).`); Shell.render(); } }); },
  "edit-session": (id) => { const s = state.sessions.find((x) => x.id === id); UI.form({ title: `Edit ${s.title}`, submitLabel: "Save changes", fields: sessionFields(s),
    onSubmit: async (v) => { await Api.put(`/api/sessions/${enc(id)}`, v); UI.toast("Changes saved."); Shell.render(); } }); },
  "delete-session": async (id) => { const s = state.sessions.find((x) => x.id === id);
    if (!await UI.confirm({ title: "Delete session?", danger: true, confirmLabel: "Delete session", message: `${s.title} (${s.id}) will be deleted. This can’t be undone.` })) return;
    await Api.del(`/api/sessions/${enc(id)}`); UI.toast(`Deleted ${s.title}.`); },
  "activate": async (id) => { const s = await Api.post(`/api/sessions/${enc(id)}/activate`); UI.toast(`${s.title} is now in session.`); },
  "deactivate": async (id) => { const s = await Api.post(`/api/sessions/${enc(id)}/deactivate`); UI.toast(`${s.title} is paused and back to scheduled.`); },
  "complete": async (id) => { const s = state.sessions.find((x) => x.id === id);
    if (!await UI.confirm({ title: "Complete session?", confirmLabel: "Complete session", message: `${s.title} will be closed and kept as a record. A completed session can’t be reopened.` })) return;
    await Api.post(`/api/sessions/${enc(id)}/complete`); UI.toast(`Completed ${s.title}.`); },

  "approve": async (id) => { const d = await Api.post(`/api/delegates/${enc(id)}/approve`); UI.toast(`Approved ${d.name}. Place them in a committee next.`); },
  "reject": (id) => { const d = delegateCache.find((x) => x.id === id);
    UI.form({ title: `Reject ${d.name}?`, intro: "The delegate sees this reason and can apply again.", submitLabel: "Reject registration",
      fields: [{ name: "reason", label: "Reason", type: "textarea", required: true, maxlength: 300 }],
      onSubmit: async (v) => { await Api.post(`/api/delegates/${enc(id)}/reject`, v); UI.toast(`Rejected ${d.name}'s registration.`); Shell.render(); } }); },
  "assign": (id) => { const d = delegateCache.find((x) => x.id === id);
    const options = state.committees.filter((c) => c.conferenceId === d.conferenceId).map((c) => {
      const sum = state.summaries.find((s) => s.id === c.id) || { assigned: 0 };
      const choice = d.preferences.indexOf(c.id);
      return { value: c.id, label: `${c.abbreviation}, ${sum.assigned}/${c.capacity} filled${choice >= 0 ? ` (choice ${choice + 1})` : ""}` };
    });
    if (!options.length) { UI.toast("This conference has no committees yet.", "error"); return; }
    UI.form({ title: `Place ${d.name}`, intro: d.preferences.length ? `Preferences: ${d.preferences.map(committeeLabel).join(", ")}.` : "",
      submitLabel: "Place delegate", fields: [
        { name: "committeeId", label: "Committee", type: "select", required: true, options, value: d.committeeId || d.preferences[0] },
        { name: "portfolio", label: "Country or portfolio", required: true, maxlength: 100, value: d.portfolio,
          hint: "Each portfolio can be held by only one delegate per committee." }],
      onSubmit: async (v) => { await Api.post(`/api/delegates/${enc(id)}/assign`, v); UI.toast(`${d.name} represents ${v.portfolio} in ${committeeLabel(v.committeeId)}.`); Shell.render(); } }); },
  "unassign": async (id) => { const d = delegateCache.find((x) => x.id === id);
    if (!await UI.confirm({ title: "Remove from committee?", confirmLabel: "Remove", message: `${d.name} will no longer represent ${d.portfolio} in ${committeeLabel(d.committeeId)}. Their registration stays approved.` })) return;
    await Api.post(`/api/delegates/${enc(id)}/unassign`); UI.toast(`Removed ${d.name} from the committee.`); },
  "delete-delegate": async (id) => { const d = delegateCache.find((x) => x.id === id);
    if (!await UI.confirm({ title: "Delete delegate account?", danger: true, confirmLabel: "Delete account", message: `${d.name} (${d.id}) and their login will be deleted. This can’t be undone.` })) return;
    await Api.del(`/api/delegates/${enc(id)}`); UI.toast(`Deleted ${d.name}.`); },

  "new-eb": () => { if (!state.committees.length) { UI.toast("Create a committee first.", "error"); return; }
    UI.form({ title: "New Executive Board member", intro: "They get an ID and a temporary password, and must choose their own password at first login.",
      submitLabel: "Create EB member", fields: ebFields(null),
      onSubmit: async (v) => { const res = await Api.post("/api/eb", v); Shell.render();
        UI.credentials({ title: "EB member created", message: `Give these to ${res.member.name} (${res.member.ebRole}, ${committeeLabel(res.member.committeeId)}).`,
          id: res.member.id, password: res.temporaryPassword }); } }); },
  "edit-eb": (id) => { const m = ebCache.find((x) => x.id === id);
    UI.form({ title: `Edit ${m.name}`, submitLabel: "Save changes", fields: ebFields(m),
      onSubmit: async (v) => {
        const body = { name: v.name, email: v.email, ebRole: v.ebRole, committeeId: v.committeeId };
        const permsChanged = v.permissions.slice().sort().join() !== m.permissions.filter((p) => p !== "view").sort().join();
        if (permsChanged || v.ebRole === m.ebRole) body.permissions = v.permissions;
        await Api.put(`/api/eb/${enc(id)}`, body); UI.toast("Changes saved."); Shell.render(); } }); },
  "revoke-eb": async (id) => { const m = ebCache.find((x) => x.id === id);
    if (!await UI.confirm({ title: "Revoke access?", danger: true, confirmLabel: "Revoke access", message: `${m.name} will be signed out at once and can’t log in until you restore access.` })) return;
    await Api.post(`/api/eb/${enc(id)}/revoke`); UI.toast(`Revoked ${m.name}'s access.`); },
  "restore-eb": async (id) => { await Api.post(`/api/eb/${enc(id)}/restore`); UI.toast("Access restored."); },

  "reset-password": async (id) => {
    if (!await UI.confirm({ title: "Reset password?", confirmLabel: "Reset password", message: `${id} will be signed out and get a temporary password to change at next login.` })) return;
    const res = await Api.post(`/api/admin/accounts/${enc(id)}/reset-password`);
    UI.credentials({ title: "Temporary password", message: `Give this to ${res.account.name}.`, id: res.account.id, password: res.temporaryPassword }); },
  "deactivate": async (id) => {
    if (!await UI.confirm({ title: "Deactivate account?", danger: true, confirmLabel: "Deactivate", message: `${id} will be signed out at once and can’t log in until reactivated.` })) return;
    await Api.post(`/api/admin/accounts/${enc(id)}/deactivate`); UI.toast(`Deactivated ${id}.`); },
  "reactivate": async (id) => { await Api.post(`/api/admin/accounts/${enc(id)}/activate`); UI.toast(`Activated ${id}.`); },
};

document.addEventListener("click", (e) => {
  const btn = e.target.closest("#view [data-action]");
  if (!btn) return;
  const action = ACTIONS[btn.dataset.action];
  if (action) Shell.act(() => action(btn.dataset.id));
});

Shell.start({
  role: "admin",
  sections: [
    { key: "overview", label: "Overview" },
    { key: "monitor", label: "Live monitor" },
    { heading: "Setup" },
    { key: "conferences", label: "Conferences" },
    { key: "committees", label: "Committees" },
    { key: "sessions", label: "Sessions" },
    { key: "delegates", label: "Delegates" },
    { key: "eb", label: "Executive Board" },
    { heading: "Results" },
    { key: "marksheets", label: "Marksheets" },
    { key: "rankings", label: "Rankings" },
    { key: "scoring", label: "Scoring & awards" },
    { heading: "Insight" },
    { key: "reports", label: "Reports" },
    { key: "analytics", label: "DSA analytics" },
    { heading: "Administration" },
    { key: "announcements", label: "Announcements" },
    { key: "data", label: "Data & audit" },
    { key: "accounts", label: "Accounts" },
  ],
  renderers: {
    overview: renderOverview, monitor: renderMonitor, conferences: renderConferences, committees: renderCommittees,
    sessions: renderSessions, delegates: renderDelegates, eb: renderEB, accounts: renderAccounts,
    marksheets: renderMarksheets, rankings: renderRankings, scoring: renderScoring,
    reports: renderReports, analytics: renderAnalytics, data: renderData, announcements: renderAnnouncements,
  },
  footLinks: [{ href: "/module1/", label: "Module 1 lab" }, { href: "/module2/", label: "Module 2 lab" }],
});
