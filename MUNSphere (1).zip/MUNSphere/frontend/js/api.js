// MUNSphere — api.js
// Every call to the C++ server goes through here. Adds the login token,
// and handles the two cross-cutting replies in one place:
//   401 (not signed in / session ended)  -> back to the login page
//   403 PASSWORD_CHANGE_REQUIRED          -> the forced password dialog
// The server always answers {ok:true,data} or {ok:false,error:{code,message}}.
"use strict";

class ApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

const Session = {
  KEY: "munsphere.session",
  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || null; } catch (e) { return null; }
  },
  set(token, user) {
    try { localStorage.setItem(this.KEY, JSON.stringify({ token, user })); } catch (e) { /* private mode */ }
  },
  clear() {
    try { localStorage.removeItem(this.KEY); } catch (e) { /* ignore */ }
  },
  token() { const s = this.get(); return s ? s.token : ""; },
};

const Api = {
  onPasswordChangeRequired: null,  // set by auth.js

  async request(method, path, body) {
    const options = { method, headers: {} };
    const token = Session.token();
    if (token) options.headers.Authorization = `Bearer ${token}`;
    if (body !== undefined) {
      options.headers["Content-Type"] = "application/json";
      options.body = JSON.stringify(body);
    }
    let response;
    try {
      response = await fetch(path, options);
    } catch (networkError) {
      throw new ApiError(0, "OFFLINE",
        "Can’t reach the MUNSphere server. Check that it’s still running, then try again.");
    }
    let payload;
    try {
      payload = await response.json();
    } catch (parseError) {
      throw new ApiError(response.status, "BAD_RESPONSE",
        `The server sent an unreadable reply (HTTP ${response.status}).`);
    }
    if (!payload.ok) {
      const err = payload.error || {};
      const e = new ApiError(response.status, err.code || "ERROR", err.message || "Request failed.");
      const onLoginPage = location.pathname.endsWith("/login.html");
      if (response.status === 401 && token && !onLoginPage) {
        Session.clear();
        location.href = `/login.html?ended=1&next=${encodeURIComponent(location.pathname + location.hash)}`;
      }
      if (e.code === "PASSWORD_CHANGE_REQUIRED" && this.onPasswordChangeRequired) {
        this.onPasswordChangeRequired();
      }
      throw e;
    }
    return payload.data;
  },
  // Downloads need the login token, which a plain link can't send: fetch the
  // file with the token, then hand it to the browser through a blob link.
  async download(path) {
    let response;
    try {
      response = await fetch(path, { headers: { Authorization: `Bearer ${Session.token()}` } });
    } catch (e) {
      throw new ApiError(0, "OFFLINE", "Can’t reach the MUNSphere server.");
    }
    if (!response.ok) {
      let message = `Download failed (HTTP ${response.status}).`;
      try { message = (await response.json()).error.message; } catch (e) { /* not JSON */ }
      throw new ApiError(response.status, "DOWNLOAD", message);
    }
    const disposition = response.headers.get("Content-Disposition") || "";
    const match = disposition.match(/filename="([^"]+)"/);
    const url = URL.createObjectURL(await response.blob());
    const a = document.createElement("a");
    a.href = url;
    a.download = match ? match[1] : "munsphere-export";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  },
  get(path) { return this.request("GET", path); },
  post(path, body) { return this.request("POST", path, body === undefined ? {} : body); },
  put(path, body) { return this.request("PUT", path, body); },
  del(path) { return this.request("DELETE", path); },
};
