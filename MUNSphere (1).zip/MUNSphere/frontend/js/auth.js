// MUNSphere — auth.js
// Page guard for the three dashboards. The server enforces every rule;
// this only keeps people on the right page and handles password changes.
"use strict";

const Auth = {
  DASHBOARDS: { admin: "/admin.html", eb: "/eb.html", delegate: "/delegate.html" },

  // Confirms the session with the server and the role for this page.
  async requireRole(role) {
    if (!Session.token()) {
      location.href = `/login.html?next=${encodeURIComponent(location.pathname + location.hash)}`;
      return new Promise(() => {});  // stop the page here while it navigates
    }
    const me = await Api.get("/api/auth/me");
    if (me.role !== role) {
      location.href = this.DASHBOARDS[me.role] || "/login.html";
      return new Promise(() => {});
    }
    Session.set(Session.token(), me);
    if (me.mustChangePassword) await this.changePassword(true);
    return Api.get("/api/auth/me");
  },

  changePassword(forced = false) {
    return new Promise((resolve) => {
      UI.form({
        title: forced ? "Choose a new password" : "Change password",
        intro: forced ? "You signed in with a temporary password. Choose your own to continue." : "",
        dismissible: !forced,
        submitLabel: "Save password",
        fields: [
          { name: "currentPassword", label: forced ? "Temporary password" : "Current password", type: "password", required: true },
          { name: "newPassword", label: "New password", type: "password", required: true, maxlength: 128,
            hint: "At least 8 characters, with a letter and a digit." },
          { name: "confirm", label: "Repeat new password", type: "password", required: true },
        ],
        onSubmit: async (v) => {
          if (v.newPassword !== v.confirm) throw new Error("The new passwords don’t match.");
          await Api.post("/api/auth/change-password", { currentPassword: v.currentPassword, newPassword: v.newPassword });
          UI.toast("Password changed.");
          resolve();
        },
      });
    });
  },

  async logout() {
    try { await Api.post("/api/auth/logout"); } catch (e) { /* already ended */ }
    Session.clear();
    location.href = "/login.html";
  },
};

Api.onPasswordChangeRequired = () => {
  if (!document.querySelector("dialog[open]")) Auth.changePassword(true).then(() => location.reload());
};
