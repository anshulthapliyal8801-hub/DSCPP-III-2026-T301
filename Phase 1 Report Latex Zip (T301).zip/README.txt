MUNSphere Project Proposal — LaTeX Source

Files:
- MUNSphere_Project_Proposal.tex : main LaTeX source
- anshul.png, akshita.png, harsita.png, siddharth.png : team photos
- system_architecture.png : architecture diagram extracted from the supplied report

Compile:
1. Put all files in the same folder.
2. Run: pdflatex MUNSphere_Project_Proposal.tex
3. Run pdflatex a second time if page references/layout need refreshing.

The source is formatted as an editable LaTeX report and follows the supplied 7-page proposal content.
